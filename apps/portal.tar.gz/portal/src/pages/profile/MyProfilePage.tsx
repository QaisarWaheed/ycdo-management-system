import { useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { format } from 'date-fns'
import { ExternalLink, Pencil, ShieldCheck, Upload, X } from 'lucide-react'
import { employeesApi } from '@/api/endpoints/employees'
import { additionalWorkingDaysApi } from '@/api/endpoints/additionalWorkingDays'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from '@/hooks/use-toast'
import { useAuth } from '@/hooks/useAuth'
import { formatDutyDisplay } from '@/lib/dutyTimes'
import { formatBranchLabel } from '@/lib/formatBranchLabel'

export function MyProfilePage() {
  const { user } = useAuth()
  const queryClient = useQueryClient()
  const employeeId = user?.employeeId ?? ''

  const [editing, setEditing] = useState(false)
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [privatePhoto, setPrivatePhoto] = useState<File | null>(null)

  const { data: employee, isLoading } = useQuery({
    queryKey: ['employee-profile', employeeId],
    queryFn: () => employeesApi.getOne(employeeId),
    enabled: !!employeeId,
  })

  const { data: documents = [], isLoading: loadingDocs } = useQuery({
    queryKey: ['employee-documents', employeeId],
    queryFn: () => employeesApi.getDocuments(employeeId),
    enabled: !!employeeId,
  })

  const { data: additionalDays = [], isLoading: loadingAdditionalDays } =
    useQuery({
      queryKey: ['additional-working-days', employeeId],
      queryFn: () => additionalWorkingDaysApi.getByEmployee(employeeId),
      enabled: !!employeeId,
    })

  const dutyHours =
    employee?.dutyTotalHours && employee.dutyTotalHours > 0
      ? employee.dutyTotalHours
      : 8

  useEffect(() => {
    if (employee) {
      setPhone(employee.phone ?? '')
      setEmail(employee.email ?? user?.email ?? '')
    }
  }, [employee, user?.email])

  const updateMutation = useMutation({
    mutationFn: () =>
      employeesApi.update(employeeId, {
        phone: phone || undefined,
        email: email || undefined,
      }),
    onSuccess: () => {
      toast({ title: 'Profile updated successfully' })
      queryClient.invalidateQueries({ queryKey: ['employee-profile'] })
      setEditing(false)
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to update profile',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const privatePhotoMutation = useMutation({
    mutationFn: () => {
      if (!privatePhoto) throw new Error('Select a photo first')
      return employeesApi.uploadPrivatePhoto(employeeId, privatePhoto)
    },
    onSuccess: () => {
      toast({ title: 'Private biometric photo uploaded' })
      setPrivatePhoto(null)
      queryClient.invalidateQueries({ queryKey: ['employee-profile', employeeId] })
    },
    onError: (err: { response?: { data?: { message?: string } }; message?: string }) =>
      toast({
        title: 'Upload failed',
        description: err.response?.data?.message ?? err.message,
        variant: 'destructive',
      }),
  })

  const photoPrivacyMutation = useMutation({
    mutationFn: (hide: boolean) =>
      employeesApi.setProfilePhotoHidden(employeeId, hide),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ['employee-profile', employeeId] }),
    onError: () =>
      toast({
        title: 'Could not update photo privacy',
        variant: 'destructive',
      }),
  })

  const displayName = employee?.fullName ?? user?.email ?? 'Employee'
  const isFemale = employee?.gender?.toUpperCase() === 'FEMALE'

  const initials = employee
    ? employee.fullName
        .trim()
        .split(/\s+/)
        .map((part: string) => part[0])
        .slice(0, 2)
        .join('')
        .toUpperCase()
    : 'EP'

  const handleCancelEdit = () => {
    if (employee) {
      setPhone(employee.phone ?? '')
      setEmail(employee.email ?? user?.email ?? '')
    }
    setEditing(false)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text-primary">My Profile</h1>
        <p className="text-sm text-text-secondary">
          View your personal information and documents
        </p>
      </div>

      <Card className="border-border shadow-sm">
        <CardContent className="flex flex-col items-center gap-4 p-6 sm:flex-row sm:items-start">
          {isLoading ? (
            <Skeleton className="h-20 w-20 rounded-full" />
          ) : (
            <Avatar className="h-20 w-20">
              <AvatarFallback className="bg-primary text-2xl text-white">
                {initials}
              </AvatarFallback>
            </Avatar>
          )}
          <div className="flex-1 text-center sm:text-left">
            {isLoading ? (
              <Skeleton className="mx-auto h-8 w-48 sm:mx-0" />
            ) : (
              <>
                <h2 className="text-xl font-bold">{displayName}</h2>
                <p className="font-mono text-sm text-text-secondary">
                  {employee?.employeeCode}
                </p>
                <div className="mt-2 flex flex-wrap justify-center gap-2 sm:justify-start">
                  <Badge variant="outline">{employee?.currentDesignation}</Badge>
                  <Badge variant="outline" className="bg-green-50">
                    {employee?.status}
                  </Badge>
                </div>
                <p className="mt-2 text-sm text-text-secondary">
                  {formatBranchLabel(employee?.currentBranch, '')}
                  {employee?.currentDepartment &&
                    ` · ${employee.currentDepartment.name}`}
                </p>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="personal">
        <TabsList>
          <TabsTrigger value="personal">Personal Info</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="additional-working-days">
            Additional working days
          </TabsTrigger>
          {isFemale && (
            <TabsTrigger value="privacy">Privacy & Biometric</TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="personal" className="mt-4">
          <Card className="border-border shadow-sm">
            <CardContent className="space-y-4 p-6">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Personal Information</h3>
                {!editing ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditing(true)}
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    Edit Contact
                  </Button>
                ) : (
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleCancelEdit}
                    >
                      <X className="mr-1 h-4 w-4" />
                      Cancel
                    </Button>
                    <Button
                      size="sm"
                      className="bg-primary hover:bg-primary-dark"
                      disabled={updateMutation.isPending}
                      onClick={() => updateMutation.mutate()}
                    >
                      Save
                    </Button>
                  </div>
                )}
              </div>

              <Separator />

              {isLoading ? (
                <div className="space-y-3">
                  {[...Array(6)].map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-1">
                    <Label className="text-text-secondary">Full Name</Label>
                    <p className="font-medium">{displayName}</p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-text-secondary">CNIC</Label>
                    <p className="font-medium">{employee?.cnic}</p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-text-secondary">Gender</Label>
                    <p className="font-medium">{employee?.gender}</p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-text-secondary">Date of Birth</Label>
                    <p className="font-medium">
                      {employee?.dateOfBirth
                        ? format(new Date(employee.dateOfBirth), 'dd/MM/yyyy')
                        : '—'}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-text-secondary">Joining Date</Label>
                    <p className="font-medium">
                      {employee?.joiningDate
                        ? format(new Date(employee.joiningDate), 'dd/MM/yyyy')
                        : '—'}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-text-secondary">Province</Label>
                    <p className="font-medium">{employee?.province ?? '—'}</p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-text-secondary">City</Label>
                    <p className="font-medium">{employee?.city ?? '—'}</p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-text-secondary">Domicile</Label>
                    <p className="font-medium">{employee?.domicile ?? '—'}</p>
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <Label className="text-text-secondary">Current Address</Label>
                    <p className="font-medium">
                      {employee?.currentAddress ?? employee?.address ?? '—'}
                    </p>
                  </div>
                  {employee?.permanentAddress && (
                    <div className="space-y-1 sm:col-span-2">
                      <Label className="text-text-secondary">
                        Permanent Address
                      </Label>
                      <p className="font-medium">{employee.permanentAddress}</p>
                    </div>
                  )}
                  <div className="space-y-1">
                    <Label className="text-text-secondary">Branch</Label>
                    <p className="font-medium">
                      {formatBranchLabel(employee?.currentBranch)}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-text-secondary">Duty Hours</Label>
                    <p className="font-medium">
                      {formatDutyDisplay(
                        employee?.dutyStartTime,
                        employee?.dutyEndTime,
                      )}
                    </p>
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <p className="text-sm text-amber-700">
                      Branch and duty hours can only be updated by HR.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    {editing ? (
                      <Input
                        id="phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+92 300 1234567"
                      />
                    ) : (
                      <p className="font-medium">{employee?.phone ?? '—'}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    {editing ? (
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    ) : (
                      <p className="font-medium">
                        {employee?.email ?? user?.email ?? '—'}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="mt-4">
          <div className="rounded-lg border border-border bg-white">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>File Name</TableHead>
                  <TableHead>Uploaded</TableHead>
                  <TableHead className="w-[80px]" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingDocs ? (
                  [...Array(3)].map((_, i) => (
                    <TableRow key={i}>
                      {[...Array(4)].map((__, j) => (
                        <TableCell key={j}>
                          <Skeleton className="h-5 w-full" />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : documents.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={4}
                      className="py-8 text-center text-text-secondary"
                    >
                      No documents on file
                    </TableCell>
                  </TableRow>
                ) : (
                  documents.map((doc) => (
                    <TableRow key={doc.id}>
                      <TableCell>
                        {doc.documentType.replace(/_/g, ' ')}
                      </TableCell>
                      <TableCell>{doc.fileName}</TableCell>
                      <TableCell>
                        {format(new Date(doc.uploadedAt), 'dd/MM/yyyy')}
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm" asChild>
                          <a
                            href={doc.fileUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          </TabsContent>

          <TabsContent value="additional-working-days" className="mt-4">
            <Card className="border-border shadow-sm">
              <CardContent className="p-0">
                <div className="border-b border-border px-6 py-4">
                  <h3 className="font-semibold">Additional working days</h3>
                  <p className="text-sm text-text-secondary">
                    Extra duty days credited by HR. Each day counts as{' '}
                    {dutyHours} hours on payroll.
                  </p>
                </div>
                {loadingAdditionalDays ? (
                  <div className="space-y-2 p-6">
                    {[...Array(3)].map((_, i) => (
                      <Skeleton key={i} className="h-10 w-full" />
                    ))}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Hours</TableHead>
                        <TableHead>Note</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {additionalDays.length === 0 ? (
                        <TableRow>
                          <TableCell
                            colSpan={3}
                            className="text-text-secondary"
                          >
                            No additional working days recorded
                          </TableCell>
                        </TableRow>
                      ) : (
                        <>
                          {additionalDays.map((row) => (
                            <TableRow key={row.id}>
                              <TableCell>
                                {format(new Date(row.date), 'dd/MM/yyyy')}
                              </TableCell>
                              <TableCell>{dutyHours}h</TableCell>
                              <TableCell>{row.note ?? '—'}</TableCell>
                            </TableRow>
                          ))}
                          <TableRow className="bg-muted/40 font-semibold">
                            <TableCell>Total</TableCell>
                            <TableCell>
                              {additionalDays.length} day(s) ·{' '}
                              {additionalDays.length * dutyHours}h
                            </TableCell>
                            <TableCell />
                          </TableRow>
                        </>
                      )}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {isFemale && (
          <TabsContent value="privacy" className="mt-4">
            <Card className="border-border shadow-sm">
              <CardContent className="space-y-6 p-6">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="mt-0.5 h-5 w-5 text-primary" />
                  <div>
                    <h3 className="font-semibold">Private biometric photo</h3>
                    <p className="text-sm text-text-secondary">
                      This authenticated photo is visible only to you and is
                      used solely for biometric face sync.
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
                  <Avatar className="h-24 w-24">
                    {employee.privatePhotoUrl && (
                      <AvatarImage
                        src={employee.privatePhotoUrl}
                        alt="Private biometric photo"
                      />
                    )}
                    <AvatarFallback className="bg-slate-200 text-slate-600">
                      {employee.hasPrivatePhoto ? 'Private' : 'No photo'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="private-photo">Upload private photo</Label>
                      <Input
                        id="private-photo"
                        type="file"
                        accept="image/jpeg,image/png"
                        onChange={(event) => {
                          const file = event.target.files?.[0] ?? null
                          if (file && file.size > 5 * 1024 * 1024) {
                            toast({
                              title: 'Photo must be 5MB or smaller',
                              variant: 'destructive',
                            })
                            event.target.value = ''
                            setPrivatePhoto(null)
                            return
                          }
                          setPrivatePhoto(file)
                        }}
                      />
                      <p className="mt-1 text-xs text-text-secondary">
                        JPG or PNG, maximum 5MB. Use a clear, front-facing photo.
                      </p>
                    </div>
                    <Button
                      disabled={!privatePhoto || privatePhotoMutation.isPending}
                      onClick={() => privatePhotoMutation.mutate()}
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      {employee.hasPrivatePhoto
                        ? 'Replace Private Photo'
                        : 'Upload Private Photo'}
                    </Button>
                  </div>
                </div>

                <Separator />

                <label className="flex cursor-pointer items-start gap-3">
                  <input
                    type="checkbox"
                    className="mt-1 h-4 w-4 accent-primary"
                    checked={Boolean(employee.hideProfilePhoto)}
                    disabled={photoPrivacyMutation.isPending}
                    onChange={(event) =>
                      photoPrivacyMutation.mutate(event.target.checked)
                    }
                  />
                  <span>
                    <span className="block font-medium">
                      Hide my profile photo from other staff
                    </span>
                    <span className="block text-sm text-text-secondary">
                      Other staff will see a Female Staff placeholder. Your
                      private biometric photo is never shown to them.
                    </span>
                  </span>
                </label>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}
