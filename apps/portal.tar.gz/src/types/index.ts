import type { PayslipSlipData } from '@/lib/payslipSlip'

export interface User {
  id: string
  email: string
  role: string
  /** All effective roles including primary + additional */
  roles?: string[]
  employeeId?: string | null
  branchId?: string | null
}

export interface AuthLoginResponse {
  access_token: string
  user: User
}

export interface Employee {
  id: string
  employeeCode: string
  fullName: string
  cnic: string
  phone?: string | null
  email?: string | null
  dateOfBirth?: string | null
  gender: string
  address?: string | null
  currentAddress?: string | null
  permanentAddress?: string | null
  province?: string | null
  city?: string | null
  domicile?: string | null
  dutyStartTime?: string | null
  dutyEndTime?: string | null
  dutyTotalHours?: number | null
  status: string
  joiningDate: string
  currentDesignation: string
  currentBranch?: { name: string; address?: string | null; phone?: string | null }
  currentDepartment?: { name: string }
  shift?: { name: string; startTime: string; endTime: string } | null
  photoUrl?: string | null
  privatePhotoUrl?: string | null
  hideProfilePhoto?: boolean
  hasPrivatePhoto?: boolean
  stipendRecords?: { basicStipend: number | string; effectiveFrom: string }[]
  documents?: EmployeeDocument[]
}

export interface EmployeeDocument {
  id: string
  documentType: string
  fileName: string
  fileUrl: string
  uploadedAt: string
}

export interface AttendanceLog {
  id: string
  date: string
  checkIn?: string | null
  checkOut?: string | null
  status: string
  lateMinutes?: number
  overtimeMinutes?: number
}

export interface WorkingHours {
  totalMinutes: number
  totalHours: number
  totalDays: number
  thisMonthMinutes: number
  thisMonthHours: number
  averageDailyHours: number
  anomalies?: number
}

export interface AttendanceSummary {
  totalDays: number
  present: number
  absent: number
  late: number
  halfDay: number
  shortLeave: number
  onLeave: number
  uninformedAbsent: number
  holiday: number
  swapCovered: number
  unmarked?: number
  overtimeMinutes: number
  totalLateMinutes: number
}

export interface ActiveTimer {
  primaryShift: {
    checkedIn: boolean
    checkIn: string | null
    checkOut: string | null
    isActive: boolean
  }
  overtime?: {
    checkedIn: boolean
    checkIn: string | null
    checkOut: string | null
    isActive: boolean
    canCheckIn: boolean
    canCheckOut: boolean
    promptPending: boolean
  }
  reliever: {
    isActive: boolean
    checkIn: string | null
    session: { id: string; checkIn: string; checkOut?: string | null } | null
  }
}

export interface RelieverSession {
  id: string
  date: string
  checkIn: string
  checkOut?: string | null
  totalMinutes: number
}

export interface RelieverSummary {
  sessions: RelieverSession[]
  totalMinutes: number
  totalHours: number
}

export interface LeaveRecord {
  id: string
  startDate: string
  endDate: string
  totalDays: number
  status: string
  reason?: string | null
  createdAt?: string
  relieverRequest?: {
    id: string
    status: string
    reliever?: { fullName: string }
  } | null
}

export interface LeaveBalance {
  employeeId: string
  year: number
  totalAllowed: number
  taken: number
  remaining: number
  pending: number
}

export interface PayrollEntry {
  id: string
  month: number
  year: number
  basicStipend: number | string
  totalDeductions: number | string
  totalAllowances: number | string
  netStipend: number | string
  status: string
  deductions?: PayrollDeduction[]
  allowances?: PayrollAllowance[]
  totalRelieverHours?: number
  slip?: PayslipSlipData
  stipendRecord?: {
    allowances?: number | string | null
    reward?: number | string | null
    progressReward?: number | string | null
    fuelAllowance?: number | string | null
    loanDeduction?: number | string | null
    advanceDeduction?: number | string | null
    fineDeduction?: number | string | null
    healthDeduction?: number | string | null
    employee?: Employee & {
      cnic?: string | null
      currentDesignation?: string | null
      dutyTotalHours?: number | null
    }
  }
}

export interface PayrollDeduction {
  id: string
  reason: string
  amount: number | string
  description?: string | null
}

export interface PayrollAllowance {
  id: string
  type: string
  amount: number | string
  description?: string | null
  hours?: number | string | null
}

export interface Letter {
  id: string
  letterType: string
  fileUrl?: string | null
  letterNo?: string | null
  generatedAt: string
  content?: Record<string, unknown>
  variables?: Record<string, unknown> | null
  replyDeadline?: string | null
  isReplied?: boolean
  autoEscalated?: boolean
  requiresAcknowledgement?: boolean
  status?: string
}

export interface BranchChangeRequest {
  id: string
  employeeId: string
  district: string
  purpose: string
  startDate: string
  endDate: string
  duration: number
  status: string
  notes?: string | null
  createdAt: string
}

export type StipendStatus = 'PENDING' | 'ACCEPTED' | 'REJECTED' | 'AUTO_ACCEPTED'

export interface StipendReceipt {
  id: string
  employeeId: string
  month: number
  year: number
  amount: number | string
  status: StipendStatus
  acceptedAt?: string | null
  rejectedAt?: string | null
  rejectionReason?: string | null
  autoAcceptedAt?: string | null
  generatedAt: string
  deadlineAt: string
}

export interface Incentive {
  id: string
  employeeId: string
  amount: number | string
  reason: string
  month: number
  year: number
  createdAt: string
}

/** @deprecated Use BranchChangeRequest */
export type OutstationRequest = BranchChangeRequest

export interface AllegationAcknowledgement {
  id: string
  letterId: string
  employeeId: string
  acknowledgedAt: string
  ipAddress?: string | null
}

export interface LetterReply {
  id: string
  letterId: string
  replyText: string
  repliedAt: string
}

export interface Notification {
  id: string
  message: string
  type: string
  isRead: boolean
  createdAt: string
}

export interface AdvanceLoanRequest {
  id: string
  employeeId: string
  type: 'ADVANCE' | 'LOAN' | string
  amount: number | string
  reason: string
  status: string
  repaymentMonths?: number | null
  monthlyDeduction?: number | string | null
  createdAt: string
}
