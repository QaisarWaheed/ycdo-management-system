import { amountInWords } from '@/lib/amountInWords'
import { payslipDayCells, type PayslipSlipData } from '@/lib/payslipSlip'
import { formatPKR } from '@/lib/helpers'

function fmtAmount(amount: number) {
  if (!amount) return 'Nil'
  return formatPKR(amount)
}

function display(value: string | number | null | undefined) {
  if (value === null || value === undefined || value === '') return '—'
  return value
}

function MetaCell({
  label,
  value,
}: {
  label: string
  value: string | number
}) {
  return (
    <div className="min-w-0">
      <p className="text-[10px] font-medium uppercase tracking-wide text-black/55">
        {label}
      </p>
      <p className="truncate text-xs font-medium sm:text-sm">{display(value)}</p>
    </div>
  )
}

function MoneyRow({
  label,
  amount,
  bold,
}: {
  label: string
  amount: number
  bold?: boolean
}) {
  return (
    <tr className={bold ? 'font-semibold' : undefined}>
      <td className="border border-black/30 px-2 py-1 text-xs">{label}</td>
      <td className="border border-black/30 px-2 py-1 text-right text-xs tabular-nums">
        {fmtAmount(amount)}
      </td>
    </tr>
  )
}

export function PayslipDocument({ slip }: { slip: PayslipSlipData }) {
  const netPay = slip.netPay ?? slip.totalAmount ?? 0
  const earningsTotal =
    slip.earningsTotal ??
    slip.earnings.stipend +
      slip.earnings.previousMonth +
      slip.earnings.rewardOnProgress +
      slip.earnings.rewards +
      slip.earnings.otherAllowance +
      slip.earnings.fuel +
      slip.earnings.mobileLoad +
      slip.earnings.extraDuty

  const deductionsTotal =
    slip.deductionsTotal ??
    slip.deductions.advance +
      slip.deductions.loan +
      slip.deductions.mobileLoad +
      slip.deductions.absence +
      slip.deductions.fine +
      slip.deductions.health +
      (slip.deductions.providentFund ?? 0) +
      (slip.deductions.tax ?? 0) +
      (slip.deductions.staffPendingMed ?? 0) +
      (slip.deductions.kitchenPending ?? 0) +
      (slip.deductions.electricityBill ?? 0) +
      (slip.deductions.mobileBill ?? 0) +
      (slip.deductions.other ?? 0)

  return (
    <div className="print-content mx-auto max-w-[820px] overflow-x-auto bg-white p-2 text-black sm:p-4">
      <div className="min-w-0 border border-black p-3 sm:p-4">
        <div className="mb-3 text-center">
          <h2 className="text-sm font-bold uppercase tracking-wide sm:text-base">
            {slip.orgName}
          </h2>
          <p className="mt-1 text-xs font-semibold sm:text-sm">{slip.title}</p>
        </div>

        {slip.sections ? (
          <div className="mb-3 flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-lg font-bold leading-tight sm:text-xl">{slip.employeeName}</p>
              {slip.employeeStatus ? (
                <span className="mt-1 inline-block rounded border-2 border-black px-2 text-xs font-bold uppercase">
                  {slip.employeeStatus.replace(/_/g, ' ')}
                </span>
              ) : null}
            </div>
            <div className="h-24 w-20 shrink-0 overflow-hidden border-2 border-black bg-black/5">
              {slip.photoUrl ? (
                <img src={slip.photoUrl} alt="" className="h-full w-full object-cover" />
              ) : null}
            </div>
          </div>
        ) : null}

        <div className="mb-4 grid grid-cols-2 gap-x-6 gap-y-2 border-b border-black/20 pb-3 sm:grid-cols-2">
          <MetaCell label="CNIC" value={slip.cnic} />
          <MetaCell label="Hospital" value={slip.hospital || slip.workPlace} />
          <MetaCell label="Name" value={slip.employeeName} />
          <MetaCell label="Work Place" value={slip.workPlace} />
          <MetaCell label="Designation" value={slip.designation} />
          <MetaCell label="Period" value={slip.period || slip.payPeriod} />
          <MetaCell label="Total Day" value={slip.totalDays} />
          <MetaCell label="Leave" value={slip.leaveDays ?? 0} />
          <MetaCell label="Time" value={slip.dutyTime || '—'} />
          <MetaCell label="Presence" value={slip.presence ?? 0} />
        </div>

        {slip.dayDetails ? (
          <div className="mb-4 flex flex-wrap border-2 border-black text-center">
            {payslipDayCells(slip.dayDetails.breakdown).map((c) => (
              <div
                key={c.label}
                className={`min-w-[4.5rem] flex-1 border-b border-r border-black/30 px-1 py-0.5 ${c.strong ? 'bg-yellow-300' : ''}`}
              >
                <div className="text-[10px] leading-tight">{c.label}</div>
                <div className="text-sm font-bold tabular-nums">{c.value}</div>
              </div>
            ))}
          </div>
        ) : null}

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 print:grid-cols-2">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-black/5">
                <th className="border border-black/30 px-2 py-1 text-left text-xs font-semibold">
                  Stipend &amp; Allowances
                </th>
                <th className="border border-black/30 px-2 py-1 text-right text-xs font-semibold">
                  Amount
                </th>
              </tr>
            </thead>
            {slip.sections ? (
              <tbody>
                {(slip.sections.find((s) => s.key === 'earnings')?.lines ?? []).map((l) => (
                  <MoneyRow
                    key={`${l.label}-${l.note ?? ''}`}
                    label={l.note ? `${l.label} — ${l.note}` : l.label}
                    amount={l.amount}
                  />
                ))}
                <MoneyRow label="Stipend & Other Allowances" amount={earningsTotal} bold />
              </tbody>
            ) : (
            <tbody>
              <MoneyRow label="Actual Basic Stipend" amount={slip.earnings.contractualStipend ?? slip.earnings.stipend} />
              <MoneyRow label="Stipend" amount={slip.earnings.stipend} />
              <MoneyRow label="Extra Day" amount={slip.earnings.extraDuty} />
              <MoneyRow
                label="Previous Month"
                amount={slip.earnings.previousMonth}
              />
              <MoneyRow
                label="Reward On Progress"
                amount={slip.earnings.rewardOnProgress}
              />
              <MoneyRow label="Rewards" amount={slip.earnings.rewards} />
              <MoneyRow
                label="Other Allowance"
                amount={slip.earnings.otherAllowance}
              />
              <MoneyRow label="Fuel" amount={slip.earnings.fuel} />
              <MoneyRow
                label="Mobile Load"
                amount={slip.earnings.mobileLoad}
              />
              <MoneyRow
                label="Stipend & Other Allowances"
                amount={earningsTotal}
                bold
              />
            </tbody>
            )}
          </table>

          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-black/5">
                <th className="border border-black/30 px-2 py-1 text-left text-xs font-semibold">
                  Deduction
                </th>
                <th className="border border-black/30 px-2 py-1 text-right text-xs font-semibold">
                  Amount
                </th>
              </tr>
            </thead>
            {slip.sections ? (
              <tbody>
                {slip.sections
                  .filter((s) => s.key !== 'earnings' && s.lines.length > 0)
                  .map((s) => [
                    <tr key={s.key} className="bg-yellow-100">
                      <td colSpan={2} className="border border-black/30 px-2 py-1 text-xs font-semibold">
                        {s.title}
                      </td>
                    </tr>,
                    ...s.lines.map((l) => (
                      <MoneyRow
                        key={`${s.key}-${l.label}-${l.note ?? ''}`}
                        label={l.note ? `${l.label} — ${l.note}` : l.label}
                        amount={l.amount}
                      />
                    )),
                  ])}
                <MoneyRow label="Deduction" amount={deductionsTotal} bold />
                <MoneyRow label="Net Stipend" amount={netPay} bold />
              </tbody>
            ) : (
            <tbody>
              <MoneyRow label="Advance" amount={slip.deductions.advance} />
              <MoneyRow label="Loan" amount={slip.deductions.loan} />
              <MoneyRow
                label="Mobile Load"
                amount={slip.deductions.mobileLoad}
              />
              <MoneyRow label="Absence" amount={slip.deductions.absence} />
              <MoneyRow label="Fine" amount={slip.deductions.fine} />
              <MoneyRow
                label="Medicine Pending"
                amount={slip.deductions.staffPendingMed ?? 0}
              />
              <MoneyRow
                label="Kitchen Pending"
                amount={slip.deductions.kitchenPending ?? 0}
              />
              <MoneyRow
                label="Electricity Bill"
                amount={slip.deductions.electricityBill ?? 0}
              />
              <MoneyRow
                label="Mobile Bill"
                amount={slip.deductions.mobileBill ?? 0}
              />
              <MoneyRow label="Health" amount={slip.deductions.health} />
              <MoneyRow
                label="Provident Fund"
                amount={slip.deductions.providentFund ?? 0}
              />
              <MoneyRow label="Tax" amount={slip.deductions.tax ?? 0} />
              <MoneyRow label="Other" amount={slip.deductions.other ?? 0} />
              <MoneyRow label="Deduction" amount={deductionsTotal} bold />
              <MoneyRow label="Net Stipend" amount={netPay} bold />
            </tbody>
            )}
          </table>
        </div>

        <p className="mt-3 text-xs text-black/70">
          Paid Through: {slip.paidThrough || 'Nil'}
        </p>
        <p className="mt-2 break-words text-xs">
          <span className="font-medium">Amount in words: </span>
          {amountInWords(netPay)}
        </p>
        <p className="mt-2 text-[11px] text-black/70">
          Bank Charges (if any) will be deducted from Stipend by the bank
        </p>

        <div className="mt-8 grid grid-cols-3 gap-2 text-center text-[10px] sm:text-xs">
          <div>
            <div className="mb-6 border-b border-black/40" />
            <p>President YCDO</p>
          </div>
          <div>
            <div className="mb-6 border-b border-black/40" />
            <p>Chairman Admin YCDO</p>
          </div>
          <div>
            <div className="mb-6 border-b border-black/40" />
            <p>Chairman Finance YCDO</p>
          </div>
        </div>
      </div>
    </div>
  )
}
