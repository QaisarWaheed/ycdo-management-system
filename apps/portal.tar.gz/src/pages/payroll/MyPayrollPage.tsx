import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { format, formatDistanceToNow } from 'date-fns'
import { Printer } from 'lucide-react'
import { incentivesApi } from '@/api/endpoints/incentives'
import { employeesApi } from '@/api/endpoints/employees'
import { payrollApi } from '@/api/endpoints/payroll'
import { stipendReceiptsApi, type CorrectionCategory } from '@/api/endpoints/stipendReceipts'
import { ConfirmDialog } from '@/components/common/ConfirmDialog'
import { PayslipDocument } from '@/components/payroll/PayslipDocument'
import {
  buildHistoryPayrollReportRows,
  PayrollReportPrintSection,
  PrintPayrollReportButton,
} from '@/components/payroll/PayrollReportPrint'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import { toast } from '@/hooks/use-toast'
import { useAuth } from '@/hooks/useAuth'
import { formatPKR } from '@/lib/helpers'
import { buildPayslipSlipFromEntry } from '@/lib/payslipSlip'
import type { PayslipSlipData } from '@/lib/payslipSlip'
import type {
  Employee,
  Incentive,
  PayrollEntry,
  StipendReceipt,
  StipendStatus,
} from '@/types'

function enrichSlipWithEmployee(
  slip: PayslipSlipData,
  employee?: Employee | null,
): PayslipSlipData {
  if (!employee) return slip
  return {
    ...slip,
    cnic: slip.cnic || employee.cnic || '',
    employeeName: slip.employeeName || employee.fullName || '',
    employeeId: slip.employeeId || employee.employeeCode || '',
    designation: slip.designation || employee.currentDesignation || '',
    department: slip.department || employee.currentDepartment?.name || '',
    hospital: slip.hospital || employee.currentBranch?.name || '',
    workPlace:
      slip.workPlace ||
      employee.currentBranch?.address ||
      employee.currentBranch?.name ||
      '',
    phone: slip.phone || employee.currentBranch?.phone || '',
    dutyTime:
      slip.dutyTime && slip.dutyTime !== 'Nil'
        ? slip.dutyTime
        : employee.dutyStartTime && employee.dutyEndTime
          ? `${employee.dutyStartTime} To ${employee.dutyEndTime}`
          : slip.dutyTime,
  }
}

function PayrollStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    PENDING: 'bg-amber-100 text-amber-800 border-amber-200',
    VERIFIED: 'bg-violet-100 text-violet-800 border-violet-200',
    PROCESSED: 'bg-blue-100 text-blue-800 border-blue-200',
    PAID: 'bg-green-100 text-green-800 border-green-200',
  }
  return (
    <Badge variant="outline" className={styles[status] ?? ''}>
      {status}
    </Badge>
  )
}

function StipendReceiptStatusBadge({ status }: { status: StipendStatus }) {
  const config: Record<StipendStatus, { label: string; className: string }> = {
    PENDING: {
      label: 'Awaiting Response',
      className: 'bg-amber-100 text-amber-800 border-amber-200',
    },
    ACCEPTED: {
      label: 'Accepted',
      className: 'bg-green-100 text-green-800 border-green-200',
    },
    REJECTED: {
      label: 'Correction requested',
      className: 'bg-red-100 text-red-800 border-red-200',
    },
    AUTO_ACCEPTED: {
      label: 'Auto-Accepted',
      className: 'bg-blue-100 text-blue-800 border-blue-200',
    },
  }
  const item = config[status]
  return (
    <Badge variant="outline" className={item.className}>
      {item.label}
    </Badge>
  )
}

function PayslipDialog({
  entry,
  open,
  onOpenChange,
  employee,
}: {
  entry: PayrollEntry | null
  open: boolean
  onOpenChange: (open: boolean) => void
  employee?: Employee | null
}) {
  const { data: fullEntry, isLoading } = useQuery({
    queryKey: ['payroll-entry-full', entry?.id],
    queryFn: () => payrollApi.getEntryFull(entry!.id),
    enabled: !!entry && open,
    retry: 1,
  })

  if (!entry) return null

  const data = fullEntry ?? entry
  const fromEntry = data.stipendRecord?.employee
  const baseSlip =
    data.slip ??
    buildPayslipSlipFromEntry({
      ...data,
      stipendRecord: {
        ...data.stipendRecord,
        employee: {
          fullName: fromEntry?.fullName ?? employee?.fullName,
          employeeCode: fromEntry?.employeeCode ?? employee?.employeeCode,
          cnic: fromEntry?.cnic ?? employee?.cnic,
          currentDesignation:
            fromEntry?.currentDesignation ?? employee?.currentDesignation,
          dutyStartTime: fromEntry?.dutyStartTime ?? employee?.dutyStartTime,
          dutyEndTime: fromEntry?.dutyEndTime ?? employee?.dutyEndTime,
          dutyTotalHours: fromEntry?.dutyTotalHours ?? employee?.dutyTotalHours,
          currentBranch: fromEntry?.currentBranch ?? employee?.currentBranch,
          currentDepartment:
            fromEntry?.currentDepartment ?? employee?.currentDepartment,
        },
      },
    })
  const slip = enrichSlipWithEmployee(baseSlip, employee)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[min(90dvh,90vh)] overflow-y-auto sm:max-w-3xl">
        <DialogHeader className="no-print">
          <DialogTitle>Stipend Slip</DialogTitle>
        </DialogHeader>

        <div className="no-print mb-4 flex justify-end">
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
        </div>

        {isLoading ? (
          <Skeleton className="h-64 w-full" />
        ) : (
          <PayslipDocument slip={slip} />
        )}
      </DialogContent>
    </Dialog>
  )
}

const CORRECTION_LABEL: Record<CorrectionCategory, string> = {
  OVERTIME: 'Overtime',
  EXTRA_DUTY: 'Extra duty',
  DEDUCTION: 'Deduction',
  OTHER: 'Other',
}
const CORRECTION_STATUS: Record<string, string> = {
  SUBMITTED: 'With HR Operations',
  HR_REJECTED: 'Not accepted by HR Operations',
  FORWARDED: 'With the Chairman',
  CHAIRMAN_REJECTED: 'Not approved',
  APPLIED: 'Approved — added to salary',
}

function StipendReceiptSection() {
  const queryClient = useQueryClient()
  const [acceptReceipt, setAcceptReceipt] = useState<StipendReceipt | null>(null)
  const [rejectReceipt, setRejectReceipt] = useState<StipendReceipt | null>(null)
  const [rejectionReason, setRejectionReason] = useState('')
  const [category, setCategory] = useState<CorrectionCategory>('OVERTIME')
  const [claims, setClaims] = useState<Array<{ date: string; hours: string }>>([{ date: '', hours: '' }])
  const needsDates = category === 'OVERTIME' || category === 'EXTRA_DUTY'
  const claimItems = claims
    .filter((c) => c.date)
    .map((c) => ({ date: c.date, ...(category === 'OVERTIME' && c.hours ? { hours: Number(c.hours) } : {}) }))
  const [, setTick] = useState(0)

  const { data: corrections = [] } = useQuery({
    queryKey: ['salary-corrections-mine'],
    queryFn: () => stipendReceiptsApi.myCorrections(),
  })

  const { data: pendingList = [], isLoading: loadingPending } = useQuery({
    queryKey: ['stipend-receipt-pending'],
    queryFn: () => stipendReceiptsApi.getPending(),
  })

  const { data: history = [], isLoading: loadingHistory } = useQuery({
    queryKey: ['stipend-receipt-my'],
    queryFn: () => stipendReceiptsApi.getMy(),
  })

  const pending = (pendingList as StipendReceipt[])[0] ?? null

  useEffect(() => {
    if (!pending) return
    const timer = setInterval(() => setTick((t) => t + 1), 60000)
    return () => clearInterval(timer)
  }, [pending])

  const respondMutation = useMutation({
    mutationFn: (data: Parameters<typeof stipendReceiptsApi.respond>[0]) => stipendReceiptsApi.respond(data),
    onSuccess: (_r, v) => {
      toast({ title: v.accept ? 'Salary accepted' : 'Correction request sent to HR Operations' })
      queryClient.invalidateQueries({ queryKey: ['salary-corrections-mine'] })
      queryClient.invalidateQueries({ queryKey: ['stipend-receipt-pending'] })
      queryClient.invalidateQueries({ queryKey: ['stipend-receipt-my'] })
      setAcceptReceipt(null)
      setRejectReceipt(null)
      setRejectionReason('')
      setClaims([{ date: '', hours: '' }])
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to respond',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  return (
    <div className="space-y-4">
      {loadingPending ? (
        <Skeleton className="h-40 w-full" />
      ) : pending ? (
        <Card className="border-amber-200 bg-amber-50/50">
          <CardContent className="space-y-4 p-6">
            <p className="font-medium text-amber-800">
              Please review your salary for {pending.month}/{pending.year}
            </p>
            <div>
              <p className="text-sm text-text-secondary">Amount</p>
              <p className="text-4xl font-bold text-primary">
                {formatPKR(pending.amount)}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-text-secondary">Generated</p>
                <p>{format(new Date(pending.generatedAt), 'dd MMM yyyy HH:mm')}</p>
              </div>
              <div>
                <p className="text-text-secondary">Review until (then auto-accepted)</p>
                <p>
                  {format(new Date(pending.deadlineAt), 'dd MMM yyyy HH:mm')}
                  <span className="ml-1 text-amber-700">
                    ({formatDistanceToNow(new Date(pending.deadlineAt), { addSuffix: true })})
                  </span>
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-3">
              <Button
                className="bg-green-600 hover:bg-green-700"
                onClick={() => setAcceptReceipt(pending)}
              >
                Accept salary
              </Button>
              <Button
                variant="destructive"
                onClick={() => setRejectReceipt(pending)}
              >
                Request correction
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-border bg-surface">
          <CardContent className="p-6 text-center text-text-secondary">
            No salary waiting for your review
          </CardContent>
        </Card>
      )}

      <div>
        <h2 className="mb-3 text-lg font-semibold">Salary Review History</h2>
        <div className="rounded-lg border border-border bg-white">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month/Year</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Response Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loadingHistory ? (
                [...Array(3)].map((_, i) => (
                  <TableRow key={i}>
                    {[...Array(4)].map((__, j) => (
                      <TableCell key={j}>
                        <Skeleton className="h-5 w-full" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (history as StipendReceipt[]).length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="py-6 text-center text-text-secondary">
                    No salary review history
                  </TableCell>
                </TableRow>
              ) : (
                (history as StipendReceipt[]).map((receipt) => (
                  <TableRow key={receipt.id}>
                    <TableCell>
                      {receipt.month}/{receipt.year}
                    </TableCell>
                    <TableCell>{formatPKR(receipt.amount)}</TableCell>
                    <TableCell>
                      <StipendReceiptStatusBadge status={receipt.status} />
                    </TableCell>
                    <TableCell>
                      {receipt.acceptedAt
                        ? format(new Date(receipt.acceptedAt), 'dd/MM/yyyy')
                        : receipt.rejectedAt
                          ? format(new Date(receipt.rejectedAt), 'dd/MM/yyyy')
                          : receipt.autoAcceptedAt
                            ? format(new Date(receipt.autoAcceptedAt), 'dd/MM/yyyy')
                            : '—'}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {corrections.length ? (
        <div>
          <h2 className="mb-3 text-lg font-semibold">My correction requests</h2>
          <div className="space-y-2">
            {corrections.map((c) => (
              <Card key={c.id}>
                <CardContent className="space-y-1 p-4 text-sm">
                  <p className="font-medium">
                    {c.month}/{c.year} · {CORRECTION_LABEL[c.category]} ·{' '}
                    <Badge variant="outline">{CORRECTION_STATUS[c.status]}</Badge>
                    {c.impactAmount != null ? ` · ${formatPKR(Number(c.impactAmount))}` : ''}
                  </p>
                  <p className="whitespace-pre-wrap text-text-secondary">{c.details}</p>
                  {c.hrNote ? <p>HR Operations: {c.hrNote}</p> : null}
                  {c.decisionNote ? <p>Chairman: {c.decisionNote}</p> : null}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ) : null}

      <ConfirmDialog
        open={!!acceptReceipt}
        title="Accept salary"
        description={
          acceptReceipt
            ? `Confirm your salary of ${formatPKR(acceptReceipt.amount)} for ${acceptReceipt.month}/${acceptReceipt.year}. Later changes will only be notified to you.`
            : ''
        }
        confirmLabel="Accept"
        loading={respondMutation.isPending}
        onConfirm={() =>
          acceptReceipt &&
          respondMutation.mutate({
            receiptId: acceptReceipt.id,
            accept: true,
          })
        }
        onCancel={() => setAcceptReceipt(null)}
      />

      <Dialog open={!!rejectReceipt} onOpenChange={(v) => !v && setRejectReceipt(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request a salary correction</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>What is wrong?</Label>
              <select
                className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                value={category}
                onChange={(e) => setCategory(e.target.value as CorrectionCategory)}
              >
                <option value="OVERTIME">Overtime not added</option>
                <option value="EXTRA_DUTY">Extra duty / off-day duty not added</option>
                <option value="DEDUCTION">Wrong deduction</option>
                <option value="OTHER">Other</option>
              </select>
            </div>
            {needsDates ? (
              <div className="space-y-2">
                <Label>{category === 'OVERTIME' ? 'Dates and hours *' : 'Dates *'}</Label>
                {claims.map((c, i) => (
                  <div key={i} className="flex gap-2">
                    <input
                      type="date"
                      className="h-9 flex-1 rounded-md border border-input bg-background px-2 text-sm"
                      value={c.date}
                      onChange={(e) => setClaims((cs) => cs.map((x, j) => (j === i ? { ...x, date: e.target.value } : x)))}
                    />
                    {category === 'OVERTIME' ? (
                      <input
                        type="number"
                        min={0}
                        step="0.5"
                        placeholder="Hours"
                        className="h-9 w-24 rounded-md border border-input bg-background px-2 text-sm"
                        value={c.hours}
                        onChange={(e) => setClaims((cs) => cs.map((x, j) => (j === i ? { ...x, hours: e.target.value } : x)))}
                      />
                    ) : null}
                    {claims.length > 1 ? (
                      <Button variant="ghost" size="sm" onClick={() => setClaims((cs) => cs.filter((_x, j) => j !== i))}>
                        ✕
                      </Button>
                    ) : null}
                  </div>
                ))}
                <Button variant="outline" size="sm" onClick={() => setClaims((cs) => [...cs, { date: '', hours: '' }])}>
                  Add date
                </Button>
              </div>
            ) : null}
            <div className="space-y-1">
              <Label>Details *</Label>
              <Textarea
                placeholder="Explain what should be corrected..."
                rows={4}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
              />
              <p className="text-xs text-text-secondary">
                Minimum 10 characters. HR Operations checks it, then the Chairman decides.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectReceipt(null)}>
              Cancel
            </Button>
            <Button
              disabled={
                respondMutation.isPending ||
                rejectionReason.trim().length < 10 ||
                (needsDates && !claimItems.length)
              }
              onClick={() =>
                rejectReceipt &&
                respondMutation.mutate({
                  receiptId: rejectReceipt.id,
                  accept: false,
                  rejectionReason: rejectionReason.trim(),
                  category,
                  claimItems: needsDates ? claimItems : undefined,
                })
              }
            >
              Send request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export function MyPayrollPage() {
  const { user } = useAuth()
  const employeeId = user?.employeeId ?? ''
  const [viewEntry, setViewEntry] = useState<PayrollEntry | null>(null)

  const { data: employee } = useQuery({
    queryKey: ['employee-payroll', employeeId],
    queryFn: () => employeesApi.getOne(employeeId),
    enabled: !!employeeId,
  })

  const { data: history = [], isLoading } = useQuery({
    queryKey: ['payroll-history', employeeId],
    queryFn: () => payrollApi.getMyHistory(employeeId),
    enabled: !!employeeId,
  })

  const { data: incentives = [], isLoading: loadingIncentives } = useQuery({
    queryKey: ['incentives', employeeId],
    queryFn: () => incentivesApi.getByEmployee(employeeId),
    enabled: !!employeeId,
  })

  const currentStipend = employee?.stipendRecords?.[0]

  const sortedHistory = [...(history as PayrollEntry[])].sort(
    (a, b) =>
      new Date(b.year, b.month - 1).getTime() -
      new Date(a.year, a.month - 1).getTime(),
  )

  const historyReportRows = useMemo(
    () => buildHistoryPayrollReportRows(history as PayrollEntry[]),
    [history],
  )

  const printSubtitle = employee
    ? [employee.fullName, employee.employeeCode].filter(Boolean).join(' · ')
    : undefined

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text-primary">My Payroll</h1>
        <p className="text-sm text-text-secondary">
          View your stipend, receipts, incentives and download stipend slips
        </p>
      </div>

      <StipendReceiptSection />

      <Card className="border-border bg-gradient-to-r from-primary/5 to-accent/5 shadow-sm">
        <CardContent className="p-6">
          <p className="text-sm text-text-secondary">Current Basic Stipend</p>
          {employee ? (
            <>
              <p className="text-4xl font-bold text-primary">
                {currentStipend ? formatPKR(currentStipend.basicStipend) : '—'}
              </p>
              {currentStipend && (
                <p className="mt-1 text-xs text-text-secondary">
                  Effective from{' '}
                  {format(new Date(currentStipend.effectiveFrom), 'dd MMM yyyy')}
                </p>
              )}
            </>
          ) : (
            <Skeleton className="mt-2 h-10 w-40" />
          )}
        </CardContent>
      </Card>

      <div>
        <h2 className="mb-3 text-lg font-semibold">Incentives</h2>
        <div className="rounded-lg border border-border bg-white">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month/Year</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Added On</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loadingIncentives ? (
                [...Array(3)].map((_, i) => (
                  <TableRow key={i}>
                    {[...Array(4)].map((__, j) => (
                      <TableCell key={j}>
                        <Skeleton className="h-5 w-full" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (incentives as Incentive[]).length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="py-6 text-center text-text-secondary">
                    No incentives recorded yet
                  </TableCell>
                </TableRow>
              ) : (
                (incentives as Incentive[]).map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      {item.month}/{item.year}
                    </TableCell>
                    <TableCell className="font-medium text-green-600">
                      {formatPKR(item.amount)}
                    </TableCell>
                    <TableCell className="max-w-[240px] truncate" title={item.reason}>
                      {item.reason}
                    </TableCell>
                    <TableCell>
                      {format(new Date(item.createdAt), 'dd/MM/yyyy')}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      <div>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-semibold">Payroll History</h2>
          <PrintPayrollReportButton disabled={sortedHistory.length === 0} />
        </div>
        <div className="no-print rounded-lg border border-border bg-white">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Period</TableHead>
                <TableHead>Basic</TableHead>
                <TableHead>Deductions</TableHead>
                <TableHead>Allowances</TableHead>
                <TableHead>Net Stipend</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[100px]" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [...Array(4)].map((_, i) => (
                  <TableRow key={i}>
                    {[...Array(7)].map((__, j) => (
                      <TableCell key={j}>
                        <Skeleton className="h-5 w-full" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : sortedHistory.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={7}
                    className="py-8 text-center text-text-secondary"
                  >
                    No payroll records found
                  </TableCell>
                </TableRow>
              ) : (
                sortedHistory.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell className="font-medium">
                      {format(new Date(entry.year, entry.month - 1, 1), 'MMM yyyy')}
                    </TableCell>
                    <TableCell>{formatPKR(entry.basicStipend)}</TableCell>
                    <TableCell className="text-red-600">
                      {formatPKR(entry.totalDeductions)}
                    </TableCell>
                    <TableCell className="text-green-600">
                      {formatPKR(entry.totalAllowances)}
                    </TableCell>
                    <TableCell className="font-semibold">
                      {formatPKR(entry.netStipend)}
                    </TableCell>
                    <TableCell>
                      <PayrollStatusBadge status={entry.status} />
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setViewEntry(entry)}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      <PayrollReportPrintSection
        id="portal-payroll-history-print"
        title="My Payroll History"
        subtitle={printSubtitle}
        rows={historyReportRows}
        footer={`Total records: ${sortedHistory.length}`}
      />

      <PayslipDialog
        entry={viewEntry}
        open={!!viewEntry}
        onOpenChange={(v) => !v && setViewEntry(null)}
        employee={employee}
      />
    </div>
  )
}
