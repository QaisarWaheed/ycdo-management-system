import { withPayrollEmployeeTransaction } from '../payroll/payroll-write-lock.util';
import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { normalizeDesignationName } from '../../common/org-structure';
import { inferShiftNameFromDuty } from '../../common/shift-inference.util';
import { normalizeWeeklyOffWeekdays } from '../attendance/weekly-off.util';
import {
  DUTY_FILTER_GRACE_MINUTES,
  getDutyWindow,
  isOnDutyAt,
  hoursBetweenDutyTimes,
  normalizeDutyTimeToHhMm,
  resolveAttendanceDutyTimes,
  workedMinutes,
} from '../../common/duty.util';
import {
  AttendanceStatus,
  ChangeType,
  DisciplinaryStatus,
  DisciplinaryType,
  EmployeeOnboardingStatus,
  EmployeeStatus,
  InquiryOutcome,
  LetterStatus,
  LetterType,
  LeaveStatus,
  MaritalStatus,
  Prisma,
  StaffType,
  SuspensionRequestStatus,
  UserRole,
} from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { PrismaService } from '../../prisma/prisma.service';
import {
  cloudinary,
  isCloudinaryEnabled,
} from '../../config/cloudinary.config';
import { LettersService } from '../letters/letters.service';
import { appointmentExtraFieldsFromEmployee } from '../letters/selection-letter.helper';
import { FaceSyncService } from '../face-sync/face-sync.service';
import {
  toPakistanMinutesOfDay,
} from '../attendance/attendance-late.util';
import { generateEmployeeCode } from './employee-code.helper';
import { getHierarchyPriority } from '../../common/hierarchy.util';
import { enforceBranchScope } from '../../common/branch-scope.util';
import type { BranchScopedUser } from '../../common/branch-scope.util';
import {
  isMedicineManagerRole,
  medicineEmployeeWhere,
} from '../../common/medicine-scope.util';
import {
  ActiveShiftQueryDto,
  ChangeStatusDto,
  CreateEmployeeDto,
  EmployeeQueryDto,
  TransferDto,
  UpdateBranchDutyDto,
  UpdateEmployeeDto,
  UpdateEmployeeRolesDto,
} from './employees.dto';
import {
  buildEffectiveRoles,
  canAssignRoles,
  canOverrideSuspendedStatus,
  hasAnyRole,
} from '../../common/user-roles.util';
import { suspensionInquiryReinstatementData } from '../attendance/suspension-watch-baseline.util';
import {
  buildStatusEffectiveFromUpdate,
  syncEmployeePortalAccess,
} from './status-effective.util';
import { AccessScopeService } from '../permissions/access-scope.service';
import { PermissionsService } from '../permissions/permissions.service';
import { buildEmployeesWorkbook } from './employees-export.util';
import {
  resolveUploadPath,
  safeFileName,
} from '../documents/documents.service';

export type EmployeeFilters = EmployeeQueryDto;

type ActingUser = {
  id: string;
  role: UserRole | string;
  roles?: UserRole[];
  branchId?: string | null;
};

@Injectable()
export class EmployeesService {
  constructor(
    private prisma: PrismaService,
    private lettersService: LettersService,
    private faceSyncService: FaceSyncService,
    private permissionsService: PermissionsService,
    private accessScopeService: AccessScopeService,
  ) {}

  private serializeUserRoles(
    user?: {
      id: string;
      role?: UserRole;
      email?: string;
      isActive?: boolean;
      branchId?: string | null;
      branch?: unknown;
      additionalRoles?: Array<{ role: UserRole }>;
      managerScopes?: Array<{
        id: string;
        projectId: string;
        departmentId: string;
        designationId: string | null;
        project?: { name: string };
        department?: { name: string };
        designation?: { title: string } | null;
      }>;
    } | null,
  ) {
    if (!user?.role) return user ?? null;
    const additional = (user.additionalRoles ?? []).map((entry) => entry.role);
    const roles = buildEffectiveRoles(user.role, additional);
    const managerScopes = (user.managerScopes ?? []).map((scope) => ({
      id: scope.id,
      projectId: scope.projectId,
      projectName: scope.project?.name ?? '',
      departmentId: scope.departmentId,
      departmentName: scope.department?.name ?? '',
      designationId: scope.designationId,
      designationTitle: scope.designation?.title ?? null,
      label: [
        scope.project?.name ?? '',
        scope.department?.name ?? '',
        scope.designation?.title ?? 'All designations',
      ]
        .filter(Boolean)
        .join(' · '),
    }));
    const { additionalRoles: _ignored, managerScopes: _scopes, ...rest } = user;
    return {
      ...rest,
      additionalRoles: additional,
      managerScopes,
      roles,
    };
  }

  private managerScopeSelect() {
    return {
      where: { isActive: true },
      select: {
        id: true,
        projectId: true,
        departmentId: true,
        designationId: true,
        project: { select: { name: true } },
        department: { select: { name: true } },
        designation: { select: { title: true } },
      },
    } as const;
  }

  async create(dto: CreateEmployeeDto, actingUser?: ActingUser) {
    const actorRoles = [...(actingUser?.roles ?? []), ...(actingUser?.role ? [actingUser.role] : [])] as UserRole[];
    if (dto.staffType === StaffType.EXISTING && !hasAnyRole(actorRoles, [UserRole.SUPER_ADMIN])) {
      throw new ForbiddenException('Only Super Admin can add Existing Staff');
    }
    this.validateCreateDto(dto);
    dto.currentDesignation = normalizeDesignationName(dto.currentDesignation);

    await this.ensureBranchExists(dto.currentBranchId);
    await this.ensureDepartmentExists(dto.currentDepartmentId);

    if (dto.cnic) {
      const existingCnic = await this.prisma.employee.findUnique({
        where: { cnic: dto.cnic },
      });
      if (existingCnic) {
        throw new ConflictException('Employee with this CNIC already exists');
      }
    }

    if (dto.email) {
      const existingEmail = await this.prisma.employee.findUnique({
        where: { email: dto.email },
      });
      if (existingEmail) {
        throw new ConflictException('Employee with this email already exists');
      }
    }

    if (dto.shiftId) {
      await this.ensureShiftExists(dto.shiftId);
    }

    let resolvedShiftId = dto.relieverOnly ? undefined : dto.shiftId;
    if (!dto.relieverOnly && !resolvedShiftId && dto.dutyStartTime) {
      resolvedShiftId = await this.assignShiftFromDuty(
        dto.dutyStartTime,
        dto.dutyEndTime,
        dto.dutyTotalHours,
      );
    }

    let syncedDutyStart = this.normalizeOptionalDuty(dto.dutyStartTime);
    let syncedDutyEnd = this.normalizeOptionalDuty(dto.dutyEndTime);
    let syncedDutyHours = dto.dutyTotalHours;
    if (resolvedShiftId) {
      const shift = await this.prisma.shift.findUnique({
        where: { id: resolvedShiftId },
      });
      if (shift) {
        // Explicit shift selection wins over manually entered duty times
        if (dto.shiftId) {
          syncedDutyStart = this.normalizeOptionalDuty(shift.startTime);
          syncedDutyEnd = this.normalizeOptionalDuty(shift.endTime);
          syncedDutyHours =
            this.calculateShiftHours(shift.startTime, shift.endTime) ??
            syncedDutyHours;
        } else {
          syncedDutyStart =
            syncedDutyStart ?? this.normalizeOptionalDuty(shift.startTime);
          syncedDutyEnd =
            syncedDutyEnd ?? this.normalizeOptionalDuty(shift.endTime);
          syncedDutyHours =
            syncedDutyHours ??
            this.calculateShiftHours(syncedDutyStart, syncedDutyEnd);
        }
      }
    }

    const employeeCode = await generateEmployeeCode(this.prisma);
    const joiningDate = new Date(dto.joiningDate);
    const {
      basicStipend,
      allowances,
      reward,
      progressReward,
      fuelAllowance,
      loanDeduction,
      advanceDeduction,
      fineDeduction,
      healthDeduction,
      shiftName: _shiftName,
      approverTarget: _approverTarget,
      formSnapshot: _formSnapshot,
      userRole: _userRole,
      staffType: _staffType,
      ...employeeData
    } = dto;
    const lumpsumTotal = this.calculateLumpsumTotal({
      basicStipend,
      allowances,
      reward,
      progressReward,
      fuelAllowance,
      loanDeduction,
      advanceDeduction,
      fineDeduction,
      healthDeduction,
    });
    const loginEmail =
      dto.email || `${employeeCode.toLowerCase()}@ycdo.org`;

    const existingUserEmail = await this.prisma.user.findUnique({
      where: { email: loginEmail },
    });
    if (existingUserEmail) {
      throw new ConflictException(
        'A user account with this email already exists',
      );
    }

    const employee = await this.prisma.$transaction(async (tx) => {
      const staffType = dto.staffType ?? StaffType.NEW;
      const pendingApproval =
        staffType === StaffType.NEW && Boolean(dto.approverTarget);
      const created = await tx.employee.create({
        data: {
          ...employeeData,
          email: loginEmail,
          staffType,
          relieverOnly: dto.relieverOnly ?? false,
          weeklyOffWeekdays: this.parseWeeklyOffWeekdays(dto.weeklyOffWeekdays),
          shiftId: resolvedShiftId,
          dutyStartTime: syncedDutyStart,
          dutyEndTime: syncedDutyEnd,
          dutyTotalHours: syncedDutyHours,
          employeeCode,
          joiningDate,
          dateOfBirth: new Date(dto.dateOfBirth),
          status: pendingApproval
            ? EmployeeStatus.PENDING_APPROVAL
            : EmployeeStatus.ACTIVE,
        },
      });

      await tx.employmentHistory.create({
        data: {
          employeeId: created.id,
          branchId: dto.currentBranchId,
          departmentId: dto.currentDepartmentId,
          designation: dto.currentDesignation,
          changeType: ChangeType.JOINED,
          effectiveDate: joiningDate,
        },
      });

      await tx.stipendRecord.create({
        data: {
          employeeId: created.id,
          basicStipend,
          allowances: allowances ?? 0,
          reward: reward ?? 0,
          progressReward: progressReward ?? 0,
          fuelAllowance: fuelAllowance ?? 0,
          loanDeduction: loanDeduction ?? 0,
          advanceDeduction: advanceDeduction ?? 0,
          fineDeduction: fineDeduction ?? 0,
          healthDeduction: healthDeduction ?? 0,
          lumpsumTotal,
          effectiveFrom: joiningDate,
        },
      });

      await this.createUserForEmployee(tx, {
        employeeId: created.id,
        employeeCode,
        email: loginEmail,
        designation: dto.currentDesignation,
        branchId: dto.currentBranchId,
        userRole: dto.userRole,
        isActive: !pendingApproval,
      });

      if (pendingApproval && dto.approverTarget && actingUser) {
        await tx.employeeOnboardingApproval.create({
          data: {
            employeeId: created.id,
            submittedById: actingUser.id,
            approverTarget: dto.approverTarget,
            status: EmployeeOnboardingStatus.PENDING,
            formSnapshot: (dto.formSnapshot ?? {
              ...dto,
              employeeCode: created.employeeCode,
            }) as Prisma.InputJsonValue,
          },
        });
      }

      return created;
    });

    await this.autoAssignBiometricId(employee.id);

    const result = await this.prisma.employee.findUnique({
      where: { id: employee.id },
      include: {
        currentBranch: { select: { name: true, address: true } },
        currentDepartment: { select: { name: true } },
        shift: true,
      },
    });

    if (result && actingUser) {
      await this.prisma.auditLog.create({
        data: {
          userId: actingUser.id,
          action: 'EMPLOYEE_CREATED',
          entity: 'Employee',
          entityId: result.id,
          changes: { fullName: result.fullName },
        },
      });
    }

    if (result) {
      try {
        if (
          result.staffType !== StaffType.EXISTING &&
          result.status === EmployeeStatus.ACTIVE
        ) {
          await this.lettersService.generateSystemLetter({
            employeeId: result.id,
            letterType: LetterType.APPOINTMENT,
            extraFields: appointmentExtraFieldsFromEmployee(
              result,
              dto.basicStipend,
            ),
          });
        }
      } catch (error) {
        const message =
          error instanceof Error ? error.message : 'Unknown error';
        console.error('Auto-letter generation failed:', message);
      }
    }

    return result;
  }

  async backfillUsers() {
    const employees = await this.prisma.employee.findMany({
      where: { user: null },
      select: {
        id: true,
        employeeCode: true,
        email: true,
      },
    });

    let created = 0;

    for (const employee of employees) {
      const loginEmail =
        employee.email || `${employee.employeeCode.toLowerCase()}@ycdo.org`;

      const existingUser = await this.prisma.user.findUnique({
        where: { email: loginEmail },
      });
      if (existingUser) {
        continue;
      }

      await this.prisma.$transaction(async (tx) => {
        if (!employee.email) {
          await tx.employee.update({
            where: { id: employee.id },
            data: { email: loginEmail },
          });
        }

        await this.createUserForEmployee(tx, {
          employeeId: employee.id,
          employeeCode: employee.employeeCode,
          email: loginEmail,
        });
      });

      created++;
    }

    return { created };
  }

  private isAdminManagerRole(
    designation: string,
    userRole?: string,
  ): boolean {
    if (userRole === 'ADMIN_MANAGER') return true;
    return designation === 'Admin Manager';
  }

  private async createUserForEmployee(
    tx: Prisma.TransactionClient,
    params: {
      employeeId: string;
      employeeCode: string;
      email: string;
      designation?: string;
      branchId?: string;
      userRole?: string;
      isActive?: boolean;
    },
  ) {
    const hashedPassword = await bcrypt.hash(params.employeeCode, 10);
    const isAdminManager = this.isAdminManagerRole(
      params.designation ?? '',
      params.userRole,
    );

    const newUser = await tx.user.create({
      data: {
        email: params.email,
        password: hashedPassword,
        role: isAdminManager ? UserRole.ADMIN_MANAGER : UserRole.EMPLOYEE,
        branchId: isAdminManager ? params.branchId : undefined,
        isActive: params.isActive ?? true,
        employeeId: params.employeeId,
      },
    });

    await tx.userPassword.upsert({
      where: { userId: newUser.id },
      update: { plainText: params.employeeCode },
      create: { userId: newUser.id, plainText: params.employeeCode },
    });

    return newUser;
  }

  private formatDate(date: Date): string {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }

  private privatePhotoPublicId(employeeId: string): string {
    return `ycdo-hrms/private-biometric/private_${employeeId}`;
  }

  private getSignedPrivatePhotoUrl(employeeId: string): string {
    return cloudinary.utils.private_download_url(
      this.privatePhotoPublicId(employeeId),
      'jpg',
      {
        resource_type: 'image',
        type: 'authenticated',
        expires_at: Math.floor(Date.now() / 1000) + 10 * 60,
        attachment: false,
      },
    );
  }

  private filterEmployeeForRole<
    T extends {
      id: string;
      photoUrl?: string | null;
      privatePhotoUrl?: string | null;
      hideProfilePhoto?: boolean;
      user?: {
        id: string;
        role?: UserRole;
        additionalRoles?: Array<{ role: UserRole }>;
      } | null;
    },
  >(employee: T, currentUserId?: string, _currentUserRole?: string) {
    const isOwner = employee.user?.id === currentUserId;
    const hasPrivatePhoto = Boolean(employee.privatePhotoUrl);

    return {
      ...employee,
      user: this.serializeUserRoles(employee.user),
      photoUrl:
        employee.hideProfilePhoto && !isOwner ? null : employee.photoUrl,
      privatePhotoUrl:
        isOwner && hasPrivatePhoto
          ? this.getSignedPrivatePhotoUrl(employee.id)
          : undefined,
      hasPrivatePhoto,
    };
  }

  async findAll(filters: EmployeeFilters, actingUser?: ActingUser) {
    enforceBranchScope(filters, actingUser);

    const where: Prisma.EmployeeWhereInput = {};
    const andConditions: Prisma.EmployeeWhereInput[] = [];

    if (isMedicineManagerRole(actingUser?.role)) {
      andConditions.push(medicineEmployeeWhere());
    }

    if (filters.branchId) {
      where.currentBranchId = filters.branchId;
    }

    const departmentDesignationWhere =
      this.accessScopeService.employeeMatchesDepartmentDesignationFilter({
        departmentId: filters.departmentId,
        designation: filters.designation,
      });
    if (departmentDesignationWhere) {
      andConditions.push(departmentDesignationWhere);
    }

    if (filters.projectId) {
      where.currentBranch = {
        ...(where.currentBranch as Prisma.BranchWhereInput | undefined),
        projectId: filters.projectId,
      };
    }

    if (filters.project) {
      where.currentBranch = {
        ...(where.currentBranch as Prisma.BranchWhereInput | undefined),
        project: { type: filters.project },
      };
    }

    if (filters.shiftName) {
      where.shift = {
        name: filters.shiftName,
        isActive: true,
      };
    } else if (filters.shiftIds) {
      const ids = filters.shiftIds.split(',').filter(Boolean);
      if (ids.length > 0) {
        where.shiftId = { in: ids };
      }
    } else if (filters.shiftId) {
      where.shiftId = filters.shiftId;
    }

    if (filters.statuses) {
      const parsed = filters.statuses
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean) as EmployeeStatus[];
      const valid = parsed.filter((s) =>
        Object.values(EmployeeStatus).includes(s),
      );
      if (valid.length > 0) {
        where.status = { in: valid };
      }
    } else if (filters.status) {
      where.status = filters.status;
    }

    if (filters.gender) {
      where.gender = filters.gender;
    }

    if (filters.widowOnly === 'true') {
      where.maritalStatus = MaritalStatus.WIDOW;
      where.gender = 'FEMALE';
    } else if (filters.maritalStatus) {
      where.maritalStatus = filters.maritalStatus;
    }

    if (filters.unassigned === 'true') {
      andConditions.push({
        OR: [{ currentDepartmentId: null }, { currentDesignation: null }],
      });
    }

    if (filters.district) {
      where.district = {
        equals: filters.district,
        mode: 'insensitive',
      };
    }

    if (filters.bloodGroup) {
      where.bloodGroup = filters.bloodGroup;
    }

    if (filters.search) {
      andConditions.push({
        OR: [
          { fullName: { contains: filters.search, mode: 'insensitive' } },
          {
            employeeCode: { contains: filters.search, mode: 'insensitive' },
          },
          { cnic: { contains: filters.search, mode: 'insensitive' } },
          {
            currentBranch: {
              name: { contains: filters.search, mode: 'insensitive' },
            },
          },
        ],
      });
    }

    if (filters.joinedFrom || filters.joinedTo) {
      where.joiningDate = {};
      if (filters.joinedFrom) {
        where.joiningDate.gte = new Date(filters.joinedFrom);
      }
      if (filters.joinedTo) {
        where.joiningDate.lte = new Date(filters.joinedTo);
      }
    }

    if (andConditions.length > 0) {
      where.AND = andConditions;
    }

    const scopedWhere = actingUser?.id
      ? await this.accessScopeService.narrowEmployeeWhereForActor(
          actingUser.id,
          actingUser.role as UserRole,
          where,
        )
      : where;

    if (filters.count === 'true') {
      const count = await this.prisma.employee.count({ where: scopedWhere });
      return { count };
    }

    const employees = await this.prisma.employee.findMany({
      where: scopedWhere,
      select: {
        id: true,
        employeeCode: true,
        fullName: true,
        currentDesignation: true,
        status: true,
        statusEffectiveFrom: true,
        joiningDate: true,
        dutyStartTime: true,
        dutyEndTime: true,
        gender: true,
        biometricId: true,
        photoUrl: true,
        privatePhotoUrl: true,
        hideProfilePhoto: true,
        user: {
          select: {
            id: true,
            role: true,
            additionalRoles: { select: { role: true } },
            managerScopes: this.managerScopeSelect(),
          },
        },
        currentBranch: {
          select: {
            id: true,
            name: true,
            address: true,
            abbreviation: true,
            projectId: true,
            project: { select: { id: true, name: true, type: true } },
          },
        },
        currentDepartment: { select: { name: true } },
        shift: {
          select: { id: true, name: true, startTime: true, endTime: true },
        },
      },
    });

    return employees
      .sort((a, b) => {
        const aPriority = getHierarchyPriority(a.currentDesignation);
        const bPriority = getHierarchyPriority(b.currentDesignation);
        if (aPriority !== bPriority) return aPriority - bPriority;
        return (a.fullName ?? '').localeCompare(b.fullName ?? '');
      })
      .map((employee) => {
        const filtered = this.filterEmployeeForRole(
          employee,
          actingUser?.id,
          actingUser?.role,
        );
        return filtered;
      });
  }

  async getStats() {
    const total = await this.prisma.employee.count();

    const byStatus = await this.prisma.employee.groupBy({
      by: ['status'],
      _count: { _all: true },
    });

    const unassigned = await this.prisma.employee.count({
      where: {
        OR: [{ currentDepartmentId: null }, { currentDesignation: null }],
      },
    });

    const employees = await this.prisma.employee.findMany({
      select: {
        currentBranch: {
          select: {
            project: { select: { id: true, name: true, type: true } },
          },
        },
      },
    });

    const projectCounts = new Map<
      string,
      { project: string; projectId: string | null; count: number }
    >();

    for (const employee of employees) {
      const project = employee.currentBranch?.project;
      const key = project?.id ?? 'unassigned';
      const existing = projectCounts.get(key);
      if (existing) {
        existing.count += 1;
      } else {
        projectCounts.set(key, {
          project: project?.name ?? 'Unassigned',
          projectId: project?.id ?? null,
          count: 1,
        });
      }
    }

    return {
      total,
      unassigned,
      byStatus: byStatus.map((row) => ({
        status: row.status,
        count: row._count._all,
      })),
      byProject: [...projectCounts.values()].sort((a, b) =>
        a.project.localeCompare(b.project),
      ),
    };
  }

  async getFilterOptions() {
    const [designationRows, districtRows] = await Promise.all([
      this.prisma.employee.findMany({
        select: { currentDesignation: true },
        distinct: ['currentDesignation'],
        orderBy: { currentDesignation: 'asc' },
      }),
      this.prisma.employee.findMany({
        where: { district: { not: null } },
        select: { district: true },
        distinct: ['district'],
        orderBy: { district: 'asc' },
      }),
    ]);

    return {
      designations: designationRows
        .map((row) => row.currentDesignation)
        .filter((value): value is string => !!value),
      districts: districtRows
        .map((row) => row.district)
        .filter((value): value is string => !!value),
    };
  }

  async findOne(id: string, actingUser?: Pick<ActingUser, 'id' | 'role'>) {
    const isEmployeeCode = id.startsWith('YCDO-');
    const employee = await this.prisma.employee.findUnique({
      where: isEmployeeCode ? { employeeCode: id } : { id },
      include: {
        currentBranch: true,
        currentDepartment: true,
        shift: true,
        stipendRecords: {
          where: { effectiveTo: null },
          orderBy: { effectiveFrom: 'desc' },
          take: 1,
        },
        employmentHistory: {
          orderBy: { createdAt: 'desc' },
          include: {
            branch: { select: { name: true, address: true } },
            department: { select: { name: true } },
          },
        },
        documents: true,
        academicQualifications: {
          orderBy: [{ qualType: 'asc' }, { createdAt: 'asc' }],
        },
        previousEmployments: {
          orderBy: { createdAt: 'desc' },
        },
        user: {
          select: {
            id: true,
            email: true,
            role: true,
            isActive: true,
            branchId: true,
            branch: { select: { name: true, address: true } },
            additionalRoles: { select: { role: true } },
            managerScopes: this.managerScopeSelect(),
          },
        },
      },
    });

    if (!employee) {
      throw new NotFoundException(`Employee not found`);
    }

    if (actingUser?.id) {
      const context = await this.accessScopeService.getActorContext(
        actingUser.id,
      );
      const roles = context.roles.length
        ? context.roles
        : [actingUser.role as UserRole];
      const isOwner = employee.user?.id === actingUser.id;
      const hasOrgWideStaffRole = roles.some((r) => r !== UserRole.EMPLOYEE);
      if (
        !context.isGlobal &&
        !isOwner &&
        !hasOrgWideStaffRole &&
        context.hasManagerScopes &&
        !this.accessScopeService.employeeMatchesScopes(
          employee,
          context.managerScopes,
        )
      ) {
        throw new ForbiddenException(
          'You do not have access to this employee within your hospital scope',
        );
      }
    }

    const filtered = this.filterEmployeeForRole(
      employee,
      actingUser?.id,
      actingUser?.role,
    );
    const biometricRegistration =
      await this.faceSyncService.getBiometricRegistrationSummary(employee.id);

    return {
      ...filtered,
      biometricRegistration,
    };
  }

  /** Personal details of every employee matching the list filters, as .xlsx. */
  async exportPersonalDetails(filters: EmployeeFilters, actingUser: ActingUser) {
    // Reuse the list query so filters, access scope and ordering match the screen.
    const listed = (await this.findAll(
      { ...filters, count: undefined },
      actingUser,
    )) as Array<{ id: string }>;
    const rows = await this.prisma.employee.findMany({
      where: { id: { in: listed.map((e) => e.id) } },
      include: {
        currentBranch: { select: { name: true } },
        currentDepartment: { select: { name: true } },
        academicQualifications: { orderBy: { createdAt: 'asc' } },
        previousEmployments: { orderBy: { createdAt: 'asc' } },
      },
    });
    const byId = new Map(rows.map((r) => [r.id, r]));
    const ordered = listed.flatMap((e) => byId.get(e.id) ?? []);
    const stamp = new Date().toISOString().slice(0, 10);
    return {
      buffer: await buildEmployeesWorkbook(ordered),
      filename: `Employees-Personal-Details-${stamp}.xlsx`,
    };
  }

  /** Profile photo bytes (local upload or Cloudinary). Hidden photos stay owner-only. */
  async getPhotoFile(id: string, isOwner: boolean) {
    const employee = await this.prisma.employee.findUnique({
      where: { id },
      select: {
        employeeCode: true,
        fullName: true,
        photoUrl: true,
        hideProfilePhoto: true,
      },
    });
    if (!employee?.photoUrl || (employee.hideProfilePhoto && !isOwner)) {
      throw new NotFoundException('No profile photo available');
    }
    const base = safeFileName(`${employee.employeeCode}-${employee.fullName}`);
    const url = employee.photoUrl;

    if (/^https?:\/\//.test(url)) {
      const res = await fetch(url);
      if (!res.ok) throw new NotFoundException('No profile photo available');
      const ext =
        path.extname(new URL(url).pathname) ||
        (res.headers.get('content-type')?.includes('png') ? '.png' : '.jpg');
      return {
        body: Buffer.from(await res.arrayBuffer()),
        filename: `${base}-photo${ext}`,
      };
    }

    const fullPath = resolveUploadPath(url);
    return {
      body: fs.createReadStream(fullPath),
      filename: `${base}-photo${path.extname(fullPath)}`,
    };
  }

  async update(
    id: string,
    dto: UpdateEmployeeDto,
  ) {
    await this.findOne(id);

    const sanitizedDto = dto;

    if (sanitizedDto.currentBranchId !== undefined || sanitizedDto.currentDepartmentId !== undefined) {
      throw new BadRequestException(
        'Use the transfer endpoint to change branch or department',
      );
    }

    const data: Prisma.EmployeeUpdateInput = {};

    if (sanitizedDto.fullName !== undefined) data.fullName = sanitizedDto.fullName;
    if (sanitizedDto.fatherName !== undefined) data.fatherName = sanitizedDto.fatherName;
    if (sanitizedDto.phone !== undefined) data.phone = sanitizedDto.phone;
    if (sanitizedDto.email !== undefined) data.email = sanitizedDto.email;
    if (sanitizedDto.dateOfBirth !== undefined) {
      data.dateOfBirth = new Date(sanitizedDto.dateOfBirth);
    }
    if (sanitizedDto.joiningDate !== undefined) {
      data.joiningDate = new Date(sanitizedDto.joiningDate);
    }
    if (sanitizedDto.gender !== undefined) data.gender = sanitizedDto.gender;
    if (sanitizedDto.currentDesignation !== undefined) {
      data.currentDesignation = normalizeDesignationName(
        sanitizedDto.currentDesignation,
      );
    }
    if (sanitizedDto.fatherContactNumber !== undefined) {
      data.fatherContactNumber = sanitizedDto.fatherContactNumber;
    }
    if (sanitizedDto.emergencyContactName !== undefined) {
      data.emergencyContactName = sanitizedDto.emergencyContactName;
    }
    if (sanitizedDto.emergencyContactNumber !== undefined) {
      data.emergencyContactNumber = sanitizedDto.emergencyContactNumber;
    }
    if (sanitizedDto.spouseName !== undefined) {
      data.spouseName = sanitizedDto.spouseName;
    }
    if (sanitizedDto.spouseContactNumber !== undefined) {
      data.spouseContactNumber = sanitizedDto.spouseContactNumber;
    }
    if (sanitizedDto.caste !== undefined) data.caste = sanitizedDto.caste;
    if (sanitizedDto.domicile !== undefined) data.domicile = sanitizedDto.domicile;
    if (sanitizedDto.currentAddress !== undefined) {
      data.currentAddress = sanitizedDto.currentAddress;
    }
    if (sanitizedDto.permanentAddress !== undefined) {
      data.permanentAddress = sanitizedDto.permanentAddress;
    }
    if (sanitizedDto.district !== undefined) data.district = sanitizedDto.district;
    if (sanitizedDto.tehsil !== undefined) data.tehsil = sanitizedDto.tehsil;
    if (sanitizedDto.policeStation !== undefined) {
      data.policeStation = sanitizedDto.policeStation;
    }
    if (sanitizedDto.bloodGroup !== undefined) data.bloodGroup = sanitizedDto.bloodGroup;
    if (sanitizedDto.dutyStartTime !== undefined) data.dutyStartTime = sanitizedDto.dutyStartTime;
    if (sanitizedDto.dutyEndTime !== undefined) data.dutyEndTime = sanitizedDto.dutyEndTime;
    if (sanitizedDto.dutyTotalHours !== undefined) {
      data.dutyTotalHours = sanitizedDto.dutyTotalHours;
    }
    if (sanitizedDto.monthlyAllowedLeaves !== undefined) {
      data.monthlyAllowedLeaves = sanitizedDto.monthlyAllowedLeaves;
    }
    if (sanitizedDto.weeklyOffWeekdays !== undefined) {
      data.weeklyOffWeekdays = this.parseWeeklyOffWeekdays(
        sanitizedDto.weeklyOffWeekdays,
      );
    }
    if (sanitizedDto.province !== undefined) data.province = sanitizedDto.province;
    if (sanitizedDto.city !== undefined) data.city = sanitizedDto.city;
    if (sanitizedDto.permanentProvince !== undefined) {
      data.permanentProvince = sanitizedDto.permanentProvince;
    }
    if (sanitizedDto.permanentCity !== undefined) data.permanentCity = sanitizedDto.permanentCity;

    if (sanitizedDto.email) {
      const existingEmail = await this.prisma.employee.findFirst({
        where: { email: sanitizedDto.email, NOT: { id } },
      });
      if (existingEmail) {
        throw new ConflictException('Employee with this email already exists');
      }
    }

    if (sanitizedDto.cnic !== undefined) {
      if (sanitizedDto.cnic) {
        const existingCnic = await this.prisma.employee.findFirst({
          where: { cnic: sanitizedDto.cnic, NOT: { id } },
        });
        if (existingCnic) {
          throw new ConflictException('Employee with this CNIC already exists');
        }
      }
      data.cnic = sanitizedDto.cnic || null;
    }

    if (
      sanitizedDto.dutyStartTime !== undefined ||
      sanitizedDto.dutyEndTime !== undefined ||
      sanitizedDto.dutyTotalHours !== undefined
    ) {
      const employee = await this.findOne(id);
      const shiftId = await this.assignShiftFromDuty(
        sanitizedDto.dutyStartTime ?? employee.dutyStartTime,
        sanitizedDto.dutyEndTime ?? employee.dutyEndTime,
        sanitizedDto.dutyTotalHours ?? employee.dutyTotalHours,
      );
      if (shiftId) {
        data.shift = { connect: { id: shiftId } };
        const shift = await this.prisma.shift.findUnique({
          where: { id: shiftId },
        });
        if (shift) {
          data.dutyStartTime =
            sanitizedDto.dutyStartTime ?? shift.startTime;
          data.dutyEndTime = sanitizedDto.dutyEndTime ?? shift.endTime;
          data.dutyTotalHours =
            sanitizedDto.dutyTotalHours ??
            this.calculateShiftHours(
              data.dutyStartTime as string,
              data.dutyEndTime as string,
            );
        }
      }
    }

    if (sanitizedDto.shiftId !== undefined) {
      if (sanitizedDto.shiftId) {
        const shift = await this.ensureShiftExists(sanitizedDto.shiftId);
        data.shift = { connect: { id: shift.id } };
        data.dutyStartTime = shift.startTime;
        data.dutyEndTime = shift.endTime;
        data.dutyTotalHours = this.calculateShiftHours(
          shift.startTime,
          shift.endTime,
        );
      } else {
        data.shift = { disconnect: true };
      }
    }

    return this.prisma.employee.update({
      where: { id },
      data,
      include: {
        currentBranch: { select: { name: true, address: true } },
        currentDepartment: { select: { name: true } },
      },
    });
  }

  async transfer(id: string, dto: TransferDto) {
    const employee = await this.findOne(id);
    dto.currentDesignation = normalizeDesignationName(dto.currentDesignation);
    await this.ensureBranchExists(dto.currentBranchId);
    await this.ensureDepartmentExists(dto.currentDepartmentId);

    const effectiveDate = new Date(dto.effectiveDate);

    const dutyStartTime = this.normalizeOptionalDuty(dto.dutyStartTime);
    const dutyEndTime = this.normalizeOptionalDuty(dto.dutyEndTime);
    const dutyPayload: Prisma.EmployeeUncheckedUpdateInput = {
      currentBranchId: dto.currentBranchId,
      currentDepartmentId: dto.currentDepartmentId,
      currentDesignation: dto.currentDesignation,
    };
    if (dutyStartTime !== undefined) {
      dutyPayload.dutyStartTime = dutyStartTime;
    }
    if (dutyEndTime !== undefined) {
      dutyPayload.dutyEndTime = dutyEndTime;
    }
    if (dto.dutyTotalHours !== undefined) {
      dutyPayload.dutyTotalHours = dto.dutyTotalHours;
    }
    if (dto.monthlyAllowedLeaves !== undefined) {
      dutyPayload.monthlyAllowedLeaves = dto.monthlyAllowedLeaves;
    }

    if (
      !employee.relieverOnly &&
      (dto.dutyStartTime !== undefined ||
        dto.dutyEndTime !== undefined ||
        dto.dutyTotalHours !== undefined)
    ) {
      const nextStart = dutyStartTime ?? employee.dutyStartTime;
      const nextEnd = dutyEndTime ?? employee.dutyEndTime;
      const nextHours = dto.dutyTotalHours ?? employee.dutyTotalHours;
      const shiftId = await this.assignShiftFromDuty(
        nextStart,
        nextEnd,
        nextHours,
      );
      if (shiftId) {
        dutyPayload.shiftId = shiftId;
        const shift = await this.prisma.shift.findUnique({
          where: { id: shiftId },
        });
        if (shift) {
          dutyPayload.dutyStartTime = nextStart ?? shift.startTime;
          dutyPayload.dutyEndTime = nextEnd ?? shift.endTime;
          dutyPayload.dutyTotalHours =
            nextHours ??
            this.calculateShiftHours(
              String(dutyPayload.dutyStartTime),
              String(dutyPayload.dutyEndTime),
            );
        }
      }
    }

    await this.prisma.$transaction(async (tx) => {
      const openHistory = await tx.employmentHistory.findFirst({
        where: { employeeId: id, endDate: null },
        orderBy: { effectiveDate: 'desc' },
      });

      if (openHistory) {
        await tx.employmentHistory.update({
          where: { id: openHistory.id },
          data: { endDate: effectiveDate },
        });
      }

      await tx.employee.update({
        where: { id },
        data: dutyPayload,
      });

      await tx.employmentHistory.create({
        data: {
          employeeId: id,
          branchId: dto.currentBranchId,
          departmentId: dto.currentDepartmentId,
          designation: dto.currentDesignation,
          changeType: dto.changeType,
          changeReason: dto.changeReason,
          effectiveDate,
        },
      });
    });

    return this.prisma.employee.findUnique({
      where: { id: employee.id },
      include: {
        currentBranch: { select: { name: true, address: true } },
        currentDepartment: { select: { name: true } },
        employmentHistory: {
          orderBy: { createdAt: 'desc' },
          take: 2,
        },
      },
    });
  }

  async changeStatus(
    id: string,
    dto: ChangeStatusDto,
    actor?: { id: string; role?: UserRole | string; roles?: UserRole[] },
  ) {
    const employee = await this.findOne(id);
    const actorRoles = [
      ...(actor?.roles ?? []),
      ...(actor?.role ? [actor.role] : []),
    ] as UserRole[];
    const privilegedOverride = canOverrideSuspendedStatus(actor);
    const itAdminOverrideOnly =
      hasAnyRole(actorRoles, [UserRole.IT_ADMIN]) &&
      !hasAnyRole(actorRoles, [
        UserRole.SUPER_ADMIN,
        UserRole.HR_MANAGER,
        UserRole.HR_EXECUTIVE,
        UserRole.HR_ADMIN_MANAGER,
        UserRole.HR_OPERATIONS_MANAGER,
      ]);

    if (itAdminOverrideOnly && employee.status !== EmployeeStatus.SUSPENDED) {
      throw new ForbiddenException(
        'IT Admin can only use Change Status to take a staff member off Suspended.',
      );
    }

    if (employee.status === EmployeeStatus.DISMISSED) {
      throw new BadRequestException(
        'This employee has been dismissed and cannot change status. Dismissed employees are permanently barred from rejoining.',
      );
    }

    if (employee.status === EmployeeStatus.PENDING_APPROVAL) {
      throw new BadRequestException(
        'This employee is pending executive approval. Status can only change when the assigned approver (President, Founder, or Chairman) approves or rejects the onboarding request.',
      );
    }

    if (dto.status === EmployeeStatus.PENDING_APPROVAL) {
      throw new BadRequestException(
        'PENDING_APPROVAL can only be set through the Add Employee onboarding flow.',
      );
    }

    if (dto.status === EmployeeStatus.DISMISSED) {
      throw new BadRequestException(
        'Dismissed cannot be set from Change Status.',
      );
    }

    if (dto.status === EmployeeStatus.SUSPENDED) {
      throw new BadRequestException(
        'Status does not become Suspended from Change Status. Open inquiry from Letters → Watchlist (Start Inquiry). The employee stays Active until inquiry opening is approved.',
      );
    }

    if (
      employee.status === EmployeeStatus.SUSPENDED &&
      dto.status === EmployeeStatus.ACTIVE &&
      !privilegedOverride
    ) {
      throw new BadRequestException(
        'A suspended employee cannot be set ACTIVE from Change Status. Complete the inquiry, or ask Super Admin / IT Admin to override.',
      );
    }

    if (
      employee.status === EmployeeStatus.TRAINEE &&
      dto.status === EmployeeStatus.ACTIVE
    ) {
      const appointmentLetter = await this.prisma.letter.findFirst({
        where: {
          employeeId: id,
          letterType: LetterType.APPOINTMENT,
          status: LetterStatus.SENT,
        },
      });

      if (!appointmentLetter) {
        throw new BadRequestException({
          code: 'APPOINTMENT_LETTER_REQUIRED',
          message:
            'A sent Appointment Letter is required before activating this employee.',
        });
      }
    }

    const leavingSuspension =
      employee.status === EmployeeStatus.SUSPENDED && privilegedOverride;

    const data: Prisma.EmployeeUpdateInput =
      leavingSuspension && dto.status === EmployeeStatus.ACTIVE
        ? suspensionInquiryReinstatementData(new Date(), dto.statusEffectiveFrom)
        : {
            status: dto.status,
            statusEffectiveFrom: buildStatusEffectiveFromUpdate(
              dto.status,
              dto.statusEffectiveFrom,
            ),
          };

    const include = {
      currentBranch: { select: { name: true, address: true } },
      currentDepartment: { select: { name: true } },
    } as const;

    if (!leavingSuspension) {
      return this.prisma.$transaction(async (tx) => {
        const updated = await tx.employee.update({
          where: { id },
          data,
          include,
        });
        await syncEmployeePortalAccess(tx, id, dto.status);
        return updated;
      });
    }

    const now = new Date();
    const resolution = `Withdrawn by Super Admin / IT Admin status override (${dto.status}). ${dto.reason.trim()}`;

    return this.prisma.$transaction(async (tx) => {
      const updated = await tx.employee.update({
        where: { id },
        data,
        include,
      });

      await syncEmployeePortalAccess(tx, id, dto.status);

      const openCases = await tx.disciplinaryAction.findMany({
        where: {
          employeeId: id,
          type: DisciplinaryType.SUSPENSION,
          status: {
            in: [DisciplinaryStatus.OPEN, DisciplinaryStatus.UNDER_INQUIRY],
          },
        },
        select: { id: true },
      });

      if (openCases.length > 0) {
        const caseIds = openCases.map((row) => row.id);
        await tx.disciplinaryAction.updateMany({
          where: { id: { in: caseIds } },
          data: {
            status: DisciplinaryStatus.DISMISSED,
            resolvedAt: now,
            resolution,
          },
        });
        await tx.inquiry.updateMany({
          where: { disciplinaryActionId: { in: caseIds } },
          data: {
            closedAt: now,
            outcome: InquiryOutcome.DISMISSED,
            notes: resolution,
          },
        });
        await tx.suspensionRequest.updateMany({
          where: {
            disciplinaryActionId: { in: caseIds },
            status: {
              in: [
                SuspensionRequestStatus.DRAFT,
                SuspensionRequestStatus.PENDING_APPROVAL,
              ],
            },
          },
          data: { status: SuspensionRequestStatus.CANCELLED },
        });
      }

      if (actor?.id) {
        await tx.auditLog.create({
          data: {
            userId: actor.id,
            action: 'EMPLOYEE_STATUS_OVERRIDE',
            entity: 'Employee',
            entityId: id,
            changes: {
              from: employee.status,
              to: dto.status,
              reason: dto.reason.trim(),
            },
          },
        });
      }

      return updated;
    });
  }

  private async ensureShiftExists(shiftId: string) {
    const shift = await this.prisma.shift.findFirst({
      where: { id: shiftId, isActive: true },
    });

    if (!shift) {
      throw new NotFoundException(`Shift with id ${shiftId} not found`);
    }

    return shift;
  }

  private parseWeeklyOffWeekdays(raw?: number[] | null): number[] {
    try {
      return normalizeWeeklyOffWeekdays(raw);
    } catch (err) {
      throw new BadRequestException(
        err instanceof Error ? err.message : 'Invalid weekly off days',
      );
    }
  }

  private normalizeOptionalDuty(
    value?: string | null,
  ): string | undefined {
    if (value == null || value === '') return undefined;
    try {
      return normalizeDutyTimeToHhMm(value);
    } catch {
      // Keep original if unparseable — validation layer should catch bad input.
      return value.trim().substring(0, 5);
    }
  }

  private calculateShiftHours(
    startTime?: string | null,
    endTime?: string | null,
  ): number | undefined {
    if (!startTime || !endTime) return undefined;
    try {
      return hoursBetweenDutyTimes(startTime, endTime);
    } catch {
      return undefined;
    }
  }

  async syncDutyTimesFromShifts() {
    const employees = await this.prisma.employee.findMany({
      where: { shiftId: { not: null } },
      select: {
        id: true,
        shift: { select: { startTime: true, endTime: true } },
      },
    });

    let updated = 0;
    for (const emp of employees) {
      if (!emp.shift) continue;
      await this.prisma.employee.update({
        where: { id: emp.id },
        data: {
          dutyStartTime: emp.shift.startTime,
          dutyEndTime: emp.shift.endTime,
          dutyTotalHours: this.calculateShiftHours(
            emp.shift.startTime,
            emp.shift.endTime,
          ),
        },
      });
      updated++;
    }

    return {
      message: `Synced duty times for ${updated} employees`,
      updated,
      total: employees.length,
    };
  }

  private async assignShiftFromDuty(
    dutyStartTime?: string | null,
    dutyEndTime?: string | null,
    dutyTotalHours?: number | null,
  ): Promise<string | undefined> {
    const shiftName = inferShiftNameFromDuty(
      dutyStartTime,
      dutyEndTime,
      dutyTotalHours,
    );
    if (!shiftName || !dutyStartTime) {
      return undefined;
    }

    const { startTime, endTime } = this.defaultShiftTimes(
      shiftName,
      dutyStartTime,
      dutyEndTime,
      dutyTotalHours,
    );

    return this.resolveOrCreateShift(shiftName, startTime, endTime);
  }

  private defaultShiftTimes(
    shiftName: string,
    dutyStartTime: string,
    dutyEndTime?: string | null,
    dutyTotalHours?: number | null,
  ) {
    if (dutyTotalHours === 24 || shiftName === '24 Hours') {
      return { startTime: '00:00', endTime: '23:59' };
    }

    return {
      startTime: dutyStartTime,
      endTime: dutyEndTime ?? this.fallbackEndTime(shiftName),
    };
  }

  private fallbackEndTime(shiftName: string): string {
    switch (shiftName) {
      case 'Morning':
        return '14:00';
      case 'Evening':
        return '20:00';
      case 'Night':
        return '08:00';
      case '24 Hours':
        return '23:59';
      default:
        return '20:00';
    }
  }

  private async resolveOrCreateShift(
    shiftName: string,
    startTime: string,
    endTime: string,
  ): Promise<string> {
    const existing = await this.prisma.shift.findFirst({
      where: {
        name: shiftName,
        startTime,
        endTime,
        isActive: true,
      },
    });

    if (existing) {
      return existing.id;
    }

    const created = await this.prisma.shift.create({
      data: {
        name: shiftName,
        startTime,
        endTime,
        branchId: null,
      },
    });

    return created.id;
  }

  private async ensureBranchExists(branchId: string) {
    const branch = await this.prisma.branch.findFirst({
      where: { id: branchId, isActive: true },
    });

    if (!branch) {
      throw new NotFoundException(`Branch with id ${branchId} not found`);
    }
  }

  private async ensureDepartmentExists(departmentId: string) {
    const department = await this.prisma.department.findFirst({
      where: { id: departmentId, isActive: true, isDeleted: false },
    });

    if (!department) {
      throw new NotFoundException(
        `Department with id ${departmentId} not found`,
      );
    }
  }

  async getTotalWorkingHours(employeeId: string) {
    const employee = await this.prisma.employee.findUnique({
      where: { id: employeeId },
    });

    if (!employee) {
      throw new NotFoundException(`Employee with id ${employeeId} not found`);
    }

    const logs = await this.prisma.attendanceLog.findMany({
      where: {
        employeeId,
        checkIn: { not: null },
        checkOut: { not: null },
      },
      select: {
        checkIn: true,
        checkOut: true,
        date: true,
        status: true,
        dutyStartTimeSnapshot: true,
        dutyEndTimeSnapshot: true,
      },
    });

    const nonWorkStatuses = new Set<AttendanceStatus>([
      AttendanceStatus.ON_LEAVE,
      AttendanceStatus.ABSENT,
      AttendanceStatus.UNINFORMED_ABSENT,
      AttendanceStatus.HOLIDAY,
    ]);

    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);

    let totalMinutes = 0;
    let thisMonthMinutes = 0;
    let anomalies = 0;
    const daysWithHours = new Set<string>();

    for (const log of logs) {
      if (!log.checkIn || !log.checkOut) continue;
      if (log.status && nonWorkStatuses.has(log.status)) continue;

      const dayDuty = resolveAttendanceDutyTimes(log, employee);
      const win = getDutyWindow({
        dutyStartTime: dayDuty.dutyStartTime,
        dutyEndTime: dayDuty.dutyEndTime,
      });
      const { minutes, anomalous } = workedMinutes(
        log.checkIn,
        log.checkOut,
        win,
      );
      if (anomalous) {
        anomalies += 1;
        continue;
      }
      totalMinutes += minutes;
      daysWithHours.add(log.date.toISOString().split('T')[0]);

      if (log.date >= monthStart && log.date <= monthEnd) {
        thisMonthMinutes += minutes;
      }
    }

    const totalDays = daysWithHours.size;
    const totalHours = Math.round((totalMinutes / 60) * 100) / 100;
    const thisMonthHours = Math.round((thisMonthMinutes / 60) * 100) / 100;
    const averageDailyHours =
      totalDays > 0
        ? Math.round((totalHours / totalDays) * 100) / 100
        : 0;

    return {
      totalMinutes,
      totalHours,
      totalDays,
      thisMonthMinutes,
      thisMonthHours,
      averageDailyHours,
      anomalies,
    };
  }

  async updateBranchDuty(
    id: string,
    dto: UpdateBranchDutyDto,
    actingUserId: string,
  ) {
    const employee = await this.prisma.employee.findUnique({ where: { id } });

    if (!employee) {
      throw new NotFoundException(`Employee with id ${id} not found`);
    }

    const branchChanged =
      dto.currentBranchId !== undefined &&
      dto.currentBranchId !== employee.currentBranchId;

    const targetBranchId = dto.currentBranchId ?? employee.currentBranchId;

    if (dto.currentBranchId) {
      await this.ensureBranchExists(dto.currentBranchId);
    }

    if (dto.currentDepartmentId) {
      await this.ensureDepartmentExists(dto.currentDepartmentId);
    }

    const updated = await this.prisma.$transaction(async (tx) => {
      if (branchChanged && dto.currentBranchId) {
        await tx.employmentHistory.create({
          data: {
            employeeId: id,
            branchId: dto.currentBranchId,
            departmentId:
              dto.currentDepartmentId ?? employee.currentDepartmentId,
            designation: employee.currentDesignation,
            changeType: ChangeType.TRANSFERRED,
            effectiveDate: new Date(),
          },
        });
      }

      const data: Prisma.EmployeeUpdateInput = {};

      if (dto.currentBranchId !== undefined) {
        data.currentBranch = { connect: { id: dto.currentBranchId } };
      }
      if (dto.currentDepartmentId !== undefined) {
        data.currentDepartment = { connect: { id: dto.currentDepartmentId } };
      }
      if (dto.dutyStartTime !== undefined) {
        data.dutyStartTime = this.normalizeOptionalDuty(dto.dutyStartTime);
      }
      if (dto.dutyEndTime !== undefined) {
        data.dutyEndTime = this.normalizeOptionalDuty(dto.dutyEndTime);
      }
      if (dto.dutyTotalHours !== undefined) {
        data.dutyTotalHours = dto.dutyTotalHours;
      }
      if (dto.monthlyAllowedLeaves !== undefined) {
        data.monthlyAllowedLeaves = dto.monthlyAllowedLeaves;
      }
      if (dto.weeklyOffWeekdays !== undefined) {
        data.weeklyOffWeekdays = this.parseWeeklyOffWeekdays(
          dto.weeklyOffWeekdays,
        );
      }
      if (dto.relieverOnly !== undefined) {
        data.relieverOnly = dto.relieverOnly;
        // Reliever-only staff should not sit on a regular shift roster.
        if (dto.relieverOnly) {
          data.shift = { disconnect: true };
        }
      }

      const nextStart =
        this.normalizeOptionalDuty(dto.dutyStartTime) ??
        employee.dutyStartTime;
      const nextEnd =
        this.normalizeOptionalDuty(dto.dutyEndTime) ?? employee.dutyEndTime;
      const nextHours = dto.dutyTotalHours ?? employee.dutyTotalHours;
      const nextRelieverOnly =
        dto.relieverOnly !== undefined
          ? dto.relieverOnly
          : employee.relieverOnly;
      if (
        !nextRelieverOnly &&
        (dto.dutyStartTime !== undefined ||
          dto.dutyEndTime !== undefined ||
          dto.dutyTotalHours !== undefined)
      ) {
        const shiftId = await this.assignShiftFromDuty(
          nextStart,
          nextEnd,
          nextHours,
        );
        if (shiftId) {
          data.shift = { connect: { id: shiftId } };
          const shift = await this.prisma.shift.findUnique({
            where: { id: shiftId },
          });
          if (shift) {
            data.dutyStartTime = nextStart ?? shift.startTime;
            data.dutyEndTime = nextEnd ?? shift.endTime;
            data.dutyTotalHours =
              nextHours ??
              this.calculateShiftHours(
                data.dutyStartTime as string,
                data.dutyEndTime as string,
              );
          }
        }
      }

      const result = await tx.employee.update({
        where: { id },
        data,
        include: {
          currentBranch: { select: { name: true, address: true } },
          currentDepartment: { select: { name: true } },
        },
      });

      await tx.auditLog.create({
        data: {
          userId: actingUserId,
          action: 'UPDATE_BRANCH_DUTY',
          entity: 'Employee',
          entityId: id,
        },
      });

      return result;
    });

    return updated;
  }

  async uploadPhoto(id: string, file: Express.Multer.File) {
    await this.findOne(id);

    const photoUrl = isCloudinaryEnabled()
      ? await this.uploadPhotoToCloudinary(id, file)
      : `/uploads/photos/${id}/${file.filename}`;

    const updated = await this.prisma.employee.update({
      where: { id },
      data: { photoUrl },
      select: {
        id: true,
        photoUrl: true,
      },
    });

    await this.prisma.faceSyncJob.create({
      data: {
        employeeId: id,
        photoUrl,
        status: 'PENDING',
      },
    });

    return updated;
  }

  async uploadPrivatePhoto(
    id: string,
    file: Express.Multer.File,
    actingUserId: string,
  ) {
    const employee = await this.prisma.employee.findUnique({
      where: { id },
      select: {
        id: true,
        gender: true,
        user: { select: { id: true } },
      },
    });

    if (!employee) {
      throw new NotFoundException(`Employee with id ${id} not found`);
    }
    if (employee.user?.id !== actingUserId) {
      throw new ForbiddenException(
        'Only the employee can upload their private biometric photo',
      );
    }
    if (String(employee.gender).toUpperCase() !== 'FEMALE') {
      throw new BadRequestException(
        'Private biometric photos are available only to female staff',
      );
    }
    if (!isCloudinaryEnabled()) {
      throw new BadRequestException(
        'Private biometric photo storage is not configured',
      );
    }

    const tempFile = path.join(
      os.tmpdir(),
      `private-${id}-${Date.now()}.upload`,
    );

    try {
      fs.writeFileSync(tempFile, file.buffer);
      const upload = await cloudinary.uploader.upload(tempFile, {
        folder: 'ycdo-hrms/private-biometric',
        public_id: `private_${id}`,
        overwrite: true,
        invalidate: true,
        resource_type: 'image',
        type: 'authenticated',
        format: 'jpg',
        transformation: [
          { width: 1200, height: 1200, crop: 'limit' },
          { quality: 'auto:good' },
        ],
      });

      await this.prisma.employee.update({
        where: { id },
        data: { privatePhotoUrl: upload.secure_url },
      });
      await this.faceSyncService.createSyncJob(id, upload.secure_url);

      return {
        id,
        hasPrivatePhoto: true,
        privatePhotoUrl: this.getSignedPrivatePhotoUrl(id),
      };
    } finally {
      if (fs.existsSync(tempFile)) {
        fs.unlinkSync(tempFile);
      }
    }
  }

  async updateEmployeeRoles(
    employeeId: string,
    dto: UpdateEmployeeRolesDto,
    actingUser: { id: string; role: UserRole },
  ) {
    const actorRoles =
      await this.permissionsService.getUserEffectiveRoles(actingUser.id);
    if (!canAssignRoles(actorRoles.length ? actorRoles : [actingUser.role])) {
      throw new ForbiddenException(
        'Only HR, IT, or Super Admin can assign roles',
      );
    }

    const employee = await this.prisma.employee.findUnique({
      where: { id: employeeId },
      select: {
        id: true,
        user: {
          select: {
            id: true,
            role: true,
            additionalRoles: { select: { role: true } },
          },
        },
      },
    });

    if (!employee) {
      throw new NotFoundException(`Employee with id ${employeeId} not found`);
    }
    if (!employee.user) {
      throw new BadRequestException(
        'Employee does not have a login account yet',
      );
    }

    const primaryRole = dto.primaryRole ?? employee.user.role;
    // Preserve existing additional-role grants; hospital scopes replace the UI.
    const existingAdditional = (employee.user.additionalRoles ?? [])
      .map((entry) => entry.role)
      .filter((role) => role !== primaryRole);
    const allRoles = buildEffectiveRoles(primaryRole, existingAdditional);

    if (!allRoles.length) {
      throw new BadRequestException('At least one role is required');
    }

    const actorIsSuperAdmin = actorRoles.includes(UserRole.SUPER_ADMIN);
    if (
      allRoles.includes(UserRole.SUPER_ADMIN) &&
      !actorIsSuperAdmin
    ) {
      throw new ForbiddenException(
        'Only Super Admin can assign the Super Admin role',
      );
    }
    if (
      employee.user.role === UserRole.SUPER_ADMIN &&
      primaryRole !== UserRole.SUPER_ADMIN &&
      !actorIsSuperAdmin
    ) {
      throw new ForbiddenException(
        'Only Super Admin can change a Super Admin primary role',
      );
    }

    if (dto.managerScopes !== undefined) {
      await this.accessScopeService.replaceManagerScopes(
        employee.user.id,
        dto.managerScopes,
      );
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: employee.user!.id },
        data: { role: primaryRole },
      });
      // Drop any additional grant that now duplicates the primary role.
      if (primaryRole !== employee.user!.role) {
        await tx.userAdditionalRole.deleteMany({
          where: { userId: employee.user!.id, role: primaryRole },
        });
      }
      await tx.auditLog.create({
        data: {
          userId: actingUser.id,
          action: 'UPDATE_EMPLOYEE_ROLES',
          entity: 'User',
          entityId: employee.user!.id,
          changes: {
            employeeId,
            primaryRole,
            additionalRoles: existingAdditional,
            managerScopes: dto.managerScopes ?? null,
          } as unknown as Prisma.InputJsonValue,
        },
      });
    });

    return this.findOne(employeeId, actingUser);
  }

  async toggleHideProfilePhoto(
    id: string,
    hide: boolean,
    actingUserId: string,
  ) {
    const employee = await this.prisma.employee.findUnique({
      where: { id },
      select: { user: { select: { id: true } } },
    });

    if (!employee) {
      throw new NotFoundException(`Employee with id ${id} not found`);
    }
    if (employee.user?.id !== actingUserId) {
      throw new ForbiddenException(
        'Only the employee can change profile photo privacy',
      );
    }

    return this.prisma.employee.update({
      where: { id },
      data: { hideProfilePhoto: hide },
      select: { id: true, hideProfilePhoto: true },
    });
  }

  private async uploadPhotoToCloudinary(
    employeeId: string,
    file: Express.Multer.File,
  ): Promise<string> {
    const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
    const tempFile = path.join(os.tmpdir(), `${employeeId}-${Date.now()}${ext}`);

    try {
      if (file.buffer?.length) {
        fs.writeFileSync(tempFile, file.buffer);
      } else if (file.path) {
        fs.copyFileSync(file.path, tempFile);
      } else {
        throw new BadRequestException('No photo data');
      }

      const result = await cloudinary.uploader.upload(tempFile, {
        folder: 'ycdo-hrms/employees',
        public_id: employeeId,
        overwrite: true,
        resource_type: 'image',
        transformation: [
          { width: 800, height: 800, crop: 'limit' },
          { quality: 'auto', fetch_format: 'auto' },
        ],
      });

      return result.secure_url;
    } finally {
      if (fs.existsSync(tempFile)) {
        fs.unlinkSync(tempFile);
      }

      if (file.path && fs.existsSync(file.path)) {
        fs.unlinkSync(file.path);
      }
    }
  }

  async findActiveShiftEmployees(
    query: ActiveShiftQueryDto,
    actingUser?: BranchScopedUser,
  ) {
    const scopedQuery = { ...query }
    enforceBranchScope(scopedQuery, actingUser)

    const today = new Date(scopedQuery.date);
    today.setHours(0, 0, 0, 0);
    const currentMinutes = toPakistanMinutesOfDay(new Date());

    const andConditions: Prisma.EmployeeWhereInput[] = [];
    if (isMedicineManagerRole(actingUser?.role)) {
      andConditions.push(medicineEmployeeWhere());
    }

    const departmentDesignationWhere =
      this.accessScopeService.employeeMatchesDepartmentDesignationFilter({
        departmentId: scopedQuery.departmentId,
      });
    if (departmentDesignationWhere) {
      andConditions.push(departmentDesignationWhere);
    }

    const employees = await this.prisma.employee.findMany({
      where: {
        status: {
          in: [
            EmployeeStatus.ACTIVE,
            EmployeeStatus.TRAINEE,
          ],
        },
        ...(scopedQuery.branchId ? { currentBranchId: scopedQuery.branchId } : {}),
        ...(andConditions.length ? { AND: andConditions } : {}),
      },
      include: {
        shift: true,
        currentBranch: { select: { name: true, address: true } },
        currentDepartment: { select: { name: true } },
        attendanceLogs: { where: { date: today }, take: 1 },
        leaveRecords: {
          where: {
            status: LeaveStatus.APPROVED,
            startDate: { lte: today },
            endDate: { gte: today },
          },
        },
      },
    });

    return employees
      .filter((emp) => {
        if (emp.leaveRecords.length > 0) return false;

        const log = emp.attendanceLogs[0];
        if (log?.checkIn) return false;

        // Reliever-only staff have no roster; always show for manual mark.
        if (emp.relieverOnly) return true;

        const win = getDutyWindow(emp);
        if (!win) return false;

        return isOnDutyAt(win, currentMinutes, DUTY_FILTER_GRACE_MINUTES);
      })
      .map(({ attendanceLogs: _a, leaveRecords: _l, ...emp }) => emp);
  }

  async getNextBiometricId(): Promise<number> {
    const employees = await this.prisma.employee.findMany({
      where: { biometricId: { not: null } },
      select: { biometricId: true },
    });

    const maxId = employees.reduce((max, employee) => {
      const value = Number.parseInt(employee.biometricId || '0', 10);
      return Number.isNaN(value) ? max : Math.max(max, value);
    }, 0);

    const nextId = maxId + 1;
    if (nextId > 99999) {
      throw new BadRequestException(
        'Biometric ID limit reached (max 99999)',
      );
    }
    return nextId;
  }

  async autoAssignBiometricId(employeeId: string): Promise<number> {
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const nextId = await this.getNextBiometricId();
      try {
        await this.prisma.employee.update({
          where: { id: employeeId },
          data: { biometricId: String(nextId) },
        });
        return nextId;
      } catch (error) {
        const isDuplicate =
          error instanceof Prisma.PrismaClientKnownRequestError &&
          error.code === 'P2002';
        if (!isDuplicate || attempt === 4) {
          throw error;
        }
      }
    }

    throw new ConflictException('Could not allocate a unique biometric ID');
  }

  async getBiometricIdStats() {
    const [total, assigned] = await this.prisma.$transaction([
      this.prisma.employee.count(),
      this.prisma.employee.count({
        where: { biometricId: { not: null } },
      }),
    ]);

    return {
      total,
      assigned,
      unassigned: total - assigned,
    };
  }

  async getBiometricIdReference(actingUser?: ActingUser) {
    let where: Prisma.EmployeeWhereInput = { biometricId: { not: null } };
    if (actingUser?.id) {
      where = await this.accessScopeService.narrowEmployeeWhereForActor(
        actingUser.id,
        actingUser.role as UserRole,
        where,
      );
    }

    const employees = await this.prisma.employee.findMany({
      where,
      select: {
        id: true,
        employeeCode: true,
        fullName: true,
        biometricId: true,
        currentDesignation: true,
        status: true,
        currentBranch: { select: { name: true } },
      },
      orderBy: [{ currentBranchId: 'asc' }, { fullName: 'asc' }],
    });

    return employees.map(({ currentBranch, ...employee }) => ({
      ...employee,
      currentBranchName: currentBranch?.name ?? null,
    }));
  }

  async generateAllBiometricIds(actingUserId: string) {
    const total = await this.prisma.employee.count();
    if (total > 99999) {
      throw new BadRequestException(
        'Biometric ID limit reached (max 99999)',
      );
    }

    const result = await this.prisma.$transaction(
      async (tx) => {
        await tx.employee.updateMany({
          data: { biometricId: null },
        });

        const employees = await tx.employee.findMany({
          orderBy: [{ joiningDate: 'asc' }, { createdAt: 'asc' }],
          select: { id: true },
        });

        let counter = 1;
        for (const employee of employees) {
          await tx.employee.update({
            where: { id: employee.id },
            data: { biometricId: String(counter) },
          });
          counter += 1;
        }

        return {
          message: `Biometric IDs generated for ${employees.length} employees`,
          total: employees.length,
          range: employees.length > 0 ? `1 - ${counter - 1}` : 'No employees',
        };
      },
      { timeout: 60_000 },
    );

    await this.prisma.auditLog.create({
      data: {
        userId: actingUserId,
        action: 'BIOMETRIC_IDS_REGENERATED',
        entity: 'Employee',
        entityId: 'ALL',
        changes: {
          total: result.total,
          range: result.range,
        },
      },
    });

    return result;
  }

  private calculateLumpsumTotal(params: {
    basicStipend: number;
    allowances?: number;
    reward?: number;
    progressReward?: number;
    fuelAllowance?: number;
    loanDeduction?: number;
    advanceDeduction?: number;
    fineDeduction?: number;
    healthDeduction?: number;
  }): number {
    return (
      (params.basicStipend || 0) +
      (params.allowances || 0) +
      (params.reward || 0) +
      (params.progressReward || 0) +
      (params.fuelAllowance || 0) -
      (params.loanDeduction || 0) -
      (params.advanceDeduction || 0) -
      (params.fineDeduction || 0) -
      (params.healthDeduction || 0)
    );
  }

  async remove(id: string) {
    const employee = await this.prisma.employee.findUnique({
      where: { id },
      select: { id: true, fullName: true, employeeCode: true },
    });

    if (!employee) {
      throw new NotFoundException(`Employee with id ${id} not found`);
    }

    await withPayrollEmployeeTransaction(this.prisma, id, async (tx) => {
      const leaveIds = (
        await tx.leaveRecord.findMany({
          where: { employeeId: id },
          select: { id: true },
        })
      ).map((row) => row.id);

      if (leaveIds.length > 0) {
        await tx.leaveApproval.deleteMany({
          where: { leaveId: { in: leaveIds } },
        });
        await tx.relieverRequest.deleteMany({
          where: { leaveRecordId: { in: leaveIds } },
        });
      }

      await tx.relieverRequest.deleteMany({
        where: {
          OR: [{ requestedById: id }, { relieverId: id }],
        },
      });

      await tx.leaveRecord.deleteMany({ where: { employeeId: id } });

      const letterIds = (
        await tx.letter.findMany({
          where: { employeeId: id },
          select: { id: true },
        })
      ).map((row) => row.id);

      if (letterIds.length > 0) {
        await tx.allegationAcknowledgement.deleteMany({
          where: { letterId: { in: letterIds } },
        });
        await tx.letterReply.deleteMany({
          where: { letterId: { in: letterIds } },
        });
      }

      await tx.letterReply.deleteMany({ where: { employeeId: id } });
      await tx.allegationAcknowledgement.deleteMany({
        where: { employeeId: id },
      });
      await tx.letter.deleteMany({ where: { employeeId: id } });

      const disciplinaryIds = (
        await tx.disciplinaryAction.findMany({
          where: { employeeId: id },
          select: { id: true },
        })
      ).map((row) => row.id);

      if (disciplinaryIds.length > 0) {
        await tx.inquiry.deleteMany({
          where: { disciplinaryActionId: { in: disciplinaryIds } },
        });
      }

      await tx.disciplinaryAction.deleteMany({ where: { employeeId: id } });

      const stipendIds = (
        await tx.stipendRecord.findMany({
          where: { employeeId: id },
          select: { id: true },
        })
      ).map((row) => row.id);

      const payrollIds =
        stipendIds.length > 0
          ? (
              await tx.payrollEntry.findMany({
                where: { stipendRecordId: { in: stipendIds } },
                select: { id: true },
              })
            ).map((row) => row.id)
          : [];

      if (payrollIds.length > 0) {
        await tx.payrollDeduction.deleteMany({
          where: { payrollEntryId: { in: payrollIds } },
        });
        await tx.allowance.deleteMany({
          where: { payrollEntryId: { in: payrollIds } },
        });
        await tx.stipendReceipt.deleteMany({
          where: { payrollEntryId: { in: payrollIds } },
        });
        await tx.payrollEntry.deleteMany({
          where: { id: { in: payrollIds } },
        });
      }

      await tx.stipendReceipt.deleteMany({ where: { employeeId: id } });
      await tx.stipendRecord.deleteMany({ where: { employeeId: id } });
      await tx.portalAttendance.deleteMany({ where: { employeeId: id } });
      await tx.advanceLoanRequest.deleteMany({ where: { employeeId: id } });
      await tx.incentive.deleteMany({ where: { employeeId: id } });
      await tx.relieverSession.deleteMany({ where: { employeeId: id } });
      await tx.notification.deleteMany({ where: { employeeId: id } });
      await tx.attendanceLog.deleteMany({ where: { employeeId: id } });
      await tx.employeeDocument.deleteMany({ where: { employeeId: id } });
      await tx.academicQualification.deleteMany({ where: { employeeId: id } });
      await tx.previousEmployment.deleteMany({ where: { employeeId: id } });
      await tx.branchChangeRequest.deleteMany({ where: { employeeId: id } });
      await tx.employmentHistory.deleteMany({ where: { employeeId: id } });

      const user = await tx.user.findUnique({
        where: { employeeId: id },
        select: { id: true },
      });

      if (user) {
        await tx.leaveApproval.deleteMany({ where: { actionBy: user.id } });
        await tx.notificationBroadcast.deleteMany({
          where: { createdById: user.id },
        });
        await tx.incentive.deleteMany({ where: { addedBy: user.id } });
        await tx.auditLog.deleteMany({ where: { userId: user.id } });
        await tx.userPassword.deleteMany({ where: { userId: user.id } });
        await tx.user.delete({ where: { id: user.id } });
      }

      await tx.employee.delete({ where: { id } });
    });

    return {
      success: true,
      message: `Employee ${employee.employeeCode} (${employee.fullName}) deleted permanently`,
    };
  }

  private validateCreateDto(dto: CreateEmployeeDto) {
    const isExisting = dto.staffType === StaffType.EXISTING;

    // Father status drives which guardian contact is captured — required for
    // every staff type.
    if (!dto.fatherStatus) {
      throw new BadRequestException('Father status is required');
    }
    if (dto.fatherStatus === 'ALIVE' && !dto.fatherContactNumber) {
      throw new BadRequestException("Father's contact number is required");
    }
    if (dto.fatherStatus === 'DECEASED' && !dto.guardianContact) {
      throw new BadRequestException("Guardian's contact number is required");
    }
    if (!dto.emergencyRelation) {
      throw new BadRequestException('Emergency contact relation is required');
    }

    if (isExisting) {
      if (!dto.maritalStatus) {
        throw new BadRequestException('Marital status is required');
      }
      if (!dto.cnic) {
        throw new BadRequestException('CNIC is required');
      }
      if (!dto.dutyStartTime || !dto.dutyEndTime) {
        throw new BadRequestException('Duty hours are required');
      }
      if (dto.maritalStatus === MaritalStatus.MARRIED) {
        if (!dto.spouseName?.trim()) {
          throw new BadRequestException('Spouse name is required');
        }
        if (!dto.spouseContactNumber) {
          throw new BadRequestException('Spouse contact number is required');
        }
      }
      return;
    }

    if (!dto.cnic) {
      throw new BadRequestException('CNIC is required');
    }
    if (!dto.domicile) {
      throw new BadRequestException('Domicile is required');
    }
    if (!dto.permanentAddress) {
      throw new BadRequestException('Permanent address is required');
    }
    if (!dto.district) {
      throw new BadRequestException('District is required');
    }
    if (!dto.tehsil) {
      throw new BadRequestException('Tehsil is required');
    }
    if (!dto.policeStation) {
      throw new BadRequestException('Police station is required');
    }
    if (!dto.permanentProvince) {
      throw new BadRequestException('Permanent province is required');
    }
    if (!dto.permanentCity) {
      throw new BadRequestException('Permanent city is required');
    }
  }
}
