import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { EmployeeStatus } from '@prisma/client';

jest.mock('../letters/letters.service', () => ({
  LettersService: class LettersService {},
}));

jest.mock('../../config/cloudinary.config', () => ({
  cloudinary: {},
  isCloudinaryEnabled: () => false,
}));

import { EmployeesService } from './employees.service';

describe('EmployeesService.changeStatus', () => {
  function build(currentStatus: EmployeeStatus) {
    const prisma = {
      employee: {
        update: jest.fn().mockImplementation(({ data }) =>
          Promise.resolve({
            id: 'emp-1',
            status: data.status,
            currentBranch: { name: 'HQ', address: null },
            currentDepartment: { name: 'OPD' },
          }),
        ),
      },
      user: {
        updateMany: jest.fn().mockResolvedValue({ count: 1 }),
      },
      letter: {
        findFirst: jest.fn().mockResolvedValue(null),
      },
      $transaction: jest.fn(async (fn: (tx: unknown) => Promise<unknown>) =>
        fn(prisma),
      ),
    };
    const service = new EmployeesService(
      prisma as never,
      {} as never,
      {} as never,
      {} as never,
      {} as never,
    );
    jest.spyOn(service, 'findOne').mockResolvedValue({
      id: 'emp-1',
      status: currentStatus,
    } as never);
    return { service, prisma };
  }

  it('rejects manual ACTIVE → SUSPENDED and does not update the employee', async () => {
    const { service, prisma } = build(EmployeeStatus.ACTIVE);

    await expect(
      service.changeStatus('emp-1', {
        status: EmployeeStatus.SUSPENDED,
        reason: 'Manual suspend',
      }),
    ).rejects.toBeInstanceOf(BadRequestException);

    await expect(
      service.changeStatus('emp-1', {
        status: EmployeeStatus.SUSPENDED,
        reason: 'Manual suspend',
      }),
    ).rejects.toThrow(/Watchlist/i);

    expect(prisma.employee.update).not.toHaveBeenCalled();
  });

  it('allows an ordinary status change such as ACTIVE → ON_REST', async () => {
    const { service, prisma } = build(EmployeeStatus.ACTIVE);

    const result = await service.changeStatus('emp-1', {
      status: EmployeeStatus.ON_REST,
      reason: 'Rest day assignment',
    });

    expect(prisma.$transaction).toHaveBeenCalled();
    expect(prisma.employee.update).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: 'emp-1' },
        data: expect.objectContaining({
          status: EmployeeStatus.ON_REST,
          statusEffectiveFrom: expect.any(Date),
        }),
      }),
    );
    expect(result.status).toBe(EmployeeStatus.ON_REST);
  });

  it('rejects SUSPENDED → ACTIVE from Change Status', async () => {
    const { service, prisma } = build(EmployeeStatus.SUSPENDED);

    await expect(
      service.changeStatus('emp-1', {
        status: EmployeeStatus.ACTIVE,
        reason: 'Reinstated after review',
      }),
    ).rejects.toThrow(/Super Admin \/ IT Admin/i);

    expect(prisma.employee.update).not.toHaveBeenCalled();
  });

  it('rejects SUSPENDED → ACTIVE for HR even when an actor is passed', async () => {
    const { service, prisma } = build(EmployeeStatus.SUSPENDED);

    await expect(
      service.changeStatus(
        'emp-1',
        { status: EmployeeStatus.ACTIVE, reason: 'HR fix' },
        { id: 'hr-1', role: 'HR_MANAGER', roles: ['HR_MANAGER' as never] },
      ),
    ).rejects.toThrow(/Super Admin \/ IT Admin/i);

    expect(prisma.employee.update).not.toHaveBeenCalled();
  });

  it('lets Super Admin override SUSPENDED → ACTIVE and withdraws open inquiries', async () => {
    const { service, prisma } = build(EmployeeStatus.SUSPENDED);
    const tx = {
      employee: prisma.employee,
      user: prisma.user,
      disciplinaryAction: {
        findMany: jest.fn().mockResolvedValue([{ id: 'case-1' }]),
        updateMany: jest.fn().mockResolvedValue({ count: 1 }),
      },
      inquiry: { updateMany: jest.fn().mockResolvedValue({ count: 1 }) },
      suspensionRequest: {
        updateMany: jest.fn().mockResolvedValue({ count: 0 }),
      },
      auditLog: { create: jest.fn().mockResolvedValue({}) },
    };
    prisma.$transaction = jest.fn(async (fn: (t: typeof tx) => unknown) =>
      fn(tx),
    );

    const result = await service.changeStatus(
      'emp-1',
      { status: EmployeeStatus.ACTIVE, reason: 'HR opened inquiry by mistake' },
      {
        id: 'sa-1',
        role: 'SUPER_ADMIN',
        roles: ['SUPER_ADMIN' as never],
      },
    );

    expect(result.status).toBe(EmployeeStatus.ACTIVE);
    expect(prisma.employee.update.mock.calls[0][0].data).toEqual(
      expect.objectContaining({
        status: EmployeeStatus.ACTIVE,
        suspensionWatchBaselineOn: expect.any(Date),
      }),
    );
    expect(tx.disciplinaryAction.updateMany).toHaveBeenCalled();
    expect(tx.inquiry.updateMany).toHaveBeenCalled();
    expect(tx.auditLog.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          action: 'EMPLOYEE_STATUS_OVERRIDE',
        }),
      }),
    );
  });

  it('rejects IT Admin Change Status when the employee is not Suspended', async () => {
    const { service, prisma } = build(EmployeeStatus.ACTIVE);

    await expect(
      service.changeStatus(
        'emp-1',
        { status: EmployeeStatus.ON_REST, reason: 'IT change' },
        { id: 'it-1', role: 'IT_ADMIN', roles: ['IT_ADMIN' as never] },
      ),
    ).rejects.toBeInstanceOf(ForbiddenException);

    expect(prisma.employee.update).not.toHaveBeenCalled();
  });

  it('lets IT Admin override SUSPENDED → TERMINATED', async () => {
    const { service, prisma } = build(EmployeeStatus.SUSPENDED);
    const tx = {
      employee: prisma.employee,
      user: prisma.user,
      disciplinaryAction: {
        findMany: jest.fn().mockResolvedValue([]),
        updateMany: jest.fn(),
      },
      inquiry: { updateMany: jest.fn() },
      suspensionRequest: { updateMany: jest.fn() },
      auditLog: { create: jest.fn().mockResolvedValue({}) },
    };
    prisma.$transaction = jest.fn(async (fn: (t: typeof tx) => unknown) =>
      fn(tx),
    );

    const result = await service.changeStatus(
      'emp-1',
      { status: EmployeeStatus.TERMINATED, reason: 'Ops override' },
      { id: 'it-1', role: 'IT_ADMIN', roles: ['IT_ADMIN' as never] },
    );

    expect(result.status).toBe(EmployeeStatus.TERMINATED);
    expect(prisma.employee.update.mock.calls[0][0].data).toEqual(
      expect.objectContaining({
        status: EmployeeStatus.TERMINATED,
        statusEffectiveFrom: expect.any(Date),
      }),
    );
    expect(tx.disciplinaryAction.updateMany).not.toHaveBeenCalled();
  });

  it('still rejects ACTIVE → SUSPENDED for Super Admin', async () => {
    const { service, prisma } = build(EmployeeStatus.ACTIVE);

    await expect(
      service.changeStatus(
        'emp-1',
        { status: EmployeeStatus.SUSPENDED, reason: 'Manual suspend' },
        {
          id: 'sa-1',
          role: 'SUPER_ADMIN',
          roles: ['SUPER_ADMIN' as never],
        },
      ),
    ).rejects.toThrow(/Watchlist/i);

    expect(prisma.employee.update).not.toHaveBeenCalled();
  });

  it('blocks TRAINEE → ACTIVE with no Appointment letter', async () => {
    const { service, prisma } = build(EmployeeStatus.TRAINEE);
    prisma.letter.findFirst.mockResolvedValue(null);
    await expect(
      service.changeStatus('emp-1', {
        status: EmployeeStatus.ACTIVE,
        reason: 'Completed training',
      }),
    ).rejects.toThrow(/A sent Appointment Letter is required/);
    expect(prisma.employee.update).not.toHaveBeenCalled();
  });

  it('blocks TRAINEE → ACTIVE when only a DRAFT Appointment exists', async () => {
    const { service, prisma } = build(EmployeeStatus.TRAINEE);
    prisma.letter.findFirst.mockResolvedValue(null);
    await expect(
      service.changeStatus('emp-1', {
        status: EmployeeStatus.ACTIVE,
        reason: 'Completed training',
      }),
    ).rejects.toThrow(/A sent Appointment Letter is required/);
    expect(prisma.letter.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          status: 'SENT',
        }),
      }),
    );
  });

  it('blocks TRAINEE → ACTIVE when only an APPROVED Appointment exists', async () => {
    const { service, prisma } = build(EmployeeStatus.TRAINEE);
    prisma.letter.findFirst.mockResolvedValue(null);
    await expect(
      service.changeStatus('emp-1', {
        status: EmployeeStatus.ACTIVE,
        reason: 'Completed training',
      }),
    ).rejects.toThrow(/A sent Appointment Letter is required/);
    expect(prisma.letter.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          status: 'SENT',
        }),
      }),
    );
  });

  it('allows TRAINEE → ACTIVE when a SENT Appointment letter exists', async () => {
    const { service, prisma } = build(EmployeeStatus.TRAINEE);
    prisma.letter.findFirst.mockResolvedValue({ id: 'letter-sent' });
    const result = await service.changeStatus('emp-1', {
      status: EmployeeStatus.ACTIVE,
      reason: 'Completed training',
    });
    expect(result.status).toBe(EmployeeStatus.ACTIVE);
    expect(prisma.employee.update).toHaveBeenCalled();
  });

  it('blocks TRAINEE → ACTIVE when the only Appointment letter is REVERSED', async () => {
    const { service, prisma } = build(EmployeeStatus.TRAINEE);
    prisma.letter.findFirst.mockResolvedValue(null);
    await expect(
      service.changeStatus('emp-1', {
        status: EmployeeStatus.ACTIVE,
        reason: 'Completed training',
      }),
    ).rejects.toThrow(/A sent Appointment Letter is required/);
    expect(prisma.employee.update).not.toHaveBeenCalled();
  });

  it('ON_REST / RESIGNED / TERMINATED → ACTIVE does not set suspensionWatchBaselineOn', async () => {
    for (const from of [
      EmployeeStatus.ON_REST,
      EmployeeStatus.RESIGNED,
      EmployeeStatus.TERMINATED,
    ]) {
      const { service, prisma } = build(from);
      await service.changeStatus('emp-1', {
        status: EmployeeStatus.ACTIVE,
        reason: 'Return to duty',
      });
      expect(prisma.employee.update.mock.calls[0][0].data).toEqual({
        status: EmployeeStatus.ACTIVE,
        statusEffectiveFrom: null,
      });
      prisma.employee.update.mockClear();
    }
  });
});
