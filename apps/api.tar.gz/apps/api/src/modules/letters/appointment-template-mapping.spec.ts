import { AppointmentLetterLanguage } from '@prisma/client';
import { BadRequestException } from '@nestjs/common';
import {
  APPOINTMENT_MAPPING_MISSING_MESSAGE,
  resolveAppointmentTemplateMapping,
} from './appointment-template-mapping';

describe('resolveAppointmentTemplateMapping', () => {
  function db(opts: {
    designationId?: string | null;
    mappings: Array<{
      id: string;
      departmentId: string | null;
      designationId: string | null;
      language: AppointmentLetterLanguage;
      templateCode: string;
    }>;
  }) {
    return {
      designation: {
        findFirst: jest.fn().mockResolvedValue(
          opts.designationId ? { id: opts.designationId } : null,
        ),
      },
      appointmentTemplateMapping: {
        findFirst: jest.fn().mockImplementation(
          async ({
            where,
          }: {
            where: {
              departmentId: string | null;
              designationId: string | null;
            };
          }) =>
            opts.mappings.find(
              (row) =>
                row.departmentId === (where.departmentId ?? null) &&
                row.designationId === (where.designationId ?? null),
            ) ?? null,
        ),
      },
    };
  }

  it('resolves exact Department + Designation and language', async () => {
    const result = await resolveAppointmentTemplateMapping(
      db({
        designationId: 'des-1',
        mappings: [
          {
            id: 'map-1',
            departmentId: 'dept-a',
            designationId: 'des-1',
            language: AppointmentLetterLanguage.UR,
            templateCode: 'APPOINTMENT_FIXTURE_UR',
          },
        ],
      }),
      { departmentId: 'dept-a', designationTitle: 'Nurse' },
    );
    expect(result.match).toBe('EXACT');
    expect(result.language).toBe(AppointmentLetterLanguage.UR);
    expect(result.templateCode).toBe('APPOINTMENT_FIXTURE_UR');
  });

  it('matches the designation title ignoring case and extra spaces', async () => {
    const database = db({
      designationId: 'des-1',
      mappings: [
        {
          id: 'map-1',
          departmentId: 'dept-a',
          designationId: 'des-1',
          language: AppointmentLetterLanguage.EN,
          templateCode: 'APPT_LAB_SUPPORT_EN',
        },
      ],
    });
    const result = await resolveAppointmentTemplateMapping(database, {
      departmentId: 'dept-a',
      designationTitle: '  Lab   staff ',
    });
    expect(result.match).toBe('EXACT');
    expect(database.designation.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          title: { equals: 'Lab staff', mode: 'insensitive' },
          isDeleted: false,
        },
      }),
    );
  });

  it('rewrites a stored Lab Support Urdu mapping to the English family', async () => {
    const result = await resolveAppointmentTemplateMapping(
      db({
        designationId: 'des-lab',
        mappings: [
          {
            id: 'map-lab',
            departmentId: 'dept-lab',
            designationId: 'des-lab',
            language: AppointmentLetterLanguage.UR,
            templateCode: 'APPT_LAB_SUPPORT_UR',
          },
        ],
      }),
      { departmentId: 'dept-lab', designationTitle: 'LAB STAFF' },
    );
    expect(result.match).toBe('EXACT');
    expect(result.templateCode).toBe('APPT_LAB_SUPPORT_EN');
    expect(result.language).toBe(AppointmentLetterLanguage.EN);
  });

  it('uses department fallback then global, and fails closed', async () => {
    const dept = await resolveAppointmentTemplateMapping(
      db({
        designationId: 'des-1',
        mappings: [
          {
            id: 'map-d',
            departmentId: 'dept-a',
            designationId: null,
            language: AppointmentLetterLanguage.EN,
            templateCode: 'APPOINTMENT_FIXTURE_EN',
          },
        ],
      }),
      { departmentId: 'dept-a', designationTitle: 'Nurse' },
    );
    expect(dept.match).toBe('DEPARTMENT');

    const global = await resolveAppointmentTemplateMapping(
      db({
        designationId: 'des-1',
        mappings: [
          {
            id: 'map-g',
            departmentId: null,
            designationId: null,
            language: AppointmentLetterLanguage.EN,
            templateCode: 'APPOINTMENT_FIXTURE_EN',
          },
        ],
      }),
      { departmentId: 'dept-b', designationTitle: 'Nurse' },
    );
    expect(global.match).toBe('GLOBAL');

    await expect(
      resolveAppointmentTemplateMapping(
        db({ designationId: 'des-1', mappings: [] }),
        { departmentId: 'dept-a', designationTitle: 'Nurse' },
      ),
    ).rejects.toBeInstanceOf(BadRequestException);

    await expect(
      resolveAppointmentTemplateMapping(
        db({ designationId: 'des-1', mappings: [] }),
        { departmentId: 'dept-a', designationTitle: 'Nurse' },
      ),
    ).rejects.toThrow(APPOINTMENT_MAPPING_MISSING_MESSAGE);
  });
});
