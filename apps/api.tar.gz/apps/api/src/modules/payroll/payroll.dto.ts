import {
  AllowanceType,
  DeductionType,
  FineReason,
  PayrollStatus,
} from '@prisma/client';
import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  ArrayMinSize,
  Equals,
  IsArray,
  IsBoolean,
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  ValidateNested,
  IsUUID,
  Max,
  Min,
  ValidateIf,
} from 'class-validator';

export class CreatePayrollEntryDto {
  @IsUUID()
  @IsNotEmpty()
  employeeId: string;

  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(12)
  @IsNotEmpty()
  month: number;

  @Type(() => Number)
  @IsInt()
  @Min(2020)
  @IsNotEmpty()
  year: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  basicStipend?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  totalAllowances?: number;

  /** Allow create/refresh when employee is not ACTIVE or ON_REST (e.g. approved suspended). */
  @IsOptional()
  @IsBoolean()
  allowNonActive?: boolean;

  @ValidateIf((o: CreatePayrollEntryDto) => o.allowNonActive === true)
  @IsString()
  @IsNotEmpty()
  approvalReason?: string;
}

export class AddDeductionDto {
  @IsUUID()
  @IsNotEmpty()
  payrollEntryId: string;

  @IsEnum(DeductionType)
  @IsNotEmpty()
  reason: DeductionType;

  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  @IsNotEmpty()
  amount: number;

  @IsOptional()
  @IsString()
  description?: string;

  /** Only for FINE: the discipline cause (mobile on duty, uniform, ...). */
  @IsOptional()
  @IsEnum(FineReason)
  fineReason?: FineReason;
}

export class DeductionItemDto {
  @IsEnum(DeductionType)
  @IsNotEmpty()
  reason: DeductionType;

  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  amount: number;

  @IsOptional()
  @IsString()
  description?: string;

  /** Only for FINE: the discipline cause (mobile on duty, uniform, ...). */
  @IsOptional()
  @IsEnum(FineReason)
  fineReason?: FineReason;
}

export class UpdateDeductionDto {
  @IsOptional()
  @IsEnum(DeductionType)
  reason?: DeductionType;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  amount?: number;

  @IsOptional()
  @IsString()
  description?: string | null;
}

/** Several deduction causes for one payroll entry, saved together. */
export class AddDeductionsDto {
  @IsUUID()
  @IsNotEmpty()
  payrollEntryId: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => DeductionItemDto)
  items: DeductionItemDto[];
}

export class AddAllowanceDto {
  @IsUUID()
  @IsNotEmpty()
  payrollEntryId: string;

  @IsEnum(AllowanceType)
  @IsNotEmpty()
  type: AllowanceType;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  hours?: number;

  @ValidateIf((o: AddAllowanceDto) => o.hours == null)
  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  amount?: number;
}

export class ApplyOvertimeDto {
  @IsUUID()
  @IsNotEmpty()
  employeeId: string;

  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(12)
  @IsNotEmpty()
  month: number;

  @Type(() => Number)
  @IsInt()
  @Min(2020)
  @IsNotEmpty()
  year: number;
}

export class RecomputeMonthAllDto {
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(12)
  @IsNotEmpty()
  month: number;

  @Type(() => Number)
  @IsInt()
  @Min(2020)
  @IsNotEmpty()
  year: number;

  @IsOptional()
  @IsBoolean()
  dryRun?: boolean;

  /** Required, and must equal exactly 'RECOMPUTE_PENDING_PAYROLL', for any
   * request where dryRun is not true — see PayrollService.recomputeMonthAll. */
  @ValidateIf((o: RecomputeMonthAllDto) => o.dryRun !== true)
  @Equals('RECOMPUTE_PENDING_PAYROLL')
  confirm?: string;

  /** Unique-employee batch size (not PayrollEntry row count). Defaults to
   * 25 when omitted; capped at 50 to keep each call comfortably clear of
   * a 504 timeout. */
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(50)
  limit?: number;

  /** Unique-employee offset into the deterministically-sorted employee
   * list for this month/year — page through a large month via repeated
   * calls using the previous response's nextOffset. */
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  offset?: number;
}

export class ResetUnpaidPayrollDto {
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(12)
  @IsNotEmpty()
  month: number;

  @Type(() => Number)
  @IsInt()
  @Min(2020)
  @IsNotEmpty()
  year: number;

  @IsOptional()
  @IsUUID()
  branchId?: string;

  /** When true, clears unpaid payroll in every month, not only month/year. */
  @IsOptional()
  @IsBoolean()
  allUnpaidMonths?: boolean;

  @Equals('RESET_UNPAID_PAYROLL')
  confirm: 'RESET_UNPAID_PAYROLL';
}

export class RebuildPayrollDto {
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(12)
  @IsNotEmpty()
  month: number;

  @Type(() => Number)
  @IsInt()
  @Min(2020)
  @IsNotEmpty()
  year: number;

  @IsOptional()
  @IsUUID()
  branchId?: string;

  @Equals('REBUILD_PAYROLL')
  confirm: 'REBUILD_PAYROLL';

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(50)
  limit?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  offset?: number;
}

export class UpdatePayrollStatusDto {
  @IsEnum(PayrollStatus)
  @IsNotEmpty()
  status: PayrollStatus;
}

export class SalaryIncrementDto {
  @IsUUID()
  @IsNotEmpty()
  employeeId: string;

  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  @IsNotEmpty()
  basicStipend: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  allowances?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  reward?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  progressReward?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  fuelAllowance?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  loanDeduction?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  advanceDeduction?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  fineDeduction?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  healthDeduction?: number;

  @IsDateString()
  @IsNotEmpty()
  effectiveFrom: string;

  @IsString()
  @IsNotEmpty()
  reason: string;
}

/** Correct the open stipend in place. Does not start a new package. */
export class UpdateActiveStipendDto {
  @IsUUID()
  @IsNotEmpty()
  employeeId: string;

  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  @IsNotEmpty()
  basicStipend: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  allowances?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  reward?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  progressReward?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  fuelAllowance?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  loanDeduction?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  advanceDeduction?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  fineDeduction?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  healthDeduction?: number;

  /**
   * When omitted, amounts apply from the current month; older versions are preserved.
   * Optional explicit correction of the open package start date (e.g. move a raise
   * entered mid-month back to the 1st). Does not create a new package.
   * Prior package closed on the old start date is closed on this date instead.
   */
  @IsOptional()
  @IsDateString()
  effectiveFrom?: string;

  @IsOptional()
  @IsString()
  reason?: string;
}

export class PayrollQueryDto {
  @IsOptional()
  @IsUUID()
  employeeId?: string;

  @IsOptional()
  @IsUUID()
  branchId?: string;

  @IsOptional()
  @IsUUID()
  departmentId?: string;

  /** Employee.currentDesignation title (case-insensitive). */
  @IsOptional()
  @IsString()
  designation?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(12)
  month?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  year?: number;

  @IsOptional()
  @IsEnum(PayrollStatus)
  status?: PayrollStatus;
}

/** Payroll entries whose payslips are printed together (4 per A4 page). */
export class PayslipBatchDto {
  @IsArray()
  @ArrayMinSize(1)
  @ArrayMaxSize(1000)
  @IsUUID('all', { each: true })
  entryIds: string[];
}
