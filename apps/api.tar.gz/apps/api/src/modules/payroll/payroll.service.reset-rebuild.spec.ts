import { BadRequestException } from '@nestjs/common';
import { PayrollStatus } from '@prisma/client';
import { PayrollService } from './payroll.service';

jest.mock('../attendance/discipline.helper', () => ({
  repairLateDisciplineForPayrollMonth: jest.fn().mockResolvedValue({
    applied: 0,
    repaired: 0,
    skipped: 0,
  }),
}));

describe('PayrollService.resetUnpaidPayroll / rebuild', () => {
  const user = { id: 'user-1', role: 'SUPER_ADMIN' as const };

  it('rejects reset without the confirm token', async () => {
    const service = new PayrollService({} as any, {} as any);
    await expect(
      service.resetUnpaidPayroll(
        { month: 8, year: 2026, confirm: 'NOPE' as any },
        user,
      ),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('deletes unpaid entries and leaves PAID counted as skipped', async () => {
    const tx = {
      $queryRaw: jest.fn().mockResolvedValue([]),
      stipendReceipt: { deleteMany: jest.fn().mockResolvedValue({ count: 1 }) },
      payrollDeduction: { deleteMany: jest.fn().mockResolvedValue({ count: 2 }) },
      allowance: { deleteMany: jest.fn().mockResolvedValue({ count: 1 }) },
      payrollEntry: {
        findMany: jest
          .fn()
          // unpaid entries to clear
          .mockResolvedValueOnce([
            { id: 'pe-1', month: 8, year: 2026, stipendRecord: { employeeId: 'emp-1' } },
            { id: 'pe-2', month: 8, year: 2026, stipendRecord: { employeeId: 'emp-2' } },
          ])
          // surviving entries for those employee-months (emp-2 has a PAID sibling)
          .mockResolvedValueOnce([
            { month: 8, year: 2026, stipendRecord: { employeeId: 'emp-2' } },
          ]),
        count: jest.fn().mockResolvedValue(3),
        deleteMany: jest.fn().mockResolvedValue({ count: 2 }),
      },
      incentive: { deleteMany: jest.fn().mockResolvedValue({ count: 1 }) },
      auditLog: { create: jest.fn().mockResolvedValue({}) },
    };
    const prisma = {
      payrollEntry: {
        findMany: jest.fn().mockResolvedValue([{ stipendRecord: { employeeId: 'emp-1' } }, { stipendRecord: { employeeId: 'emp-2' } }]),
        count: jest.fn().mockResolvedValue(3),
      },
      $transaction: jest.fn(async (cb: (client: typeof tx) => Promise<void>) =>
        cb(tx),
      ),
    };
    const service = new PayrollService(prisma as any, {} as any);
    const result = await service.resetUnpaidPayroll(
      { month: 8, year: 2026, confirm: 'RESET_UNPAID_PAYROLL' },
      user,
    );

    expect(result.deleted).toBe(2);
    expect(result.paidSkipped).toBe(3);
    expect(prisma.payrollEntry.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          month: 8,
          year: 2026,
          status: {
            in: [PayrollStatus.PENDING, PayrollStatus.PROCESSED],
          },
        }),
      }),
    );
    expect(tx.payrollEntry.deleteMany).toHaveBeenCalled();
    expect(tx.incentive.deleteMany).toHaveBeenCalledWith({
      where: { OR: [{ employeeId: 'emp-1', month: 8, year: 2026 }] },
    });
    expect(result.incentivesDeleted).toBe(1);
    expect(tx.auditLog.create).toHaveBeenCalled();
  });

  it('rebuilds in employee batches and skips missing stipend packages', async () => {
    const prisma = {
      employee: {
        count: jest.fn().mockResolvedValue(2),
        findMany: jest.fn().mockResolvedValue([
          { id: 'emp-1', fullName: 'A', employeeCode: 'A1' },
          { id: 'emp-2', fullName: 'B', employeeCode: 'B1' },
        ]),
      },
    };
    const service = new PayrollService(prisma as any, {
      assertEmployeeAccess: jest.fn(),
    } as any);
    jest
      .spyOn(service, 'createOrGetEntry')
      .mockResolvedValueOnce({ id: 'ok' } as any)
      .mockRejectedValueOnce(
        new Error('No stipend record found covering 8/2026 for B (B1)'),
      );

    const result = await service.rebuildPayrollFromAttendanceAndLetters(
      { month: 8, year: 2026, confirm: 'REBUILD_PAYROLL', limit: 25, offset: 0 },
      user,
    );

    expect(result.generated).toBe(1);
    expect(result.skipped).toBe(1);
    expect(result.hasMore).toBe(false);
  });
});
