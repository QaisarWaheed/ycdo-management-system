/** Financial arithmetic only. All daily classification/quota/extras come from the Card. */
export type SalaryAttendanceCard = {
  calendarDays: number; present: number; absent: number; uninformedAbsent: number;
  late: number; halfDay: number; shortLeave: number; onLeave: number;
  paidLeaveDays: number; unpaidLeaveDays: number; holiday: number; swapCovered: number;
  unmarked: number; additionalWorkingDays: number; overtimeHours: number;
  /** Days checked out before duty end (own track, never counted as late). */
  earlyCheckout?: number;
  /** Days the employee did not check out (closed by the scheduler). */
  missingCheckout?: number;
  /** Leave days HR approved at 50% pay (part of onLeave, paid half). */
  halfPaidLeaveDays?: number;
};
const round = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
export function calculateCardSalary(card: SalaryAttendanceCard, basic: number, workingHours: number) {
  const counts: Array<keyof SalaryAttendanceCard> = ['calendarDays','present','absent','uninformedAbsent','late','halfDay','shortLeave','onLeave','paidLeaveDays','unpaidLeaveDays','holiday','swapCovered','unmarked','additionalWorkingDays','overtimeHours'];
  for (const key of counts) if (!Number.isFinite(card[key]) || card[key] < 0) throw new Error('Invalid Attendance Card value');
  if (!Number.isFinite(basic) || basic < 0 || !Number.isFinite(workingHours) || workingHours <= 0 || card.calendarDays < 1) throw new Error('Valid Basic Stipend and Working Hours required');
  const classifications = card.present + card.absent + card.uninformedAbsent + card.late + card.halfDay + card.shortLeave + card.onLeave + card.holiday + card.swapCovered + card.unmarked;
  if (classifications > card.calendarDays || card.paidLeaveDays + card.unpaidLeaveDays + (card.halfPaidLeaveDays ?? 0) !== card.onLeave) throw new Error('Attendance Card classifications/quota are inconsistent');
  const dailyRate = basic / card.calendarDays;
  const hourlyRate = dailyRate / workingHours;
  const paidDays = card.present + card.late + card.shortLeave + card.holiday + card.swapCovered + card.paidLeaveDays + (card.halfPaidLeaveDays ?? 0) * 0.5 + card.halfDay * 0.5;
  const earnedBasic = round(paidDays * dailyRate);
  const absencePenalty = round((card.absent + card.uninformedAbsent) * dailyRate);
  const latePenalty = round(Math.floor(card.late / 3) * dailyRate);
  // Same cadence as lateness, on its own count: every 3 early checkouts = 1 day.
  const earlyCheckoutPenalty = round(Math.floor((card.earlyCheckout ?? 0) / 3) * dailyRate);
  // Same cadence again for missed checkouts: every 3 = 1 day.
  const missingCheckoutPenalty = round(Math.floor((card.missingCheckout ?? 0) / 3) * dailyRate);
  const additionalWorkingDayPay = round(card.additionalWorkingDays * dailyRate);
  const overtimePay = round(card.overtimeHours * hourlyRate);
  return { dailyRate, hourlyRate, paidDays, earnedBasic, absencePenalty, latePenalty, earlyCheckoutPenalty, missingCheckoutPenalty, additionalWorkingDayPay, overtimePay,
    attendanceSalary: round(earnedBasic - absencePenalty - latePenalty - earlyCheckoutPenalty - missingCheckoutPenalty + additionalWorkingDayPay + overtimePay) };
}

/**
 * Salary is only calculated when the employee worked at least one day in the
 * month (Present, Late, Short Leave or Half Day). Leave, holidays or swaps
 * alone do not count — staff on rest for months must not draw a salary.
 */
export function hasPresenceInMonth(card: Pick<SalaryAttendanceCard, 'present' | 'late' | 'shortLeave' | 'halfDay'>): boolean {
  return card.present + card.late + card.shortLeave + card.halfDay > 0;
}

/** These categories now belong exclusively to the Card; legitimate unrelated fines remain. */
export function isLegacyAttendanceDeduction(row: { reason?: string; description?: string | null }) {
  if (['LATE_ARRIVAL', 'UNINFORMED_ABSENCE', 'UNPAID_LEAVE', 'HALF_DAY', 'EXTRA_LEAVE_REJECTED'].includes(row.reason ?? '')) return true;
  if (row.reason === 'DISCIPLINARY_FINE' && /^(Missing checkout deduction|Late arrival deduction|Early checkout deduction|Attendance Card: every 3 Early Checkout|Attendance Card: every 3 Missing Checkout)/.test(row.description ?? '')) return true;
  return row.reason === 'OTHER' && /^Unmarked day \(/.test(row.description ?? '');
}
export const CARD_ABSENCE_DESCRIPTION = 'Attendance Card: additional absence penalty';
export const CARD_LATE_DESCRIPTION = 'Attendance Card: every 3 Late';
export const CARD_EARLY_CHECKOUT_DESCRIPTION = 'Attendance Card: every 3 Early Checkout';
export const CARD_MISSING_CHECKOUT_DESCRIPTION = 'Attendance Card: every 3 Missing Checkout';
