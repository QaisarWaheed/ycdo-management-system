import { AttendanceLogType, AttendanceStatus, PayrollStatus } from '@prisma/client';
import { PayrollService } from './payroll.service';

jest.mock('../attendance/discipline.helper', () => ({
  repairLateDisciplineForPayrollMonth: jest.fn().mockResolvedValue({
    applied: 0,
    repaired: 0,
    skipped: 0,
  }),
}));

beforeAll(() => {
  jest.useFakeTimers({
    now: new Date('2026-09-15T07:00:00.000Z'),
    doNotFake: [
      'nextTick',
      'setImmediate',
      'setTimeout',
      'setInterval',
      'clearTimeout',
      'clearInterval',
      'performance',
      'queueMicrotask',
      'hrtime',
    ],
  });
});
afterAll(() => {
  jest.useRealTimers();
});

/**
 * Coverage for the new PERMANENT-behavior centralized hook,
 * recomputePendingPayrollForAttendanceDate — the single entry point every
 * attendance/leave/swap mutation path now calls after its own write
 * commits, so a PENDING PayrollEntry never goes stale the way the August
 * 2026 data did before Steps 1-6's one-time cleanup.
 *
 * This tests the hook's own logic exhaustively: month/year derivation
 * from the attendance business date (never wall-clock), the
 * never-auto-create guard, frozen (PROCESSED/PAID) segments staying
 * untouched, idempotency, and multi-segment correctness. It adds zero new
 * calculation logic of its own (delegates to the already-tested
 * recomputeEmployeeMonth — see payroll.service.segmentation.spec.ts), so
 * this suite is about the hook's own decision logic, not re-proving
 * payroll math already covered elsewhere.
 *
 * Uses the same in-memory FakeDb double as
 * payroll.service.segmentation.spec.ts, extended with
 * PayrollEntry.findFirst (the hook's own existence-check query).
 */

let idCounter = 0;
function newId(prefix: string) {
  idCounter++;
  return `${prefix}-${idCounter}`;
}

type FakeStipendRecord = {
  id: string;
  employeeId: string;
  basicStipend: number;
  allowances: number;
  reward: number;
  progressReward: number;
  fuelAllowance: number;
  loanDeduction: number;
  advanceDeduction: number;
  fineDeduction: number;
  healthDeduction: number;
  lumpsumTotal: number;
  effectiveFrom: Date;
  effectiveTo: Date | null;
};

type FakeAttendanceLog = {
  employeeId: string;
  type: AttendanceLogType;
  date: Date;
  checkIn: Date | null;
  checkOut: Date | null;
  status: AttendanceStatus;
  note: string | null;
  dutyStartTimeSnapshot: string | null;
  dutyEndTimeSnapshot: string | null;
};

type FakeDeduction = { id: string; payrollEntryId: string; reason: string; amount: number; description: string | null };
type FakeAllowance = { id: string; payrollEntryId: string; type: string; amount: number; hours: number | null; description: string | null };

type FakePayrollEntry = {
  id: string;
  stipendRecordId: string;
  month: number;
  year: number;
  status: PayrollStatus;
  basicStipend: number;
  totalAllowances: number;
  totalDeductions: number;
  netStipend: number;
  forcedNonActive: boolean;
};

class FakeDb {
  employees = new Map<string, any>();
  stipendRecords = new Map<string, FakeStipendRecord>();
  payrollEntries = new Map<string, FakePayrollEntry>();
  attendanceLogs: FakeAttendanceLog[] = [];
  additionalWorkingDays: Array<{ employeeId: string; date: Date; note: string | null }> = [];
  relieverSessions: Array<{ employeeId: string; date: Date; checkIn: Date; checkOut: Date | null; totalMinutes: number }> = [];
  deductions = new Map<string, FakeDeduction>();
  allowances = new Map<string, FakeAllowance>();
  auditLogs: any[] = [];
}

function inDateRange(date: Date, where: { gte?: Date; lte?: Date; lt?: Date }): boolean {
  if (where.gte && date.getTime() < where.gte.getTime()) return false;
  if (where.lte && date.getTime() > where.lte.getTime()) return false;
  if (where.lt && date.getTime() >= where.lt.getTime()) return false;
  return true;
}

function makeFakePrisma(db: FakeDb) {
  const prisma = {
    $queryRaw: jest.fn().mockResolvedValue([]),
    employee: {
      findUnique: async ({ where }: any) => db.employees.get(where.id) ?? null,
    },
    stipendRecord: {
      findMany: async ({ where }: any) => {
        const monthEndBound: Date = where.effectiveFrom.lte;
        const orClauses: any[] = where.OR;
        return [...db.stipendRecords.values()]
          .filter((r) => r.employeeId === where.employeeId)
          .filter((r) => r.effectiveFrom.getTime() <= monthEndBound.getTime())
          .filter((r) =>
            orClauses.some((clause) =>
              'effectiveTo' in clause && clause.effectiveTo === null
                ? r.effectiveTo === null
                : r.effectiveTo != null && r.effectiveTo.getTime() > clause.effectiveTo.gt.getTime(),
            ),
          )
          .sort((a, b) => a.effectiveFrom.getTime() - b.effectiveFrom.getTime());
      },
    },
    payrollEntry: {
      findFirst: async ({ where }: any) => [...db.payrollEntries.values()].find(e =>
        e.month === where.month && e.year === where.year &&
        (!where.stipendRecordId?.not || e.stipendRecordId !== where.stipendRecordId.not) &&
        (!where.status?.in || where.status.in.includes(e.status)) &&
        (!where.OR || where.OR.some((condition: any) => Object.entries(condition).every(([field, predicate]: [string, any]) => Number((e as any)[field]) > predicate.gt))) &&
        (!where.stipendRecord?.employeeId || db.stipendRecords.get(e.stipendRecordId)?.employeeId === where.stipendRecord.employeeId)
      ) ?? null,
      findUnique: async ({ where, include }: any) => {
        let entry: FakePayrollEntry | undefined;
        if (where.id) entry = db.payrollEntries.get(where.id);
        else if (where.stipendRecordId_month_year) {
          const { stipendRecordId, month, year } = where.stipendRecordId_month_year;
          entry = [...db.payrollEntries.values()].find(
            (e) => e.stipendRecordId === stipendRecordId && e.month === month && e.year === year,
          );
        }
        if (!entry) return null;
        return hydrate(entry, include);
      },
      create: async ({ data, include }: any) => {
        const entry: FakePayrollEntry = {
          id: newId('pe'),
          stipendRecordId: data.stipendRecordId,
          month: data.month,
          year: data.year,
          status: data.status,
          basicStipend: data.basicStipend,
          totalAllowances: data.totalAllowances,
          totalDeductions: data.totalDeductions,
          netStipend: data.netStipend,
          forcedNonActive: data.forcedNonActive ?? false,
        };
        db.payrollEntries.set(entry.id, entry);
        return hydrate(entry, include);
      },
      update: async ({ where, data, include }: any) => {
        const entry = db.payrollEntries.get(where.id)!;
        Object.assign(entry, data);
        return hydrate(entry, include);
      },
    },
    payrollDeduction: {
      findFirst: async ({ where }: any) =>
        [...db.deductions.values()].find((d) => d.payrollEntryId === where.payrollEntryId && (!where.reason || d.reason === where.reason)) ?? null,
      findMany: async ({ where }: any) =>
        [...db.deductions.values()].filter(
          (d) => d.payrollEntryId === where.payrollEntryId && (!where.reason || d.reason === where.reason),
        ),
      deleteMany: async ({ where }: any) => {
        const ids: string[] = where.id?.in ?? [];
        for (const id of ids) db.deductions.delete(id);
        return { count: ids.length };
      },
      create: async ({ data }: any) => {
        const d: FakeDeduction = { id: newId('ded'), ...data };
        db.deductions.set(d.id, d);
        return d;
      },
      update: async ({ where, data }: any) => {
        const d = db.deductions.get(where.id)!;
        Object.assign(d, data);
        return d;
      },
      delete: async ({ where }: any) => {
        const d = db.deductions.get(where.id)!;
        db.deductions.delete(where.id);
        return d;
      },
    },
    allowance: {
      findFirst: async ({ where }: any) =>
        [...db.allowances.values()].find((a) => a.payrollEntryId === where.payrollEntryId && a.type === where.type) ?? null,
      findMany: async ({ where }: any) =>
        [...db.allowances.values()].filter(
          (a) => a.payrollEntryId === where.payrollEntryId && a.type === where.type,
        ),
      deleteMany: async ({ where }: any) => {
        const ids: string[] = where.id?.in ?? [];
        for (const id of ids) db.allowances.delete(id);
        return { count: ids.length };
      },
      create: async ({ data }: any) => {
        const a: FakeAllowance = { id: newId('allow'), ...data };
        db.allowances.set(a.id, a);
        return a;
      },
      update: async ({ where, data }: any) => {
        const a = db.allowances.get(where.id)!;
        Object.assign(a, data);
        return a;
      },
      delete: async ({ where }: any) => {
        const a = db.allowances.get(where.id)!;
        db.allowances.delete(where.id);
        return a;
      },
    },
    leaveRecord: {
      findMany: async () => [],
    },
    attendanceLog: {
      findMany: async ({ where }: any) =>
        db.attendanceLogs
          .filter((l) => l.employeeId === where.employeeId)
          .filter((l) => !where.type || l.type === where.type)
          .filter((l) => !where.status || l.status === where.status)
          .filter((l) => inDateRange(l.date, where.date))
          .sort((a, b) => a.date.getTime() - b.date.getTime())
          .map(l => ({ overtimeMinutes: 0, lateMinutes: 0, overtimePending: false, overtimeApprovedAt: null, ...l })),
    },
    additionalWorkingDay: {
      findMany: async ({ where }: any) =>
        db.additionalWorkingDays
          .filter((d) => d.employeeId === where.employeeId)
          .filter((d) => inDateRange(d.date, where.date)),
    },
    relieverSession: {
      findMany: async ({ where }: any) =>
        db.relieverSessions
          .filter((s) => s.employeeId === where.employeeId)
          .filter((s) => inDateRange(s.date, where.date))
          .filter((s) => s.checkOut !== null),
    },
    letter: {
      findMany: async () => [],
    },
    auditLog: {
      create: async ({ data }: any) => {
        db.auditLogs.push(data);
        return data;
      },
    },
    $transaction: async (fn: any) => fn(prisma),
  };

  function hydrate(entry: FakePayrollEntry, include: any) {
    if (!include) return { ...entry };
    return {
      ...entry,
      ...(include.deductions ? { deductions: [...db.deductions.values()].filter((d) => d.payrollEntryId === entry.id) } : {}),
      ...(include.allowances ? { allowances: [...db.allowances.values()].filter((a) => a.payrollEntryId === entry.id) } : {}),
    };
  }

  return prisma;
}

function makeService(db: FakeDb) {
  const prisma = makeFakePrisma(db);
  const accessScopeService = { assertEmployeeAccess: jest.fn().mockResolvedValue(undefined) };
  return new PayrollService(prisma as any, accessScopeService as any);
}

function augustDate(day: number): Date {
  return new Date(Date.UTC(2026, 7, day, 0, 0, 0));
}
function septemberDate(day: number): Date {
  return new Date(Date.UTC(2026, 8, day, 0, 0, 0));
}
function pkTime(day: number, hours: number, minutes = 0): Date {
  return new Date(Date.UTC(2026, 7, day, hours - 5, minutes, 0));
}

const EMP_ID = 'emp-hook-1';

function seedEmployee(db: FakeDb, overrides: Partial<any> = {}) {
  db.employees.set(EMP_ID, {
    id: EMP_ID,
    status: 'ACTIVE',
    dutyTotalHours: 8,
    dutyStartTime: null,
    dutyEndTime: null,
    monthlyAllowedLeaves: null,
    relieverOnly: false,
    shift: null,
    ...overrides,
  });
  // Explicit stored fixture dates: production must never synthesize missing days.
  for (let day = 1; day <= 31; day++) seedPresentDay(db, day, AttendanceStatus.UNMARKED);
}

function seedStipend(db: FakeDb, basicStipend: number, effectiveFrom: Date, effectiveTo: Date | null): FakeStipendRecord {
  const r: FakeStipendRecord = {
    id: newId('sr'),
    employeeId: EMP_ID,
    basicStipend,
    allowances: 0,
    reward: 0,
    progressReward: 0,
    fuelAllowance: 0,
    loanDeduction: 0,
    advanceDeduction: 0,
    fineDeduction: 0,
    healthDeduction: 0,
    lumpsumTotal: basicStipend,
    effectiveFrom,
    effectiveTo,
  };
  db.stipendRecords.set(r.id, r);
  return r;
}

function seedPayrollEntry(db: FakeDb, stipendRecordId: string, month: number, year: number, status: PayrollStatus, overrides: Partial<FakePayrollEntry> = {}): FakePayrollEntry {
  const e: FakePayrollEntry = {
    id: newId('pe'),
    stipendRecordId,
    month,
    year,
    status,
    basicStipend: 0,
    totalAllowances: 0,
    totalDeductions: 0,
    netStipend: 0,
    forcedNonActive: false,
    ...overrides,
  };
  db.payrollEntries.set(e.id, e);
  return e;
}

function seedPresentDay(db: FakeDb, day: number, status: AttendanceStatus = AttendanceStatus.PRESENT) {
  db.attendanceLogs = db.attendanceLogs.filter(l => l.date.getTime() !== augustDate(day).getTime());
  db.attendanceLogs.push({
    employeeId: EMP_ID,
    type: AttendanceLogType.REGULAR,
    date: augustDate(day),
    checkIn: pkTime(day, 9, 0),
    checkOut: pkTime(day, 17, 0),
    status,
    note: null,
    dutyStartTimeSnapshot: null,
    dutyEndTimeSnapshot: null,
  });
}

const AUG_15 = new Date(Date.UTC(2026, 7, 15, 0, 0, 0));

describe('PayrollService.recomputePendingPayrollForAttendanceDate', () => {
  // Final stored statuses determine paid Basic.
  it('1: PENDING Basic grows only when a stored final day becomes paid', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    const sr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    seedPayrollEntry(db, sr.id, 8, 2026, PayrollStatus.PENDING, { basicStipend: 0, netStipend: 0 });
    const service = makeService(db);

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));
    const before = [...db.payrollEntries.values()][0];
    expect(before.basicStipend).toBe(0);

    seedPresentDay(db, 10);
    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));

    const after = [...db.payrollEntries.values()][0];
    expect(after.basicStipend).toBe(800);
  });

  // ABSENT loses its own pay and adds the Card absence penalty.
  it('2: PRESENT -> ABSENT removes paid Basic and adds one daily-rate penalty', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    const sr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    seedPayrollEntry(db, sr.id, 8, 2026, PayrollStatus.PENDING);
    seedPresentDay(db, 10);
    // A second worked day keeps the month payable (no salary at all with 0
    // present days), so only day 10's own change is measured.
    seedPresentDay(db, 11);
    const service = makeService(db);

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));
    const afterPresent = [...db.payrollEntries.values()][0].basicStipend;

    db.attendanceLogs.find((l) => l.date.getTime() === augustDate(10).getTime())!.status =
      AttendanceStatus.ABSENT;
    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));
    const afterAbsent = [...db.payrollEntries.values()][0].basicStipend;

    expect(afterPresent).toBe(1600);
    expect(afterAbsent).toBe(800);
    expect([...db.payrollEntries.values()][0].totalDeductions).toBe(800);
  });

  // 3. Historical August correction made later recomputes August, not the
  // "current" month — the hook has no wall-clock dependency at all; it
  // derives month/year purely from the passed attendanceDate.
  it('3: a historical August date recomputes ONLY the August PayrollEntry, a September entry is untouched', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    const sr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    const augEntry = seedPayrollEntry(db, sr.id, 8, 2026, PayrollStatus.PENDING, { basicStipend: 0, netStipend: 0 });
    const sepEntry = seedPayrollEntry(db, sr.id, 9, 2026, PayrollStatus.PENDING, { basicStipend: 12345, netStipend: 12345 });
    seedPresentDay(db, 10);
    const service = makeService(db);

    // Simulates: HR corrects an August 10 record while "today" is actually
    // in September — the hook is called with the August business date,
    // never a wall-clock "now".
    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));

    expect(db.payrollEntries.get(augEntry.id)!.basicStipend).toBe(800);
    expect(db.payrollEntries.get(sepEntry.id)!.basicStipend).toBe(12345);
  });

  it('6: a PROCESSED PayrollEntry is financially frozen when attendance changes', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    const sr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    const entry = seedPayrollEntry(db, sr.id, 8, 2026, PayrollStatus.PROCESSED, {
      basicStipend: 0,
      totalAllowances: 0,
      totalDeductions: 0,
      netStipend: 0,
    });
    seedPresentDay(db, 10);
    const before = { ...db.payrollEntries.get(entry.id)! };
    const service = makeService(db);

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));

    expect(db.payrollEntries.get(entry.id)).toEqual(before);
    expect(db.payrollEntries.get(entry.id)!.status).toBe(PayrollStatus.PROCESSED);
  });

  it('6c: recomputeEmployeeMonth does not rewrite PROCESSED financial totals', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    const sr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    const entry = seedPayrollEntry(db, sr.id, 8, 2026, PayrollStatus.PROCESSED, {
      basicStipend: 111,
      totalAllowances: 22,
      totalDeductions: 33,
      netStipend: 100,
    });
    seedPresentDay(db, 10);
    const before = { ...db.payrollEntries.get(entry.id)! };
    const service = makeService(db);

    const results = await service.recomputeEmployeeMonth({
      employeeId: EMP_ID,
      month: 8,
      year: 2026,
    });

    expect(results).toEqual([
      expect.objectContaining({ stipendRecordId: sr.id, status: 'FROZEN' }),
    ]);
    expect(db.payrollEntries.get(entry.id)).toEqual(before);
  });

  it('6b: PRESENT -> HALF_DAY earns half a daily rate without a separate deduction', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    const sr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    seedPayrollEntry(db, sr.id, 8, 2026, PayrollStatus.PENDING);
    seedPresentDay(db, 10);
    const service = makeService(db);

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));
    expect([...db.payrollEntries.values()][0].basicStipend).toBe(800);

    db.attendanceLogs.find((l) => l.date.getTime() === augustDate(10).getTime())!.status =
      AttendanceStatus.HALF_DAY;
    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));
    expect([...db.payrollEntries.values()][0].basicStipend).toBe(400);
    expect([...db.deductions.values()]).toHaveLength(0);
  });

  // 7. PAID payroll remains financially unchanged.
  it('7: a PAID PayrollEntry is never mutated by the hook', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    const sr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    const entry = seedPayrollEntry(db, sr.id, 8, 2026, PayrollStatus.PAID, { basicStipend: 24800, netStipend: 24800 });
    seedPresentDay(db, 10);
    const before = { ...db.payrollEntries.get(entry.id)! };
    const service = makeService(db);

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));

    expect(db.payrollEntries.get(entry.id)).toEqual(before);
  });

  // 8. No PayrollEntry -> no accidental payroll creation.
  it('8: an employee with no existing August PayrollEntry gets nothing created by the hook', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    seedPresentDay(db, 10);
    // Deliberately no seedPayrollEntry call.
    const service = makeService(db);

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));

    expect(db.payrollEntries.size).toBe(0);
  });

  // 9. Repeating the same attendance update remains idempotent.
  it('9: calling the hook repeatedly for the same unchanged state never duplicates rows or drifts totals', async () => {
    const db = new FakeDb();
    seedEmployee(db, { monthlyAllowedLeaves: 2 });
    const sr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    seedPayrollEntry(db, sr.id, 8, 2026, PayrollStatus.PENDING);
    seedPresentDay(db, 10);
    db.additionalWorkingDays.push({ employeeId: EMP_ID, date: augustDate(20), note: null });
    const service = makeService(db);

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));
    const first = { ...[...db.payrollEntries.values()][0] };

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));
    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));
    const third = { ...[...db.payrollEntries.values()][0] };

    expect(third).toEqual(first);
    expect(db.payrollEntries.size).toBe(1); // no duplicate entries
    const awdAllowances = [...db.allowances.values()].filter((a) => a.type === 'ADDITIONAL_WORKING_DAYS');
    expect(awdAllowances).toHaveLength(1); // no duplicate allowance rows across 3 calls
  });

  // The package-bearing entry owns the whole monthly Card.
  it('10: the package-bearing segment owns the whole Card month and old Basic stays zero', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    const oldSr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), AUG_15);
    const newSr = seedStipend(db, 27900, AUG_15, null);
    const oldEntry = seedPayrollEntry(db, oldSr.id, 8, 2026, PayrollStatus.PENDING);
    const newEntry = seedPayrollEntry(db, newSr.id, 8, 2026, PayrollStatus.PENDING);
    // Full month present in both segments' windows.
    for (let day = 1; day <= 31; day++) seedPresentDay(db, day);
    const service = makeService(db);

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(5)); // OLD segment's window

    // 2026-09-04 rule: a mid-month package change pays the new rate for
    // the WHOLE month, no blending — the closed OLD segment earns 0 Basic
    // and the active NEW segment earns the full contractual amount.
    expect(db.payrollEntries.get(oldEntry.id)!.basicStipend).toBe(0);
    expect(db.payrollEntries.get(newEntry.id)!.basicStipend).toBe(27900);
  });

  // Additional: hook never even queries StipendRecord/AttendanceLog beyond
  // the existence check when no entry exists — confirms the "avoid
  // unnecessary recomputation" requirement, not just "no creation".
  it('extra: when no PayrollEntry exists, recomputeEmployeeMonth is never invoked at all', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    const service = makeService(db);
    const spy = jest.spyOn(service, 'recomputeEmployeeMonth');

    await service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10));

    expect(spy).not.toHaveBeenCalled();
  });

  it('extra: never throws even if the underlying recompute fails', async () => {
    const db = new FakeDb();
    seedEmployee(db);
    const sr = seedStipend(db, 24800, new Date(Date.UTC(2000, 0, 1)), null);
    seedPayrollEntry(db, sr.id, 8, 2026, PayrollStatus.PENDING);
    const service = makeService(db);
    jest.spyOn(service, 'recomputeEmployeeMonth').mockRejectedValue(new Error('boom'));

    await expect(
      service.recomputePendingPayrollForAttendanceDate(EMP_ID, augustDate(10)),
    ).resolves.toBeUndefined();
  });
});
