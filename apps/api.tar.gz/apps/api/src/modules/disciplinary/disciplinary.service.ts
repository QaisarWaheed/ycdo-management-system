import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  DisciplinaryStatus,
  DisciplinaryType,
  EmployeeStatus,
  InquiryFinalAction,
  InquiryFinalDecisionStatus,
  InquiryOutcome,
  LetterStatus,
  LetterType,
  Permission,
  Prisma,
  SuspensionRequestStatus,
  UserRole,
} from '@prisma/client';
import { suspensionInquiryReinstatementData } from '../attendance/suspension-watch-baseline.util';
import { PrismaService } from '../../prisma/prisma.service';
import { AccessScopeService } from '../permissions/access-scope.service';
import { LettersService } from '../letters/letters.service';
import {
  expectedFinalLetters,
  matchFinalLetterStatuses,
} from './inquiry-final-letters';
import {
  CreateDisciplinaryDto,
  DisciplinaryQueryDto,
  ResolveInquiryDto,
  StartInquiryDto,
} from './disciplinary.dto';

@Injectable()
export class DisciplinaryService {
  constructor(
    private prisma: PrismaService,
    private lettersService: LettersService,
    private accessScopeService: AccessScopeService,
  ) {}

  async create(
    dto: CreateDisciplinaryDto,
    actingUserId: string,
    actingRole: UserRole = UserRole.HR_MANAGER,
  ) {
    await this.accessScopeService.assertEmployeeAccess(
      actingUserId,
      actingRole,
      Permission.DISCIPLINARY_MANAGE,
      dto.employeeId,
    );

    const employee = await this.prisma.employee.findUnique({
      where: { id: dto.employeeId },
      include: {
        currentDepartment: { select: { name: true } },
      },
    });

    if (!employee) {
      throw new NotFoundException(
        `Employee with id ${dto.employeeId} not found`,
      );
    }

    if (
      employee.status !== EmployeeStatus.ACTIVE &&
      employee.status !== EmployeeStatus.SUSPENDED
    ) {
      throw new BadRequestException(
        'Disciplinary action can only be issued to active or suspended employees',
      );
    }

    if (dto.type === DisciplinaryType.SUSPENSION) {
      const existing = await this.prisma.disciplinaryAction.findFirst({
        where: {
          employeeId: dto.employeeId,
          type: DisciplinaryType.SUSPENSION,
          status: {
            in: [DisciplinaryStatus.OPEN, DisciplinaryStatus.UNDER_INQUIRY],
          },
        },
        select: { id: true },
      });
      if (existing) {
        throw new BadRequestException(
          'This employee already has an open suspension case in Disciplinary Actions. Continue that case (Prepare → Approve → Send) instead of opening another.',
        );
      }
    }

    const issuedAt = dto.issuedAt ? new Date(dto.issuedAt) : new Date();

    const action = await this.prisma.$transaction(async (tx) => {
      const disciplinaryAction = await tx.disciplinaryAction.create({
        data: {
          employeeId: dto.employeeId,
          type: dto.type,
          reason: dto.reason,
          issuedAt,
        },
      });

      await tx.notification.create({
        data: {
          employeeId: dto.employeeId,
          type: 'DISCIPLINARY_ACTION',
          message: `A ${dto.type.toLowerCase().replace('_', ' ')} disciplinary action has been issued against you.`,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: actingUserId,
          action: 'DISCIPLINARY_CREATED',
          entity: 'DisciplinaryAction',
          entityId: disciplinaryAction.id,
          changes: { type: dto.type, reason: dto.reason },
        },
      });

      return disciplinaryAction;
    });

    await this.generateLetterForDisciplinary(
      dto.employeeId,
      dto.type,
      dto.reason,
      issuedAt,
      actingUserId,
      action.id,
    );

    return action;
  }

  async findAll(
    query: DisciplinaryQueryDto,
    actingUser?: { id: string; role: UserRole },
    repaired = false,
  ) {
    const where: Prisma.DisciplinaryActionWhereInput = {};

    if (query.employeeId) {
      where.employeeId = query.employeeId;
    }

    if (query.type) {
      where.type = query.type;
    }

    if (query.status) {
      where.status = query.status;
    }

    if (query.startDate && query.endDate) {
      where.issuedAt = {
        gte: new Date(query.startDate),
        lte: new Date(query.endDate),
      };
    }

    if (actingUser?.id) {
      where.employee =
        await this.accessScopeService.narrowEmployeeWhereForActor(
          actingUser.id,
          actingUser.role,
          {},
        );
    }

    const rows = await this.prisma.disciplinaryAction.findMany({
      where,
      include: {
        employee: {
          select: {
            id: true,
            fullName: true,
            employeeCode: true,
            status: true,
          },
        },
        inquiry: {
          include: {
            inquiryOfficer: {
              select: {
                id: true,
                email: true,
                employee: {
                  select: {
                    fullName: true,
                    phone: true,
                    currentDesignation: true,
                  },
                },
              },
            },
            findingRecordedBy: {
              select: {
                id: true,
                email: true,
                employee: { select: { fullName: true } },
              },
            },
            selectedFinalApprover: {
              select: {
                id: true,
                email: true,
                employee: { select: { fullName: true } },
              },
            },
            finalDecidedBy: {
              select: {
                id: true,
                email: true,
                employee: { select: { fullName: true } },
              },
            },
            destinationBranch: {
              select: { id: true, name: true, abbreviation: true },
            },
          },
        },
        suspensionRequest: {
          select: {
            id: true,
            status: true,
            letterId: true,
            decisionNote: true,
            suspendedFromBranchId: true,
            selectedApprover: {
              select: {
                id: true,
                email: true,
                employee: { select: { fullName: true } },
              },
            },
          },
        },
      },
      orderBy: { issuedAt: 'desc' },
    });

    const missingInquiry = rows.filter(
      (row) =>
        !row.inquiry &&
        (row.status === DisciplinaryStatus.UNDER_INQUIRY ||
          (row.type === DisciplinaryType.SUSPENSION &&
            row.status === DisciplinaryStatus.OPEN)),
    );
    if (missingInquiry.length > 0 && !repaired) {
      for (const action of missingInquiry) {
        await this.ensureInquiryForAction(action);
      }
      return this.findAll(query, actingUser, true);
    }

    return this.withFinalLetterStatuses(rows);
  }

  async findOne(id: string) {
    const action = await this.prisma.disciplinaryAction.findUnique({
      where: { id },
      include: {
        employee: {
          select: {
            id: true,
            fullName: true,
            employeeCode: true,
            currentDesignation: true,
            status: true,
          },
        },
        inquiry: {
          include: {
            inquiryOfficer: {
              select: {
                id: true,
                email: true,
                employee: {
                  select: {
                    fullName: true,
                    phone: true,
                    currentDesignation: true,
                  },
                },
              },
            },
            findingRecordedBy: {
              select: {
                id: true,
                email: true,
                employee: { select: { fullName: true } },
              },
            },
            selectedFinalApprover: {
              select: {
                id: true,
                email: true,
                employee: { select: { fullName: true } },
              },
            },
            finalDecidedBy: {
              select: {
                id: true,
                email: true,
                employee: { select: { fullName: true } },
              },
            },
            destinationBranch: {
              select: { id: true, name: true, abbreviation: true },
            },
          },
        },
        suspensionRequest: {
          select: {
            id: true,
            status: true,
            letterId: true,
            decisionNote: true,
            suspendedFromBranchId: true,
            selectedApprover: {
              select: {
                id: true,
                email: true,
                employee: { select: { fullName: true } },
              },
            },
          },
        },
      },
    });

    if (!action) {
      throw new NotFoundException(
        `Disciplinary action with id ${id} not found`,
      );
    }

    const [annotated] = await this.withFinalLetterStatuses([action]);
    return annotated;
  }

  async ensureInquiry(actionId: string) {
    const existing = await this.prisma.inquiry.findUnique({
      where: { disciplinaryActionId: actionId },
    });
    if (existing) return existing;

    const action = await this.prisma.disciplinaryAction.findUnique({
      where: { id: actionId },
      select: { id: true, issuedAt: true, reason: true },
    });
    if (!action) {
      throw new NotFoundException(
        `Disciplinary action with id ${actionId} not found`,
      );
    }

    await this.ensureInquiryForAction(action);

    const created = await this.prisma.inquiry.findUnique({
      where: { disciplinaryActionId: actionId },
    });
    if (!created) {
      throw new BadRequestException(
        'Could not create an inquiry for this disciplinary action',
      );
    }
    return created;
  }

  private async withFinalLetterStatuses<
    T extends {
      employeeId: string;
      inquiry?: {
        id: string;
        finding?: string | null;
        finalAction?: string | null;
        closedAt?: Date | string | null;
        finalDecisionStatus?: string | null;
      } | null;
    },
  >(actions: T[]): Promise<T[]> {
    const applied = actions.filter(
      (action) =>
        action.inquiry &&
        (action.inquiry.closedAt ||
          action.inquiry.finalDecisionStatus === 'APPLIED'),
    );
    if (!applied.length) {
      return actions;
    }

    const employeeIds = [...new Set(applied.map((row) => row.employeeId))];
    const letters = await this.prisma.letter.findMany({
      where: {
        employeeId: { in: employeeIds },
        letterType: {
          in: [
            LetterType.REINSTATEMENT,
            LetterType.TERMINATION,
            LetterType.FINE,
          ],
        },
        status: { not: LetterStatus.REVERSED },
      },
      select: {
        id: true,
        employeeId: true,
        letterType: true,
        status: true,
        letterNo: true,
        content: true,
      },
    });

    return actions.map((action) => {
      if (!action.inquiry) return action;
      const expected = expectedFinalLetters(
        action.inquiry.finding,
        action.inquiry.finalAction,
      );
      return {
        ...action,
        inquiry: {
          ...action.inquiry,
          finalLetters: matchFinalLetterStatuses(
            expected,
            letters.filter((letter) => letter.employeeId === action.employeeId),
            action.inquiry.id,
          ),
        },
      };
    });
  }

  async startInquiry(dto: StartInquiryDto, actingUserId: string) {
    const action = await this.prisma.disciplinaryAction.findUnique({
      where: { id: dto.disciplinaryActionId },
      include: { inquiry: true },
    });

    if (!action) {
      throw new NotFoundException(
        `Disciplinary action with id ${dto.disciplinaryActionId} not found`,
      );
    }

    if (action.status !== DisciplinaryStatus.OPEN) {
      throw new BadRequestException(
        'Inquiry can only be started on open disciplinary actions',
      );
    }

    if (action.inquiry) {
      throw new BadRequestException(
        'An inquiry already exists for this disciplinary action',
      );
    }

    if (action.type === DisciplinaryType.SUSPENSION) {
      throw new BadRequestException(
        'Suspension inquiries are started automatically after an approved suspension letter is issued.',
      );
    }

    const now = new Date();
    const deadlineDays = dto.deadlineDays ?? 3;
    const deadlineAt = this.addDays(now, deadlineDays);

    const inquiry = await this.prisma.$transaction(async (tx) => {
      const created = await tx.inquiry.create({
        data: {
          disciplinaryActionId: dto.disciplinaryActionId,
          deadlineAt,
          notes: dto.notes,
        },
      });

      await tx.disciplinaryAction.update({
        where: { id: dto.disciplinaryActionId },
        data: { status: DisciplinaryStatus.UNDER_INQUIRY },
      });

      await tx.notification.create({
        data: {
          employeeId: action.employeeId,
          type: 'INQUIRY_STARTED',
          message: `An inquiry has been initiated regarding your disciplinary action. Deadline: ${this.formatDate(deadlineAt)}`,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: actingUserId,
          action: 'INQUIRY_STARTED',
          entity: 'Inquiry',
          entityId: created.id,
          changes: { disciplinaryActionId: dto.disciplinaryActionId },
        },
      });

      return created;
    });

    await this.lettersService.generate(
      {
        employeeId: action.employeeId,
        letterType: LetterType.INQUIRY,
        extraFields: {
          inquiryReason: action.reason,
          inquiryDate: this.formatDate(now),
          committeeMembers: 'HR Committee',
        },
      },
      actingUserId,
    );

    return this.prisma.inquiry.findUnique({
      where: { id: inquiry.id },
      include: { disciplinaryAction: true },
    });
  }

  async resolveInquiry(dto: ResolveInquiryDto, actingUserId: string) {
    const inquiry = await this.prisma.inquiry.findUnique({
      where: { id: dto.inquiryId },
      include: {
        disciplinaryAction: {
          include: {
            employee: {
              include: {
                currentDepartment: { select: { name: true } },
                stipendRecords: {
                  orderBy: { effectiveFrom: 'desc' },
                  take: 1,
                },
              },
            },
          },
        },
      },
    });

    if (!inquiry) {
      throw new NotFoundException(`Inquiry with id ${dto.inquiryId} not found`);
    }

    if (
      inquiry.outcome ||
      inquiry.closedAt ||
      inquiry.finalDecisionStatus === InquiryFinalDecisionStatus.APPLIED
    ) {
      throw new BadRequestException('Inquiry has already been resolved');
    }

    const action = inquiry.disciplinaryAction;
    const employee = action.employee;
    const today = this.formatDate(new Date());
    const now = new Date();
    const finalAction = this.finalActionForOutcome(dto.outcome);
    const noteParts = [
      dto.decision?.trim(),
      dto.duration?.trim()
        ? `Duration: ${dto.duration.trim()}`
        : dto.durationDays != null
          ? `Duration: ${dto.durationDays} days`
          : null,
      dto.notes?.trim(),
    ].filter((part): part is string => !!part);
    const combinedNotes = noteParts.join('\n') || undefined;

    await this.prisma.$transaction(async (tx) => {
      await tx.inquiry.update({
        where: { id: dto.inquiryId },
        data: {
          outcome: dto.outcome,
          notes: combinedNotes,
          closedAt: now,
          finalAction,
          finalDecisionStatus: InquiryFinalDecisionStatus.APPLIED,
          finalDecidedById: actingUserId,
          finalDecidedAt: now,
          finalDecisionNote: combinedNotes,
        },
      });

      const actionStatus =
        dto.outcome === InquiryOutcome.DISMISSED
          ? DisciplinaryStatus.DISMISSED
          : DisciplinaryStatus.RESOLVED;

      await tx.disciplinaryAction.update({
        where: { id: action.id },
        data: {
          status: actionStatus,
          resolvedAt: now,
          resolution: combinedNotes,
        },
      });

      if (
        dto.outcome === InquiryOutcome.REINSTATED ||
        dto.outcome === InquiryOutcome.REJOINED
      ) {
        await tx.employee.update({
          where: { id: employee.id },
          data: suspensionInquiryReinstatementData(now),
        });
        await tx.user.updateMany({
          where: { employeeId: employee.id },
          data: { isActive: true },
        });
      } else if (dto.outcome === InquiryOutcome.TERMINATED) {
        await tx.employee.update({
          where: { id: employee.id },
          data: { status: EmployeeStatus.TERMINATED },
        });
        await tx.user.updateMany({
          where: { employeeId: employee.id },
          data: { isActive: false },
        });
      } else if (dto.outcome === InquiryOutcome.REST) {
        await tx.employee.update({
          where: { id: employee.id },
          data: { status: EmployeeStatus.ON_REST },
        });
      } else if (dto.outcome === InquiryOutcome.DISMISSED) {
        await tx.employee.update({
          where: { id: employee.id },
          data: { status: EmployeeStatus.DISMISSED },
        });
        await tx.user.updateMany({
          where: { employeeId: employee.id },
          data: { isActive: false },
        });
      }

      await tx.suspensionRequest.updateMany({
        where: {
          disciplinaryActionId: action.id,
          status: SuspensionRequestStatus.ISSUED,
        },
        data: { status: SuspensionRequestStatus.COMPLETED },
      });

      await tx.notification.create({
        data: {
          employeeId: employee.id,
          type: 'INQUIRY_RESOLVED',
          message: `Your inquiry has been resolved with outcome: ${dto.outcome}`,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: actingUserId,
          action: 'INQUIRY_RESOLVED',
          entity: 'Inquiry',
          entityId: dto.inquiryId,
          changes: {
            outcome: dto.outcome,
            notes: combinedNotes,
            decision: dto.decision,
            duration: dto.duration,
            durationDays: dto.durationDays,
          },
        },
      });
    });

    const letterExtra = dto.extraLetterFields ?? {};

    if (dto.outcome === InquiryOutcome.REINSTATED) {
      await this.lettersService.generate(
        {
          employeeId: employee.id,
          letterType: LetterType.REINSTATEMENT,
          extraFields: {
            reinstatementDate: today,
            reinstatedDesignation: employee.currentDesignation,
            reinstatedDepartment: employee.currentDepartment?.name ?? '',
            ...letterExtra,
          },
        },
        actingUserId,
      );
    } else if (dto.outcome === InquiryOutcome.TERMINATED) {
      await this.lettersService.generate(
        {
          employeeId: employee.id,
          letterType: LetterType.TERMINATION,
          extraFields: {
            terminationReason:
              combinedNotes || inquiry.notes || action.reason,
            terminationDate: today,
            settlementDetails: 'As per HR policy',
            ...letterExtra,
          },
        },
        actingUserId,
      );
    } else if (dto.outcome === InquiryOutcome.REJOINED) {
      await this.lettersService.generate(
        {
          employeeId: employee.id,
          letterType: LetterType.REJOINING,
          extraFields: {
            rejoiningDate: today,
            rejoiningDesignation: employee.currentDesignation,
            ...letterExtra,
          },
        },
        actingUserId,
      );
    } else if (dto.outcome === InquiryOutcome.DISMISSED) {
      await this.lettersService.generate(
        {
          employeeId: employee.id,
          letterType: LetterType.TERMINATION,
          extraFields: {
            terminationReason: 'Dismissed due to corruption inquiry',
            terminationDate: today,
            settlementDetails: combinedNotes || inquiry.notes || action.reason,
            ...letterExtra,
          },
        },
        actingUserId,
      );

      await this.prisma.notification.create({
        data: {
          employeeId: employee.id,
          type: 'DISMISSED',
          message:
            'You have been dismissed from YCDO following the inquiry. You are no longer eligible to rejoin.',
        },
      });

      await this.prisma.auditLog.create({
        data: {
          userId: actingUserId,
          action: 'EMPLOYEE_DISMISSED',
          entity: 'Employee',
          entityId: employee.id,
          changes: {
            inquiryId: dto.inquiryId,
            outcome: dto.outcome,
            notes: combinedNotes,
          },
        },
      });
    }

    return this.prisma.inquiry.findUnique({
      where: { id: dto.inquiryId },
      include: { disciplinaryAction: { include: { employee: true } } },
    });
  }

  private async generateLetterForDisciplinary(
    employeeId: string,
    type: DisciplinaryType,
    reason: string,
    issuedAt: Date,
    actingUserId: string,
    disciplinaryActionId: string,
  ) {
    const formattedDate = this.formatDate(issuedAt);
    const monthYear = `${issuedAt.getMonth() + 1}/${issuedAt.getFullYear()}`;

    switch (type) {
      case DisciplinaryType.SUSPENSION:
        await this.lettersService.generate(
          {
            employeeId,
            letterType: LetterType.SUSPENSION,
            extraFields: {
              disciplinaryActionId,
              suspensionReason: reason,
              suspensionStartDate: formattedDate,
              suspensionDuration: 'Pending inquiry',
            },
          },
          actingUserId,
        );
        break;

      case DisciplinaryType.WARNING: {
        const warningCount = await this.prisma.disciplinaryAction.count({
          where: { employeeId, type: DisciplinaryType.WARNING },
        });
        await this.lettersService.generate(
          {
            employeeId,
            letterType: LetterType.WARNING,
            extraFields: {
              violations: reason,
              warningReason: reason,
              incidentDate: formattedDate,
              warningNumber: this.ordinal(warningCount),
            },
          },
          actingUserId,
        );
        break;
      }

      case DisciplinaryType.SHOW_CAUSE:
        await this.lettersService.generate(
          {
            employeeId,
            letterType: LetterType.SHOW_CAUSE,
            extraFields: {
              allegation: reason,
              responseDeadline: '3 working days',
            },
          },
          actingUserId,
        );
        break;

      case DisciplinaryType.FINE:
        await this.lettersService.generate(
          {
            employeeId,
            letterType: LetterType.FINE,
            extraFields: {
              fineReason: reason,
              fineAmount: 'As per policy',
              deductionMonth: monthYear,
            },
          },
          actingUserId,
        );
        break;

      default:
        break;
    }
  }

  private async ensureInquiryForAction(action: {
    id: string;
    issuedAt: Date;
    reason: string;
  }) {
    const officerMatch = action.reason.match(/Inquiry officer:\s*(.+?)\./i);
    const officerName = officerMatch?.[1]?.trim();
    const startedAt = action.issuedAt ?? new Date();
    const deadlineAt = this.addDays(startedAt, 7);
    try {
      await this.prisma.inquiry.create({
        data: {
          disciplinaryActionId: action.id,
          startedAt,
          deadlineAt,
          ...(officerName ? { inquiryOfficerName: officerName } : {}),
        },
      });
    } catch {
      try {
        await this.prisma.inquiry.create({
          data: {
            disciplinaryActionId: action.id,
            startedAt,
            deadlineAt,
            notes: officerName ? `Inquiry officer: ${officerName}` : undefined,
          },
        });
      } catch {
        return;
      }
    }
    await this.prisma.disciplinaryAction.update({
      where: { id: action.id },
      data: { status: DisciplinaryStatus.UNDER_INQUIRY },
    });
  }

  private finalActionForOutcome(
    outcome: InquiryOutcome,
  ): InquiryFinalAction | null {
    if (outcome === InquiryOutcome.DISMISSED) return InquiryFinalAction.DISMISS;
    if (outcome === InquiryOutcome.TERMINATED) return InquiryFinalAction.TERMINATE;
    if (outcome === InquiryOutcome.REST) return InquiryFinalAction.REST;
    return null;
  }

  private addDays(date: Date, days: number): Date {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  private formatDate(date: Date): string {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }

  private ordinal(n: number): string {
    const suffixes = ['th', 'st', 'nd', 'rd'];
    const v = n % 100;
    return `${n}${suffixes[(v - 20) % 10] || suffixes[v] || suffixes[0]}`;
  }
}
