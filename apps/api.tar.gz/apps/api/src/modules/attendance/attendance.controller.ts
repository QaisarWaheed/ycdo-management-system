import {
  Body,
  Controller,
  ForbiddenException,
  Get,
  Headers,
  Param,
  Patch,
  Post,
  Query,
  UnauthorizedException,
  UseGuards,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Permission, UserRole } from '@prisma/client';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import {
  Roles,
  AlsoAllowPermission,
  StrictRoles,
} from '../auth/roles.decorator';
import { RolesGuard } from '../auth/roles.guard';
import {
  ApplyPunchReviewDto,
  ApproveOvertimeDto,
  AttendanceQueryDto,
  BackfillAbsentDto,
  BiometricPushDto,
  DismissPunchReviewDto,
  ImportAttendanceDto,
  ManualAttendanceDto,
  MarkAbsenteesDto,
  OvertimePunchDto,
  PortalCheckDto,
  PunchReviewQueryDto,
  RawScanDto,
  RecalculateMonthDto,
  RepairDelayedPunchesDto,
  RelieverCheckInDto,
  RelieverCheckOutDto,
  RelieverSessionsQueryDto,
  UpdateAttendanceDto,
  UpdateRelieverSessionDto,
} from './attendance.dto';
import { StartDueInquiryDto } from '../disciplinary/disciplinary.dto';
import { AccessScopeService } from '../permissions/access-scope.service';
import { AttendanceService } from './attendance.service';
import { ShiftAbsentScheduler } from './shift-absent.scheduler';

@Controller('attendance')
export class AttendanceController {
  constructor(
    private attendanceService: AttendanceService,
    private shiftAbsentScheduler: ShiftAbsentScheduler,
    private configService: ConfigService,
    private accessScopeService: AccessScopeService,
  ) {}

  @Post('biometric-push')
  biometricPush(
    @Headers('x-device-key') deviceKey: string,
    @Body() dto: BiometricPushDto,
  ) {
    const expectedKey = this.configService.get<string>('BIOMETRIC_DEVICE_KEY');
    if (!deviceKey || deviceKey !== expectedKey) {
      throw new UnauthorizedException('Invalid device key');
    }

    return this.attendanceService.biometricPush(dto);
  }

  /**
   * Thin-agent contract: the agent forwards the device's raw event verbatim
   * (no status mapping, no dedup, no CHECKIN/CHECKOUT guessing on the agent
   * side). Runs in parallel with POST /attendance/biometric-push, which is
   * unchanged — branches can move to this endpoint independently of one
   * another, and the old endpoint keeps working for branches that don't.
   */
  @Post('raw-scan')
  rawScan(@Headers('x-device-key') deviceKey: string, @Body() dto: RawScanDto) {
    const expectedKey = this.configService.get<string>('BIOMETRIC_DEVICE_KEY');
    if (!deviceKey || deviceKey !== expectedKey) {
      throw new UnauthorizedException('Invalid device key');
    }

    return this.attendanceService.rawScan(dto);
  }

  @Post('manual')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.MEDICINE_MANAGER,
    UserRole.ADMIN_OFFICER,
    UserRole.IT_ADMIN,
  )
  markManual(
    @Body() dto: ManualAttendanceDto,
    @CurrentUser() user: { id: string; role: UserRole },
  ) {
    return this.attendanceService.markManual(dto, user);
  }

  @Patch(':id/approve-overtime')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.SUPER_ADMIN)
  approveOvertime(
    @Param('id') id: string,
    @Body() dto: ApproveOvertimeDto,
    @CurrentUser() user: { id: string },
  ) {
    return this.attendanceService.approveOvertime(id, dto, user.id);
  }

  @Get(':id/trail')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_OFFICER,
    UserRole.ADMIN_MANAGER,
    UserRole.MEDICINE_MANAGER,
    UserRole.IT_ADMIN,
  )
  getAttendanceTrail(
    @Param('id') id: string,
    @CurrentUser() user: { id: string; role: UserRole },
  ) {
    return this.attendanceService.getAttendanceTrail(id, user);
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_OFFICER,
    UserRole.ADMIN_MANAGER,
    UserRole.MEDICINE_MANAGER,
    UserRole.IT_ADMIN,
  )
  updateAttendance(
    @Param('id') id: string,
    @Body() dto: UpdateAttendanceDto,
    @CurrentUser() user: { id: string; role: UserRole },
  ) {
    return this.attendanceService.updateAttendance(id, dto, user);
  }

  /** HR fixed a duty: re-apply the month's machine punches with the current duty. */
  @Post('recalculate-month')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
  )
  recalculateMonth(
    @Body() dto: RecalculateMonthDto,
    @CurrentUser() user: { id: string; role: UserRole },
  ) {
    return this.attendanceService.recalculateMonthFromPunches(
      dto.employeeId,
      dto.year,
      dto.month,
      user,
    );
  }

  @Get('timer/:employeeId')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.EMPLOYEE)
  getActiveTimer(
    @Param('employeeId') employeeId: string,
    @CurrentUser() user: { employeeId?: string | null },
  ) {
    if (user.employeeId !== employeeId) {
      throw new ForbiddenException('Access denied');
    }
    return this.attendanceService.getActiveTimer(employeeId);
  }

  @Post('device-punch-repair')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.SUPER_ADMIN)
  @StrictRoles()
  repairDelayedDevicePunches(
    @Body() dto: RepairDelayedPunchesDto,
    @CurrentUser() user: { id: string; role: UserRole },
  ) {
    return this.attendanceService.repairDelayedDevicePunches(dto, user);
  }

  /** Device punches not saved because the device clock changed or is unknown. */
  @Get('punch-reviews')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
  )
  listPunchReviews(@Query() query: PunchReviewQueryDto) {
    return this.attendanceService.listPunchReviews(query.status);
  }

  @Post('punch-reviews/:id/apply')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
  )
  applyPunchReview(
    @Param('id') id: string,
    @Body() dto: ApplyPunchReviewDto,
    @CurrentUser() user: { id: string },
  ) {
    return this.attendanceService.applyPunchReview(id, dto, user.id);
  }

  @Post('punch-reviews/:id/dismiss')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
  )
  dismissPunchReview(
    @Param('id') id: string,
    @Body() dto: DismissPunchReviewDto,
    @CurrentUser() user: { id: string },
  ) {
    return this.attendanceService.dismissPunchReview(id, dto.note, user.id);
  }

  @Get('reliever-sessions')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.ADMIN_OFFICER,
  )
  findAllRelieverSessions(@Query() query: RelieverSessionsQueryDto) {
    return this.attendanceService.findAllRelieverSessions(query);
  }

  @Post('reliever-sessions/check-in')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.ADMIN_OFFICER,
  )
  relieverCheckIn(@Body() dto: RelieverCheckInDto) {
    return this.attendanceService.relieverCheckIn(dto);
  }

  @Post('reliever-sessions/check-out')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.ADMIN_OFFICER,
  )
  relieverCheckOut(
    @Body() dto: RelieverCheckOutDto,
    @CurrentUser() user: { id: string },
  ) {
    return this.attendanceService.relieverCheckOut(dto, user.id);
  }

  /** HR correction to an existing session's recorded checkIn/checkOut. */
  @Patch('reliever-sessions/:id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.ADMIN_OFFICER,
  )
  updateRelieverSession(
    @Param('id') id: string,
    @Body() dto: UpdateRelieverSessionDto,
    @CurrentUser() user: { id: string; role: UserRole },
  ) {
    return this.attendanceService.updateRelieverSession(id, dto, user);
  }

  @Get('reliever/:employeeId')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.ADMIN_MANAGER,
    UserRole.ADMIN_OFFICER,
    UserRole.EMPLOYEE,
  )
  getRelieverSessions(
    @Param('employeeId') employeeId: string,
    @Query('month') month: string,
    @Query('year') year: string,
    @CurrentUser() user: { role: UserRole; employeeId?: string | null },
  ) {
    if (user.role === UserRole.EMPLOYEE && user.employeeId !== employeeId) {
      throw new ForbiddenException('Access denied');
    }
    return this.attendanceService.getRelieverSessions(
      employeeId,
      Number(month),
      Number(year),
    );
  }

  @Get('summary/:employeeId')
  @AlsoAllowPermission(Permission.REPORTS_VIEW)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.IT_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.ADMIN_MANAGER,
    UserRole.ADMIN_OFFICER,
    UserRole.EMPLOYEE,
  )
  getEmployeeSummary(
    @Param('employeeId') employeeId: string,
    @Query('month') month: string,
    @Query('year') year: string,
    @CurrentUser() user: { role: UserRole; employeeId?: string | null },
  ) {
    if (user.role === UserRole.EMPLOYEE && user.employeeId !== employeeId) {
      throw new ForbiddenException('Access denied');
    }
    return this.attendanceService.getEmployeeSummary(
      employeeId,
      Number(month),
      Number(year),
    );
  }

  @Get('suspension-watchlist')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.IT_ADMIN,
    UserRole.PROGRESS_OFFICER,
  )
  getSuspensionWatchlist(
    @Query('year') year?: string,
    @Query('month') month?: string,
  ) {
    return this.attendanceService.getSuspensionWatchlist(
      year != null && year !== '' ? Number(year) : undefined,
      month != null && month !== '' ? Number(month) : undefined,
    );
  }

  @Post('suspension-watchlist/:employeeId/reminder')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.IT_ADMIN,
  )
  sendNearSuspensionReminder(
    @Param('employeeId') employeeId: string,
    @CurrentUser() user: { id: string; role: UserRole },
    @Query('year') year?: string,
    @Query('month') month?: string,
  ) {
    return this.attendanceService.sendNearSuspensionReminder(
      employeeId,
      user.id,
      user.role,
      year != null && year !== '' ? Number(year) : undefined,
      month != null && month !== '' ? Number(month) : undefined,
    );
  }

  @Get('suspension-watchlist/:employeeId/inquiry-preview')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.IT_ADMIN,
  )
  getDueInquiryPreview(
    @Param('employeeId') employeeId: string,
    @Query('year') year?: string,
    @Query('month') month?: string,
  ) {
    return this.attendanceService.getDueInquiryPreview(
      employeeId,
      year != null && year !== '' ? Number(year) : undefined,
      month != null && month !== '' ? Number(month) : undefined,
    );
  }

  @Post('suspension-watchlist/:employeeId/start-case')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.IT_ADMIN,
  )
  startSuspensionCaseFromWatchlist(
    @Param('employeeId') employeeId: string,
    @Body() dto: StartDueInquiryDto,
    @CurrentUser() user: { id: string; role: UserRole; roles?: UserRole[] },
    @Query('year') year?: string,
    @Query('month') month?: string,
  ) {
    return this.attendanceService.startSuspensionCaseFromWatchlist(
      employeeId,
      user.id,
      user.role,
      year != null && year !== '' ? Number(year) : undefined,
      month != null && month !== '' ? Number(month) : undefined,
      dto,
      user.roles,
    );
  }

  @Get()
  @AlsoAllowPermission(Permission.REPORTS_VIEW)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    // Accounts read verified attendance (no edit permissions).
    UserRole.PAYROLL_OFFICER,
    UserRole.HR_MANAGER,
    UserRole.ADMIN_MANAGER,
    UserRole.MEDICINE_MANAGER,
    UserRole.ADMIN_OFFICER,
    UserRole.EMPLOYEE,
    UserRole.CHAIRMAN,
    UserRole.FOUNDER,
    UserRole.PRESIDENT,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.IT_ADMIN,
  )
  async findAll(
    @Query() query: AttendanceQueryDto,
    @CurrentUser()
    user: {
      id: string;
      role: UserRole;
      roles?: UserRole[];
      employeeId?: string | null;
      branchId?: string | null;
    },
  ) {
    const effectiveRoles = user.roles?.length ? user.roles : [user.role];
    const isPortalOnly =
      effectiveRoles.length === 1 && effectiveRoles[0] === UserRole.EMPLOYEE;
    const hasManagerScopes = await this.accessScopeService.userHasManagerScopes(
      user.id,
    );

    if (isPortalOnly && !hasManagerScopes) {
      if (!user.employeeId) {
        throw new ForbiddenException('Employee profile required');
      }
      return this.attendanceService.findAll(
        {
          ...query,
          employeeId: user.employeeId,
        },
        user,
      );
    }
    return this.attendanceService.findAll(query, user);
  }

  @Post('mark-absentees')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.SUPER_ADMIN, UserRole.HR_MANAGER)
  markAbsentees(@Body() dto: MarkAbsenteesDto) {
    return this.attendanceService.markAbsentees(dto.date);
  }

  @Post('import')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.SUPER_ADMIN, UserRole.HR_MANAGER, UserRole.HR_ADMIN_MANAGER)
  importRecord(
    @Body() dto: ImportAttendanceDto,
    @CurrentUser() user: { id: string },
  ) {
    return this.attendanceService.importRecord(dto, user.id);
  }

  @Post('backfill-absent')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.SUPER_ADMIN)
  backfillAbsent(@Body() dto: BackfillAbsentDto) {
    return this.shiftAbsentScheduler.backfillAbsentForDate(
      dto.date,
      dto.shiftName,
    );
  }

  @Post('portal-checkin')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.EMPLOYEE)
  portalCheckIn(
    @Body() dto: PortalCheckDto,
    @CurrentUser() user: { employeeId?: string | null },
  ) {
    if (!user.employeeId) {
      throw new ForbiddenException('Employee profile required');
    }
    return this.attendanceService.portalCheckIn(
      user.employeeId,
      dto.latitude,
      dto.longitude,
    );
  }

  @Post('portal-checkout')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.EMPLOYEE)
  portalCheckOut(
    @Body() dto: PortalCheckDto,
    @CurrentUser() user: { employeeId?: string | null },
  ) {
    if (!user.employeeId) {
      throw new ForbiddenException('Employee profile required');
    }
    return this.attendanceService.portalCheckOut(
      user.employeeId,
      dto.latitude,
      dto.longitude,
    );
  }

  @Post('overtime-punch')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.EMPLOYEE)
  overtimePunch(
    @Body() dto: OvertimePunchDto,
    @CurrentUser() user: { employeeId?: string | null },
  ) {
    if (!user.employeeId) {
      throw new ForbiddenException('Employee profile required');
    }
    return this.attendanceService.recordOvertimePunch(
      user.employeeId,
      dto.punchType,
    );
  }
}
