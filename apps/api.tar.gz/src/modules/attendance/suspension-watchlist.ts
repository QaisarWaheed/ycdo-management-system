import { AttendanceStatus, EmployeeStatus, Prisma } from '@prisma/client';
import { pakistanMonthDateRange } from './attendance-calendar.util';
import { BRANCH_LABEL_SELECT } from '../../common/branch-select.util';
import { countsTowardSuspensionWatch } from './suspension-watch-baseline.util';

export type SuspensionWatchReason =
  | 'LATE_NEAR'
  | 'LATE_DUE'
  | 'UA_NEAR'
  | 'UA_DUE';

export type SuspensionWatchlistEntry = {
  employeeId: string;
  fullName: string;
  employeeCode: string | null;
  biometricId: string | null;
  phone: string | null;
  branchId: string | null;
  branchName: string | null;
  lateDays: number;
  uninformedAbsentDays: number;
  lateDates: string[];
  uninformedAbsentDates: string[];
  reasons: SuspensionWatchReason[];
};

export type SuspensionWatchlistResult = {
  month: string;
  year: number;
  monthNumber: number;
  near: SuspensionWatchlistEntry[];
  due: SuspensionWatchlistEntry[];
  counts: { near: number; due: number };
};

/** Near/Due lists evaluate only working staff who can still be suspended. */
export const SUSPENSION_WATCHLIST_STATUSES: EmployeeStatus[] = [
  EmployeeStatus.ACTIVE,
  EmployeeStatus.SUSPENDED,
];

function dayKey(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function isLateDrivenHalfDay(row: {
  status: AttendanceStatus;
  note: string | null;
  lateMinutes: number | null;
}): boolean {
  if (row.status !== AttendanceStatus.HALF_DAY) return false;
  if (row.note && /short leave/i.test(row.note)) return false;
  return (row.lateMinutes ?? 0) > 0;
}

/**
 * Monthly late / uninformed-absent counts → Near (6–8 late or UA=2) and
 * Due (≥9 late or UA≥3). Due wins if both apply. Anyone below those
 * thresholds is omitted from both lists.
 */
export function classifySuspensionWatchBucket(
  lateDays: number,
  uninformedAbsentDays: number,
): 'near' | 'due' | null {
  if (lateDays >= 9 || uninformedAbsentDays >= 3) return 'due';
  if ((lateDays >= 6 && lateDays <= 8) || uninformedAbsentDays === 2) {
    return 'near';
  }
  return null;
}

export function suspensionWatchReasons(
  lateDays: number,
  uninformedAbsentDays: number,
): SuspensionWatchReason[] {
  const reasons: SuspensionWatchReason[] = [];
  if (lateDays >= 9) reasons.push('LATE_DUE');
  else if (lateDays >= 6 && lateDays <= 8) reasons.push('LATE_NEAR');
  if (uninformedAbsentDays >= 3) reasons.push('UA_DUE');
  else if (uninformedAbsentDays === 2) reasons.push('UA_NEAR');
  return reasons;
}
type WatchlistDb = {
  attendanceLog: { findMany: Prisma.TransactionClient['attendanceLog']['findMany'] };
  employee: { findMany: Prisma.TransactionClient['employee']['findMany'] };
};

export async function buildSuspensionWatchlist(
  db: WatchlistDb,
  year: number,
  month: number,
): Promise<SuspensionWatchlistResult> {
  const { start, end } = pakistanMonthDateRange(year, month);
  const monthLabel = `${year}-${String(month).padStart(2, '0')}`;

  const logs = await db.attendanceLog.findMany({
    where: {
      date: { gte: start, lte: end },
      employee: { status: { in: SUSPENSION_WATCHLIST_STATUSES } },
      OR: [
        { status: AttendanceStatus.LATE },
        {
          status: AttendanceStatus.HALF_DAY,
          lateMinutes: { gt: 0 },
        },
        { status: AttendanceStatus.UNINFORMED_ABSENT },
      ],
    },
    select: {
      employeeId: true,
      date: true,
      status: true,
      note: true,
      lateMinutes: true,
    },
  });

  const lateDaysByEmployee = new Map<string, Set<string>>();
  const uaDaysByEmployee = new Map<string, Set<string>>();
  const logsByEmployee = new Map<string, typeof logs>();

  for (const row of logs) {
    if (!logsByEmployee.has(row.employeeId)) {
      logsByEmployee.set(row.employeeId, []);
    }
    logsByEmployee.get(row.employeeId)!.push(row);
  }

  const candidateIds = [...logsByEmployee.keys()];
  if (candidateIds.length === 0) {
    return {
      month: monthLabel,
      year,
      monthNumber: month,
      near: [],
      due: [],
      counts: { near: 0, due: 0 },
    };
  }

  const employees = await db.employee.findMany({
    where: {
      id: { in: candidateIds },
      status: { in: SUSPENSION_WATCHLIST_STATUSES },
    },
    select: {
      id: true,
      fullName: true,
      employeeCode: true,
      biometricId: true,
      phone: true,
      currentBranchId: true,
      currentBranch: { select: BRANCH_LABEL_SELECT },
      status: true,
      suspensionWatchBaselineOn: true,
    },
  });
  const byId = new Map(employees.map((e) => [e.id, e]));

  const nearIds: string[] = [];
  const dueIds: string[] = [];
  const meta = new Map<
    string,
    {
      lateDays: number;
      uninformedAbsentDays: number;
      lateDates: string[];
      uninformedAbsentDates: string[];
      reasons: SuspensionWatchReason[];
      bucket: 'near' | 'due';
    }
  >();

  for (const emp of employees) {
    const baseline = emp.suspensionWatchBaselineOn;
    for (const row of logsByEmployee.get(emp.id) ?? []) {
      if (!countsTowardSuspensionWatch(row.date, baseline)) continue;
      const key = dayKey(row.date);
      if (row.status === AttendanceStatus.UNINFORMED_ABSENT) {
        if (!uaDaysByEmployee.has(row.employeeId)) {
          uaDaysByEmployee.set(row.employeeId, new Set());
        }
        uaDaysByEmployee.get(row.employeeId)!.add(key);
        continue;
      }
      if (
        row.status === AttendanceStatus.LATE ||
        isLateDrivenHalfDay(row)
      ) {
        if (!lateDaysByEmployee.has(row.employeeId)) {
          lateDaysByEmployee.set(row.employeeId, new Set());
        }
        lateDaysByEmployee.get(row.employeeId)!.add(key);
      }
    }

    const lateDays = lateDaysByEmployee.get(emp.id)?.size ?? 0;
    const uninformedAbsentDays = uaDaysByEmployee.get(emp.id)?.size ?? 0;
    const bucket = classifySuspensionWatchBucket(
      lateDays,
      uninformedAbsentDays,
    );
    if (!bucket) continue;

    const reasons = suspensionWatchReasons(lateDays, uninformedAbsentDays);
    meta.set(emp.id, {
      lateDays,
      uninformedAbsentDays,
      lateDates: [...(lateDaysByEmployee.get(emp.id) ?? [])].sort(),
      uninformedAbsentDates: [
        ...(uaDaysByEmployee.get(emp.id) ?? []),
      ].sort(),
      reasons,
      bucket,
    });
    if (bucket === 'due') dueIds.push(emp.id);
    else nearIds.push(emp.id);
  }

  if (nearIds.length === 0 && dueIds.length === 0) {
    return {
      month: monthLabel,
      year,
      monthNumber: month,
      near: [],
      due: [],
      counts: { near: 0, due: 0 },
    };
  }

  const toEntry = (employeeId: string): SuspensionWatchlistEntry | null => {
    const emp = byId.get(employeeId);
    const m = meta.get(employeeId);
    if (!emp || !m) return null;
    return {
      employeeId: emp.id,
      fullName: emp.fullName,
      employeeCode: emp.employeeCode,
      biometricId: emp.biometricId,
      phone: emp.phone,
      branchId: emp.currentBranchId,
      branchName: emp.currentBranch?.name ?? null,
      lateDays: m.lateDays,
      uninformedAbsentDays: m.uninformedAbsentDays,
      lateDates: m.lateDates,
      uninformedAbsentDates: m.uninformedAbsentDates,
      reasons: m.reasons,
    };
  };

  const sortEntries = (a: SuspensionWatchlistEntry, b: SuspensionWatchlistEntry) =>
    a.fullName.localeCompare(b.fullName);

  const near = nearIds
    .map(toEntry)
    .filter((e): e is SuspensionWatchlistEntry => e != null)
    .sort(sortEntries);
  const due = dueIds
    .map(toEntry)
    .filter((e): e is SuspensionWatchlistEntry => e != null)
    .sort(sortEntries);

  return {
    month: monthLabel,
    year,
    monthNumber: month,
    near,
    due,
    counts: { near: near.length, due: due.length },
  };
}
