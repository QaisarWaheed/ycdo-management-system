import { UserRole } from '@prisma/client';
import {
  IsEmail,
  IsEnum,
  IsIn,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  MinLength,
} from 'class-validator';

export type AuthClient = 'portal' | 'hrms';

export class LoginDto {
  @IsEmail()
  email: string;

  @IsString()
  @MinLength(6)
  password: string;

  /** Which app is signing in — enforces employee vs system login separation. */
  @IsOptional()
  @IsIn(['portal', 'hrms'])
  client?: AuthClient;
}

export class VerifyLoginOtpDto {
  @IsUUID()
  @IsNotEmpty()
  challengeId: string;

  @IsString()
  @Length(6, 6)
  otp: string;
}

export class ResendLoginOtpDto {
  @IsUUID()
  @IsNotEmpty()
  challengeId: string;
}

export class RegisterDto {
  @IsEmail()
  email: string;

  @IsString()
  @MinLength(6)
  password: string;

  @IsEnum(UserRole)
  role: UserRole;

  @IsOptional()
  @IsString()
  employeeId?: string;
}

export class ChangePasswordDto {
  @IsString()
  @MinLength(6)
  currentPassword: string;

  @IsString()
  @MinLength(6)
  newPassword: string;
}

export class ResetPasswordDto {
  @IsUUID()
  @IsNotEmpty()
  userId: string;

  @IsString()
  @MinLength(6)
  @IsNotEmpty()
  newPassword: string;
}
