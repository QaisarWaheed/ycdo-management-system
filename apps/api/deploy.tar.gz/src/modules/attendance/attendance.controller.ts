import {
  Body,
  Controller,
  ForbiddenException,
  Get,
  Headers,
  Param,
  Patch,
  Post,
  Query,
  UnauthorizedException,
  UseGuards,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { UserRole } from '@prisma/client';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { Roles } from '../auth/roles.decorator';
import { RolesGuard } from '../auth/roles.guard';
import {
  ApproveOvertimeDto,
  AttendanceQueryDto,
  BackfillAbsentDto,
  BiometricPushDto,
  ImportAttendanceDto,
  ManualAttendanceDto,
  MarkAbsenteesDto,
  PortalCheckDto,
  RelieverSessionsQueryDto,
  UpdateAttendanceDto,
} from './attendance.dto';
import { AccessScopeService } from '../permissions/access-scope.service';
import { AttendanceService } from './attendance.service';
import { ShiftAbsentScheduler } from './shift-absent.scheduler';

@Controller('attendance')
export class AttendanceController {
  constructor(
    private attendanceService: AttendanceService,
    private shiftAbsentScheduler: ShiftAbsentScheduler,
    private configService: ConfigService,
    private accessScopeService: AccessScopeService,
  ) {}

  @Post('biometric-push')
  biometricPush(
    @Headers('x-device-key') deviceKey: string,
    @Body() dto: BiometricPushDto,
  ) {
    const expectedKey = this.configService.get<string>('BIOMETRIC_DEVICE_KEY');
    if (!deviceKey || deviceKey !== expectedKey) {
      throw new UnauthorizedException('Invalid device key');
    }

    return this.attendanceService.biometricPush(dto);
  }

  @Post('manual')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_MANAGER,
    UserRole.MEDICINE_MANAGER,
    UserRole.ADMIN_OFFICER,
    UserRole.IT_ADMIN,
  )
  markManual(
    @Body() dto: ManualAttendanceDto,
    @CurrentUser() user: { id: string; role: UserRole },
  ) {
    return this.attendanceService.markManual(dto, user);
  }

  @Patch(':id/approve-overtime')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.SUPER_ADMIN)
  approveOvertime(
    @Param('id') id: string,
    @Body() dto: ApproveOvertimeDto,
    @CurrentUser() user: { id: string },
  ) {
    return this.attendanceService.approveOvertime(id, dto, user.id);
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.HR_EXECUTIVE,
    UserRole.ADMIN_OFFICER,
    UserRole.ADMIN_MANAGER,
    UserRole.MEDICINE_MANAGER,
    UserRole.IT_ADMIN,
  )
  updateAttendance(
    @Param('id') id: string,
    @Body() dto: UpdateAttendanceDto,
    @CurrentUser() user: { id: string; role: UserRole },
  ) {
    return this.attendanceService.updateAttendance(id, dto, user);
  }

  @Get('timer/:employeeId')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.EMPLOYEE)
  getActiveTimer(
    @Param('employeeId') employeeId: string,
    @CurrentUser() user: { employeeId?: string | null },
  ) {
    if (user.employeeId !== employeeId) {
      throw new ForbiddenException('Access denied');
    }
    return this.attendanceService.getActiveTimer(employeeId);
  }

  @Get('reliever-sessions')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.ADMIN_MANAGER,
    UserRole.ADMIN_OFFICER,
  )
  findAllRelieverSessions(@Query() query: RelieverSessionsQueryDto) {
    return this.attendanceService.findAllRelieverSessions(query);
  }

  @Get('reliever/:employeeId')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.ADMIN_MANAGER,
    UserRole.ADMIN_OFFICER,
    UserRole.EMPLOYEE,
  )
  getRelieverSessions(
    @Param('employeeId') employeeId: string,
    @Query('month') month: string,
    @Query('year') year: string,
    @CurrentUser() user: { role: UserRole; employeeId?: string | null },
  ) {
    if (
      user.role === UserRole.EMPLOYEE &&
      user.employeeId !== employeeId
    ) {
      throw new ForbiddenException('Access denied');
    }
    return this.attendanceService.getRelieverSessions(
      employeeId,
      Number(month),
      Number(year),
    );
  }

  @Get('summary/:employeeId')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.ADMIN_MANAGER,
    UserRole.ADMIN_OFFICER,
    UserRole.EMPLOYEE,
  )
  getEmployeeSummary(
    @Param('employeeId') employeeId: string,
    @Query('month') month: string,
    @Query('year') year: string,
    @CurrentUser() user: { role: UserRole; employeeId?: string | null },
  ) {
    if (
      user.role === UserRole.EMPLOYEE &&
      user.employeeId !== employeeId
    ) {
      throw new ForbiddenException('Access denied');
    }
    return this.attendanceService.getEmployeeSummary(
      employeeId,
      Number(month),
      Number(year),
    );
  }

  @Get()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.ADMIN_MANAGER,
    UserRole.MEDICINE_MANAGER,
    UserRole.ADMIN_OFFICER,
    UserRole.EMPLOYEE,
    UserRole.CHAIRMAN,
    UserRole.FOUNDER,
    UserRole.HR_ADMIN_MANAGER,
    UserRole.HR_OPERATIONS_MANAGER,
    UserRole.IT_ADMIN,
  )
  async findAll(
    @Query() query: AttendanceQueryDto,
    @CurrentUser()
    user: {
      id: string;
      role: UserRole;
      roles?: UserRole[];
      employeeId?: string | null;
      branchId?: string | null;
    },
  ) {
    const effectiveRoles = user.roles?.length ? user.roles : [user.role];
    const isPortalOnly =
      effectiveRoles.length === 1 && effectiveRoles[0] === UserRole.EMPLOYEE;
    const hasManagerScopes =
      await this.accessScopeService.userHasManagerScopes(user.id);

    if (isPortalOnly && !hasManagerScopes) {
      if (!user.employeeId) {
        throw new ForbiddenException('Employee profile required');
      }
      return this.attendanceService.findAll(
        {
          ...query,
          employeeId: user.employeeId,
        },
        user,
      );
    }
    return this.attendanceService.findAll(query, user);
  }

  @Post('mark-absentees')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.SUPER_ADMIN, UserRole.HR_MANAGER)
  markAbsentees(@Body() dto: MarkAbsenteesDto) {
    return this.attendanceService.markAbsentees(dto.date);
  }

  @Post('import')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    UserRole.SUPER_ADMIN,
    UserRole.HR_MANAGER,
    UserRole.HR_ADMIN_MANAGER,
  )
  importRecord(
    @Body() dto: ImportAttendanceDto,
    @CurrentUser() user: { id: string },
  ) {
    return this.attendanceService.importRecord(dto, user.id);
  }

  @Post('backfill-absent')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.SUPER_ADMIN)
  backfillAbsent(@Body() dto: BackfillAbsentDto) {
    return this.shiftAbsentScheduler.backfillAbsentForDate(
      dto.date,
      dto.shiftName,
    );
  }

  @Post('portal-checkin')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.EMPLOYEE)
  portalCheckIn(
    @Body() dto: PortalCheckDto,
    @CurrentUser() user: { employeeId?: string | null },
  ) {
    if (!user.employeeId) {
      throw new ForbiddenException('Employee profile required');
    }
    return this.attendanceService.portalCheckIn(
      user.employeeId,
      dto.latitude,
      dto.longitude,
    );
  }

  @Post('portal-checkout')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.EMPLOYEE)
  portalCheckOut(
    @Body() dto: PortalCheckDto,
    @CurrentUser() user: { employeeId?: string | null },
  ) {
    if (!user.employeeId) {
      throw new ForbiddenException('Employee profile required');
    }
    return this.attendanceService.portalCheckOut(
      user.employeeId,
      dto.latitude,
      dto.longitude,
    );
  }
}
