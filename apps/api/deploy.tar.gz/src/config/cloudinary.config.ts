import { v2 as cloudinary } from 'cloudinary';

export const initCloudinary = () => {
  if (!process.env.CLOUDINARY_CLOUD_NAME) {
    return;
  }

  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });
};

export { cloudinary };

export function isCloudinaryEnabled(): boolean {
  return !!process.env.CLOUDINARY_CLOUD_NAME;
}
