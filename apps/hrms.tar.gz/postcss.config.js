import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)

export default {
  plugins: {
    tailwindcss: require('tailwindcss'),
    autoprefixer: require('autoprefixer'),
  },
}
