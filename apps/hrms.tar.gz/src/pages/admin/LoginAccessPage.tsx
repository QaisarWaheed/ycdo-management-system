import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { format } from 'date-fns'
import {
  Eye,
  EyeOff,
  MessageCircle,
  Plus,
  RefreshCw,
  Settings2,
  Shield,
} from 'lucide-react'
import { branchesApi } from '@/api/endpoints/branches'
import { projectsApi } from '@/api/endpoints/projects'
import {
  userAccessApi,
  type AppPermission,
  type PermissionOverrideInput,
  type UserAccessRecord,
} from '@/api/endpoints/userAccess'
import { userPasswordsApi } from '@/api/endpoints/userPasswords'
import { PortalCredentialsWhatsAppDialog } from '@/components/admin/PortalCredentialsWhatsAppDialog'
import { TablePagination } from '@/components/common/TablePagination'
import { TableRecordCount } from '@/components/common/TableRecordCount'
import { EmployeeNameLink } from '@/components/employees/EmployeeNameLink'
import {
  HospitalScopeSelect,
  type SelectedScope,
} from '@/components/employees/HospitalScopeSelect'
import { RoleBadges } from '@/components/employees/RoleBadges'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { toast } from '@/hooks/use-toast'
import { useAuth } from '@/hooks/useAuth'
import { useDebounce } from '@/hooks/useDebounce'
import { usePagination } from '@/hooks/usePagination'
import { getApiErrorMessage } from '@/lib/apiErrorMessage'
import { formatBranchLabel } from '@/lib/formatBranchLabel'
import { roleAllowsPermission } from '@/lib/permissionDefaults'

type LoginTypeFilter = 'all' | 'employee' | 'system'
type PermissionMode = 'default' | 'grant' | 'deny'

function loginBranch(record: UserAccessRecord) {
  return record.employee?.currentBranch ?? record.branch ?? null
}

function loginPassword(record: UserAccessRecord) {
  return (
    record.passwordRecord?.plainText ??
    record.employee?.employeeCode ??
    null
  )
}

function permissionMode(
  permission: AppPermission,
  overrides: { permission: AppPermission; granted: boolean }[],
): PermissionMode {
  const override = overrides.find((o) => o.permission === permission)
  if (!override) return 'default'
  return override.granted ? 'grant' : 'deny'
}

function ManageAccessDialog({
  userId,
  open,
  onOpenChange,
}: {
  userId: string | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [newPassword, setNewPassword] = useState('')
  const [permissionModes, setPermissionModes] = useState<
    Record<AppPermission, PermissionMode>
  >({} as Record<AppPermission, PermissionMode>)
  const [managerScopes, setManagerScopes] = useState<SelectedScope[]>([])
  const [isActive, setIsActive] = useState(true)
  const [branchId, setBranchId] = useState('')

  const { data: meta } = useQuery({
    queryKey: ['user-access-meta'],
    queryFn: () => userAccessApi.getMeta(),
  })

  const { data: branches = [] } = useQuery({
    queryKey: ['branches'],
    queryFn: () => branchesApi.getAll(),
  })

  const { data: user, isLoading } = useQuery({
    queryKey: ['user-access', userId],
    queryFn: () => userAccessApi.getOne(userId!),
    enabled: open && !!userId,
  })

  useEffect(() => {
    if (!user || !open) return
    setManagerScopes(
      (user.managerScopes ?? []).map((scope) => ({
        projectId: scope.projectId,
        departmentId: scope.departmentId,
        designationId: scope.designationId ?? null,
        label: scope.label,
      })),
    )
    setIsActive(user.isActive)
    setBranchId(user.branchId ?? '')
    const modes = {} as Record<AppPermission, PermissionMode>
    for (const p of user.permissions) {
      modes[p.permission] = p.granted ? 'grant' : 'deny'
    }
    setPermissionModes(modes)
  }, [user, open])

  useEffect(() => {
    if (!open) {
      setManagerScopes([])
      setNewPassword('')
      setPermissionModes({} as Record<AppPermission, PermissionMode>)
    }
  }, [open])

  const saveMutation = useMutation({
    mutationFn: () => {
      const permissions: PermissionOverrideInput[] =
        meta?.permissions.map(({ permission }) => {
          const mode = permissionModes[permission] ?? 'default'
          if (mode === 'default') return { permission, granted: null }
          return { permission, granted: mode === 'grant' }
        }) ?? []

      return userAccessApi.update(userId!, {
        managerScopes: managerScopes.map((scope) => ({
          projectId: scope.projectId,
          departmentId: scope.departmentId,
          designationId: scope.designationId ?? null,
        })),
        isActive,
        branchId: branchId || null,
        permissions,
      })
    },
    onSuccess: () => {
      toast({ title: 'Access settings saved' })
      queryClient.invalidateQueries({ queryKey: ['login-access'] })
      queryClient.invalidateQueries({ queryKey: ['user-access', userId] })
      onOpenChange(false)
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to save',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const passwordMutation = useMutation({
    mutationFn: () => userAccessApi.resetPassword(userId!, newPassword),
    onSuccess: () => {
      toast({ title: 'Password updated' })
      setNewPassword('')
      queryClient.invalidateQueries({ queryKey: ['login-access'] })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to reset password',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const handleClose = (v: boolean) => {
    if (!v) {
      setNewPassword('')
      setPermissionModes({} as Record<AppPermission, PermissionMode>)
    }
    onOpenChange(v)
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Manage Login Access</DialogTitle>
        </DialogHeader>

        {isLoading || !user ? (
          <div className="space-y-3 py-4">
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : (
          <div className="space-y-6">
            <div>
              <p className="font-medium">{user.email}</p>
              <p className="text-sm text-text-secondary">
                {user.employee
                  ? `${user.employee.fullName} (${user.employee.employeeCode})`
                  : 'System login'}
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2 sm:col-span-2 rounded-lg border border-border p-3">
                <HospitalScopeSelect
                  options={
                    user.hospitalScopeOptions ??
                    meta?.hospitalScopeOptions ??
                    []
                  }
                  value={managerScopes}
                  onChange={setManagerScopes}
                  disabled={saveMutation.isPending}
                />
              </div>

              <div className="space-y-2">
                <Label>Account status</Label>
                <Select
                  value={isActive ? 'active' : 'disabled'}
                  onValueChange={(v) => setIsActive(v === 'active')}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active — can sign in</SelectItem>
                    <SelectItem value="disabled">Disabled — access revoked</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {!user.employeeId && (
                <div className="space-y-2 sm:col-span-2">
                  <Label>Branch (optional)</Label>
                  <Select
                    value={branchId || 'none'}
                    onValueChange={(v) => setBranchId(v === 'none' ? '' : v)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="No branch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No branch</SelectItem>
                      {branches.map((b) => (
                        <SelectItem key={b.id} value={b.id}>
                          {formatBranchLabel(b)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <div>
                <Label className="text-base">Permissions</Label>
                <p className="text-xs text-text-secondary">
                  Default follows the role. Grant or deny to override for this login
                  only — e.g. allow one HR to mark attendance and block another.
                </p>
              </div>
              <div className="max-h-64 space-y-2 overflow-y-auto rounded-md border border-border p-3">
                {user.effectivePermissions.map((perm) => {
                  const mode =
                    permissionModes[perm.permission] ??
                    permissionMode(perm.permission, user.permissions)
                  return (
                    <div
                      key={perm.permission}
                      className="flex flex-wrap items-center justify-between gap-2 border-b border-border/60 pb-2 last:border-0 last:pb-0"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium">{perm.label}</p>
                        <p className="text-xs text-text-secondary">
                          Currently: {perm.effective ? 'Allowed' : 'Not allowed'}
                          {perm.source !== 'role' &&
                            ` (${perm.source === 'override_grant' ? 'granted' : 'denied'} override)`}
                        </p>
                      </div>
                      <Select
                        value={mode}
                        onValueChange={(v) =>
                          setPermissionModes((prev) => ({
                            ...prev,
                            [perm.permission]: v as PermissionMode,
                          }))
                        }
                      >
                        <SelectTrigger className="w-[130px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="default">Default</SelectItem>
                          <SelectItem value="grant">Grant</SelectItem>
                          <SelectItem value="deny">Deny</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )
                })}
              </div>
            </div>

            <div className="space-y-2 rounded-md border border-border p-3">
              <Label>Reset password</Label>
              <div className="flex gap-2">
                <Input
                  type="text"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                />
                <Button
                  variant="outline"
                  disabled={newPassword.length < 6 || passwordMutation.isPending}
                  onClick={() => passwordMutation.mutate()}
                >
                  Reset
                </Button>
              </div>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => handleClose(false)}>
            Cancel
          </Button>
          <Button
            className="bg-primary hover:bg-primary-dark"
            disabled={saveMutation.isPending || !user}
            onClick={() => saveMutation.mutate()}
          >
            {saveMutation.isPending ? 'Saving...' : 'Save changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function CreateSystemLoginDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('')
  const [branchId, setBranchId] = useState('')
  const [permissionModes, setPermissionModes] = useState<
    Partial<Record<AppPermission, PermissionMode>>
  >({})

  const { data: meta } = useQuery({
    queryKey: ['user-access-meta'],
    queryFn: () => userAccessApi.getMeta(),
  })

  const { data: branches = [] } = useQuery({
    queryKey: ['branches'],
    queryFn: () => branchesApi.getAll(),
  })

  const resetForm = () => {
    setEmail('')
    setPassword('')
    setRole('')
    setBranchId('')
    setPermissionModes({})
  }

  const mutation = useMutation({
    mutationFn: () =>
      userAccessApi.createSystemLogin({
        email,
        password,
        role,
        branchId: branchId || undefined,
        permissions: Object.entries(permissionModes)
          .filter(([, mode]) => mode && mode !== 'default')
          .map(([permission, mode]) => ({
            permission: permission as AppPermission,
            granted: mode === 'grant',
          })),
      }),
    onSuccess: () => {
      toast({ title: 'System login created' })
      resetForm()
      onOpenChange(false)
      queryClient.invalidateQueries({ queryKey: ['login-access'] })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to create login',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) resetForm()
        onOpenChange(v)
      }}
    >
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create System Login</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Email</Label>
            <Input value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Password</Label>
            <Input
              type="text"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label>Role</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger>
                <SelectValue placeholder="Select role" />
              </SelectTrigger>
              <SelectContent>
                {(meta?.assignableRoles ?? []).map((r) => (
                  <SelectItem key={r} value={r}>
                    {r.replace(/_/g, ' ')}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Branch (optional)</Label>
            <Select
              value={branchId || 'none'}
              onValueChange={(v) => setBranchId(v === 'none' ? '' : v)}
            >
              <SelectTrigger>
                <SelectValue placeholder="No branch" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No branch</SelectItem>
                {branches.map((b) => (
                  <SelectItem key={b.id} value={b.id}>
                    {formatBranchLabel(b)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {role && (
            <div className="space-y-3">
              <div>
                <Label className="text-base">Permissions</Label>
                <p className="text-xs text-text-secondary">
                  Default follows the role. Grant or deny to decide what this login
                  can see and do — the sidebar only shows sections it is allowed.
                </p>
              </div>
              <div className="max-h-64 space-y-2 overflow-y-auto rounded-md border border-border p-3">
                {(meta?.permissions ?? []).map(({ permission, label }) => (
                  <div
                    key={permission}
                    className="flex flex-wrap items-center justify-between gap-2 border-b border-border/60 pb-2 last:border-0 last:pb-0"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">{label}</p>
                      <p className="text-xs text-text-secondary">
                        Role default:{' '}
                        {roleAllowsPermission(role, permission)
                          ? 'Allowed'
                          : 'Not allowed'}
                      </p>
                    </div>
                    <Select
                      value={permissionModes[permission] ?? 'default'}
                      onValueChange={(v) =>
                        setPermissionModes((prev) => ({
                          ...prev,
                          [permission]: v as PermissionMode,
                        }))
                      }
                    >
                      <SelectTrigger className="w-[130px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Default</SelectItem>
                        <SelectItem value="grant">Grant</SelectItem>
                        <SelectItem value="deny">Deny</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="bg-primary hover:bg-primary-dark"
            disabled={
              !email ||
              password.length < 6 ||
              !role ||
              mutation.isPending
            }
            onClick={() => mutation.mutate()}
          >
            {mutation.isPending ? 'Creating...' : 'Create login'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export function LoginAccessPage() {
  const queryClient = useQueryClient()
  const { hasRole } = useAuth()
  const isSuperAdmin = hasRole(['SUPER_ADMIN'])
  const [loginType, setLoginType] = useState<LoginTypeFilter>('all')
  const [projectId, setProjectId] = useState('')
  const [branchId, setBranchId] = useState('')
  const [search, setSearch] = useState('')
  const [manageUserId, setManageUserId] = useState<string | null>(null)
  const [createOpen, setCreateOpen] = useState(false)
  const [visiblePasswords, setVisiblePasswords] = useState<Record<string, boolean>>(
    {},
  )
  const [waOpen, setWaOpen] = useState(false)
  const [waEnabled, setWaEnabled] = useState(false)

  const debouncedSearch = useDebounce(search, 300)

  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => projectsApi.getAll(),
  })

  const { data: branches = [] } = useQuery({
    queryKey: ['branches'],
    queryFn: () => branchesApi.getAll(),
  })

  const filteredBranches = useMemo(() => {
    if (!projectId) return branches
    return branches.filter((b) => b.projectId === projectId)
  }, [branches, projectId])

  const { data: records = [], isLoading, isError } = useQuery({
    queryKey: ['login-access', loginType, projectId, branchId, debouncedSearch],
    queryFn: () =>
      userAccessApi.getAll({
        employeeOnly: loginType === 'employee',
        systemOnly: loginType === 'system',
        projectId: projectId || undefined,
        branchId: branchId || undefined,
        search: debouncedSearch || undefined,
      }),
  })

  const { data: summary } = useQuery({
    queryKey: ['login-access-summary'],
    queryFn: () => userAccessApi.getSummary(),
  })

  const {
    data: waShares,
    isFetching: waLoading,
    refetch: refetchWaShares,
  } = useQuery({
    queryKey: ['portal-whatsapp-shares', projectId, branchId],
    queryFn: () =>
      userPasswordsApi.getPortalWhatsAppShares({
        projectId: projectId || undefined,
        branchId: branchId || undefined,
      }),
    enabled: waEnabled && isSuperAdmin,
  })

  const syncMutation = useMutation({
    mutationFn: () => userAccessApi.syncEmployeeLogins(),
    onSuccess: (result) => {
      toast({
        title: 'Employee logins synced',
        description: `${result.created} created, ${result.remaining} still missing`,
      })
      queryClient.invalidateQueries({ queryKey: ['login-access'] })
      queryClient.invalidateQueries({ queryKey: ['login-access-summary'] })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Sync failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const toggleMutation = useMutation({
    mutationFn: (userId: string) => userAccessApi.toggleActive(userId),
    onSuccess: (result) => {
      toast({
        title: result.isActive ? 'Login enabled' : 'Login disabled',
      })
      queryClient.invalidateQueries({ queryKey: ['login-access'] })
      queryClient.invalidateQueries({ queryKey: ['login-access-summary'] })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Action failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const { page, setPage, totalPages, paginated, total } = usePagination(
    records,
    [loginType, projectId, branchId, debouncedSearch],
  )

  const togglePassword = (id: string) => {
    setVisiblePasswords((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  const startBulkWhatsApp = async () => {
    setWaEnabled(true)
    setWaOpen(true)
    const result = await refetchWaShares()
    if (result.error) {
      toast({
        title: 'Could not prepare WhatsApp links',
        description: getApiErrorMessage(result.error, 'Error'),
        variant: 'destructive',
      })
    }
  }

  const sendOneWhatsApp = async (record: UserAccessRecord) => {
    try {
      const { item } = await userPasswordsApi.getOnePortalWhatsAppShare(
        record.id,
      )
      if (!item.ready || !item.waUrl) {
        toast({
          title: 'Cannot open WhatsApp',
          description: item.skipReason ?? 'Missing phone or password',
          variant: 'destructive',
        })
        return
      }
      window.open(item.waUrl, '_blank', 'noopener,noreferrer')
    } catch (err) {
      toast({
        title: 'WhatsApp share failed',
        description: getApiErrorMessage(err, 'Error'),
        variant: 'destructive',
      })
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold text-text-primary">
            <Shield className="h-7 w-7 text-primary" />
            Login Access Control
          </h1>
          <p className="mt-1 text-sm text-text-secondary">
            All employee (Portal) and system (HRMS) logins across every branch
            and team. Disable or revoke access for any account.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {(summary?.missingEmployeeLogins ?? 0) > 0 && (
            <Button
              variant="outline"
              disabled={syncMutation.isPending}
              onClick={() => syncMutation.mutate()}
            >
              <RefreshCw
                className={`mr-2 h-4 w-4 ${syncMutation.isPending ? 'animate-spin' : ''}`}
              />
              Sync {summary?.missingEmployeeLogins} missing logins
            </Button>
          )}
          {isSuperAdmin && (
            <Button variant="outline" onClick={startBulkWhatsApp}>
              <MessageCircle className="mr-2 h-4 w-4" />
              WhatsApp portal credentials
            </Button>
          )}
          <Button
            className="bg-primary hover:bg-primary-dark"
            onClick={() => setCreateOpen(true)}
          >
            <Plus className="mr-2 h-4 w-4" />
            Create system login
          </Button>
        </div>
      </div>

      {summary && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <Card>
            <CardContent className="p-4">
              <p className="text-2xl font-bold">{summary.total}</p>
              <p className="text-xs text-text-secondary">Total logins</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-2xl font-bold">{summary.employeeLogins}</p>
              <p className="text-xs text-text-secondary">Employee (Portal)</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-2xl font-bold">{summary.systemLogins}</p>
              <p className="text-xs text-text-secondary">System (HRMS)</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-2xl font-bold text-green-700">{summary.active}</p>
              <p className="text-xs text-text-secondary">Active</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-2xl font-bold text-red-700">{summary.disabled}</p>
              <p className="text-xs text-text-secondary">Disabled</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-2xl font-bold text-amber-700">
                {summary.missingEmployeeLogins}
              </p>
              <p className="text-xs text-text-secondary">Employees without login</p>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="flex flex-wrap items-end gap-3">
        <div className="space-y-1">
          <Label>Login type</Label>
          <Select
            value={loginType}
            onValueChange={(v) => setLoginType(v as LoginTypeFilter)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All logins</SelectItem>
              <SelectItem value="employee">Employee (Portal)</SelectItem>
              <SelectItem value="system">System (HRMS)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label>Project</Label>
          <Select
            value={projectId || 'all'}
            onValueChange={(v) => {
              setProjectId(v === 'all' ? '' : v)
              setBranchId('')
            }}
          >
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="All projects" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All projects</SelectItem>
              {projects.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label>Branch</Label>
          <Select
            value={branchId || 'all'}
            onValueChange={(v) => setBranchId(v === 'all' ? '' : v)}
          >
            <SelectTrigger className="w-[240px]">
              <SelectValue placeholder="All branches" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All branches</SelectItem>
              {filteredBranches.map((b) => (
                <SelectItem key={b.id} value={b.id}>
                  {formatBranchLabel(b)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="min-w-[220px] flex-1 space-y-1">
          <Label>Search</Label>
          <Input
            placeholder="Email, name, or employee code..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <TableRecordCount count={total} label="login account" />

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Type</TableHead>
                <TableHead>Account</TableHead>
                <TableHead>Branch</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Password</TableHead>
                <TableHead>Last login</TableHead>
                <TableHead className="w-[220px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <TableRow key={i}>
                    {[...Array(8)].map((__, j) => (
                      <TableCell key={j}>
                        <Skeleton className="h-5 w-full" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : paginated.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-text-secondary">
                    {isError
                      ? 'Could not load logins — ensure API is updated and migration is applied on the server'
                      : 'No login accounts found'}
                  </TableCell>
                </TableRow>
              ) : (
                paginated.map((record: UserAccessRecord) => {
                  const branch = loginBranch(record)
                  const password = loginPassword(record)
                  return (
                  <TableRow key={record.id}>
                    <TableCell>
                      <Badge variant="outline">
                        {record.employeeId ? 'Employee' : 'System'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <p className="font-medium">{record.email}</p>
                      {record.employee && (
                        <EmployeeNameLink
                          employee={{
                            id: record.employeeId!,
                            fullName: record.employee.fullName,
                          }}
                        />
                      )}
                    </TableCell>
                    <TableCell>
                      {branch ? formatBranchLabel(branch) : '—'}
                      {branch?.project && (
                        <p className="text-xs text-text-secondary">
                          {branch.project.name}
                        </p>
                      )}
                    </TableCell>
                    <TableCell>
                      <RoleBadges roles={[record.role]} />
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          record.isActive
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }
                      >
                        {record.isActive ? 'Active' : 'Disabled'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {password ? (
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-sm">
                            {visiblePasswords[record.id] ? password : '••••••••'}
                          </span>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0"
                            onClick={() => togglePassword(record.id)}
                          >
                            {visiblePasswords[record.id] ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      ) : (
                        '—'
                      )}
                    </TableCell>
                    <TableCell>
                      {record.lastLogin
                        ? format(new Date(record.lastLogin), 'dd/MM/yyyy HH:mm')
                        : 'Never'}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        <Button
                          size="sm"
                          variant={record.isActive ? 'outline' : 'default'}
                          className={
                            record.isActive
                              ? 'text-red-600 hover:text-red-700'
                              : 'bg-green-600 hover:bg-green-700'
                          }
                          disabled={toggleMutation.isPending}
                          onClick={() => toggleMutation.mutate(record.id)}
                        >
                          {record.isActive ? 'Disable' : 'Enable'}
                        </Button>
                        {isSuperAdmin && record.employeeId && (
                          <Button
                            size="sm"
                            variant="outline"
                            title="Send portal credentials via WhatsApp"
                            onClick={() => sendOneWhatsApp(record)}
                          >
                            <MessageCircle className="h-3.5 w-3.5" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setManageUserId(record.id)}
                        >
                          <Settings2 className="mr-1 h-3.5 w-3.5" />
                          Manage
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>

          <TablePagination
            page={page}
            totalPages={totalPages}
            total={total}
            onPageChange={setPage}
          />
        </CardContent>
      </Card>

      <ManageAccessDialog
        userId={manageUserId}
        open={!!manageUserId}
        onOpenChange={(open) => !open && setManageUserId(null)}
      />

      <CreateSystemLoginDialog open={createOpen} onOpenChange={setCreateOpen} />

      <PortalCredentialsWhatsAppDialog
        open={waOpen}
        onOpenChange={setWaOpen}
        data={waShares}
        isLoading={waLoading}
      />
    </div>
  )
}
