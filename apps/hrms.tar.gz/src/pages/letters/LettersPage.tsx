import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { differenceInHours, format, parseISO } from 'date-fns'
import {
  AlertTriangle,
  Award,
  Briefcase,
  Check,
  CheckCircle,
  Clock,
  FileText,
  Gavel,
  HelpCircle,
  Mail,
  MessageCircle,
  MoreHorizontal,
  Plus,
  RefreshCw,
  Scale,
  Shield,
  TrendingUp,
  UserCheck,
  UserMinus,
  UserPlus,
} from 'lucide-react'
import { lettersApi } from '@/api/endpoints/letters'
import { letterRepliesApi } from '@/api/endpoints/letterReplies'
import { notificationsApi } from '@/api/endpoints/notifications'
import { TablePagination } from '@/components/common/TablePagination'
import { TableRecordCount } from '@/components/common/TableRecordCount'
import { DateInput } from '@/components/common/DateInput'
import { ConfirmDialog } from '@/components/common/ConfirmDialog'
import { EmployeeSearchSelect } from '@/components/common/EmployeeSearchSelect'
import { EmployeeNameLink } from '@/components/employees/EmployeeNameLink'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { toast } from '@/hooks/use-toast'
import { useAuth } from '@/hooks/useAuth'
import { usePagination } from '@/hooks/usePagination'
import {
  getLetterExtraFields,
  getLetterRequiredFields,
  isLetterPdfUnavailable,
  isUrduLetterType,
  letterReference,
  letterTypeBadgeClass,
} from '@/lib/letterFieldConfig'
import {
  translateBranch,
  translateDesignation,
  transliterateName,
} from '@/lib/urduIdentity'
import { openLetterWhatsAppShare } from '@/lib/openLetterWhatsAppShare'
import { UrduLetterCanvas } from '@/components/letters/UrduLetterCanvas'
import { employeesApi } from '@/api/endpoints/employees'
import { cn } from '@/lib/utils'
import {
  LETTER_TYPES,
  type Letter,
  type LetterReply,
  type LetterType,
} from '@/types'

const ALL = 'ALL'

function AcknowledgementCell({ letter }: { letter: Letter }) {
  const isAcknowledgementRequired = letter.requiresAcknowledgement
  const isAcknowledged = !!letter.acknowledgement

  if (!isAcknowledgementRequired) {
    return <span className="text-gray-400">—</span>
  }

  if (isAcknowledged && letter.acknowledgement) {
    return (
      <div className="flex flex-col gap-1">
        <Badge className="w-fit bg-green-100 text-green-700 hover:bg-green-100">
          ✓ Acknowledged
        </Badge>
        <span className="text-xs text-gray-500">
          {format(
            new Date(letter.acknowledgement.acknowledgedAt),
            'dd/MM/yyyy HH:mm',
          )}
        </span>
      </div>
    )
  }

  return (
    <Badge className="w-fit bg-amber-100 text-amber-700 hover:bg-amber-100">
      Pending
    </Badge>
  )
}

function AcknowledgementDialog({
  letter,
  open,
  onOpenChange,
}: {
  letter: Letter | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const reminderMutation = useMutation({
    mutationFn: () =>
      notificationsApi.sendReminder({
        employeeId: letter!.employeeId!,
        message: `Please acknowledge the letter requiring your acknowledgement.`,
      }),
    onSuccess: () => {
      toast({ title: 'Reminder sent' })
    },
    onError: () => {
      toast({ title: 'Failed to send reminder', variant: 'destructive' })
    },
  })

  if (!letter) return null

  const ref = letterReference(letter)
  const acknowledgement = letter.acknowledgement

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Acknowledgement — {ref}</DialogTitle>
        </DialogHeader>

        {acknowledgement ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-green-600">
              <CheckCircle className="h-5 w-5" />
              <span className="font-medium">Acknowledged</span>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <label className="text-gray-500">Acknowledged At</label>
                <p>
                  {format(
                    new Date(acknowledgement.acknowledgedAt),
                    'dd/MM/yyyy HH:mm:ss',
                  )}
                </p>
              </div>
              <div>
                <label className="text-gray-500">IP Address</label>
                <p>{acknowledgement.ipAddress || 'Not recorded'}</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4 py-4 text-center text-gray-500">
            <Clock className="mx-auto mb-2 h-8 w-8 text-amber-500" />
            <p>Not yet acknowledged by employee</p>
            <p className="mt-1 text-sm">
              Employee has been notified to acknowledge this letter.
            </p>
            {letter.employeeId && (
              <Button
                className="bg-primary hover:bg-primary-dark"
                disabled={reminderMutation.isPending}
                onClick={() => reminderMutation.mutate()}
              >
                {reminderMutation.isPending ? 'Sending...' : 'Send Reminder'}
              </Button>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

function ReplyStatusCell({ letter }: { letter: Letter }) {
  if (letter.letterType !== 'SHOW_CAUSE') {
    return <span className="text-text-secondary">—</span>
  }

  if (letter.isReplied) {
    return (
      <Badge variant="outline" className="border-green-200 bg-green-50 text-green-800">
        Replied
      </Badge>
    )
  }

  const deadline = letter.replyDeadline ? new Date(letter.replyDeadline) : null
  const now = new Date()

  if (deadline && deadline < now) {
    return (
      <Badge variant="outline" className="border-red-200 bg-red-50 text-red-800">
        Overdue
      </Badge>
    )
  }

  if (deadline) {
    const hrs = Math.max(0, differenceInHours(deadline, now))
    return (
      <Badge variant="outline" className="border-amber-200 bg-amber-50 text-amber-800">
        Awaiting · {hrs} hrs remaining
      </Badge>
    )
  }

  return (
    <Badge variant="outline" className="border-amber-200 bg-amber-50 text-amber-800">
      Awaiting
    </Badge>
  )
}

function LetterRepliesDialog({
  letter,
  open,
  onOpenChange,
}: {
  letter: Letter | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const { data: replies = [], isLoading } = useQuery({
    queryKey: ['letter-replies', letter?.id],
    queryFn: () => letterRepliesApi.getRepliesByLetter(letter!.id),
    enabled: !!letter && open,
  })

  if (!letter) return null

  const ref = letterReference(letter)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Replies — {ref}</DialogTitle>
        </DialogHeader>

        {letter.autoEscalated && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">
            This letter was auto-escalated due to no reply within 48 hours
          </div>
        )}

        {isLoading ? (
          <Skeleton className="h-24 w-full" />
        ) : replies.length === 0 ? (
          <p className="py-8 text-center text-text-secondary">No replies yet</p>
        ) : (
          <div className="space-y-4">
            {(replies as LetterReply[]).map((reply) => (
              <div
                key={reply.id}
                className="rounded-lg border border-border p-4 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <p className="font-medium">
                    <EmployeeNameLink
                      employee={reply.employee}
                      fallback="Employee"
                    />
                    {reply.employee?.employeeCode && (
                      <span className="ml-2 font-mono text-xs text-text-secondary">
                        {reply.employee.employeeCode}
                      </span>
                    )}
                  </p>
                  <span className="text-xs text-text-secondary">
                    {format(new Date(reply.repliedAt), 'dd/MM/yyyy HH:mm')}
                  </span>
                </div>
                <p className="whitespace-pre-wrap text-sm">{reply.replyText}</p>
              </div>
            ))}
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

const LETTER_ICONS: Record<LetterType, React.ElementType> = {
  APPOINTMENT: Briefcase,
  WARNING: AlertTriangle,
  ADVICE: HelpCircle,
  DISCIPLINARY: Gavel,
  EXPLANATION: FileText,
  EXPLANATION_FINE: Scale,
  SHOW_CAUSE: Scale,
  FINE: Shield,
  INQUIRY: HelpCircle,
  APPRECIATION: Award,
  TRANSFER: RefreshCw,
  SUSPENSION: UserMinus,
  TERMINATION: UserMinus,
  REINSTATEMENT: UserCheck,
  REJOINING: UserPlus,
  SALARY_INCREMENT: TrendingUp,
  EXPERIENCE: Mail,
  CUSTOM: FileText,
}

function GenerateLetterWizard({
  open,
  onOpenChange,
  initialEmployeeId,
  initialLetterType,
  initialFields,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  initialEmployeeId?: string
  initialLetterType?: LetterType
  initialFields?: Record<string, string>
}) {
  const queryClient = useQueryClient()
  const [step, setStep] = useState(1)
  const [employeeId, setEmployeeId] = useState(initialEmployeeId ?? '')
  const [letterType, setLetterType] = useState<LetterType>(
    initialLetterType ?? 'WARNING',
  )
  const [fields, setFields] = useState<Record<string, string>>(
    initialFields ?? {},
  )
  const [previewHtml, setPreviewHtml] = useState<string | null>(null)
  const [downloadPrompt, setDownloadPrompt] = useState<{
    id: string
    reference: string
  } | null>(null)

  const reset = () => {
    setStep(1)
    setEmployeeId(initialEmployeeId ?? '')
    setLetterType(initialLetterType ?? 'WARNING')
    setFields(initialFields ?? {})
    setPreviewHtml(null)
  }

  useEffect(() => {
    if (!open) return
    if (initialEmployeeId) setEmployeeId(initialEmployeeId)
    if (initialLetterType) setLetterType(initialLetterType)
    if (initialFields) setFields(initialFields)
  }, [open, initialEmployeeId, initialLetterType, initialFields])

  const extraFields = getLetterExtraFields(letterType)
  const requiredFields = getLetterRequiredFields(letterType)
  const urduMode = isUrduLetterType(letterType)
  const templateFields = extraFields.filter((f) => f.onTemplate)
  const sideFields = extraFields.filter((f) => !f.onTemplate)

  const { data: employee } = useQuery({
    queryKey: ['employee', employeeId],
    queryFn: () => employeesApi.getOne(employeeId),
    enabled: open && !!employeeId && step >= 3 && urduMode,
  })

  useEffect(() => {
    if (!employee || !urduMode || step !== 3) return
    setFields((prev) => ({
      ...prev,
      senderTitle: prev.senderTitle || 'چیئرمین ایڈمن ڈیپارٹمنٹ',
      employeeName: prev.employeeName || transliterateName(employee.fullName) || '',
      designation:
        prev.designation || translateDesignation(employee.currentDesignation) || '',
      branch: prev.branch || translateBranch(employee.currentBranch?.name) || '',
    }))
  }, [employee, urduMode, step, letterType])

  const buildExtraFieldsPayload = () => {
    const payload: Record<string, string> = {}

    for (const field of extraFields) {
      const value = fields[field.key]?.trim()
      if (!value) continue

      payload[field.key] =
        field.type === 'date' ? format(parseISO(value), 'dd/MM/yyyy') : value
    }

    return payload
  }

  const requiredFieldsFilled = requiredFields.every(
    (field) => (fields[field.key] ?? '').trim().length > 0,
  )

  const previewMutation = useMutation({
    mutationFn: () =>
      lettersApi.preview({
        employeeId,
        letterType,
        extraFields: buildExtraFieldsPayload(),
      }),
    onSuccess: (data) => {
      setPreviewHtml(data.previewHtml)
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Preview failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const mutation = useMutation({
    mutationFn: () =>
      lettersApi.generate({
        employeeId,
        letterType,
        extraFields: buildExtraFieldsPayload(),
      }),
    onSuccess: (data) => {
      const ref = letterReference(data.letter)
      const isDraft = data.letter.status === 'DRAFT'
      toast({
        title: isDraft ? 'Draft letter created' : 'Letter generated',
        description: isDraft
          ? `${ref} — send to portal when ready`
          : `Reference: ${ref}`,
      })
      queryClient.invalidateQueries({ queryKey: ['letters'] })
      queryClient.invalidateQueries({ queryKey: ['letters-pending'] })
      onOpenChange(false)
      reset()
      setDownloadPrompt({ id: data.letter.id, reference: ref })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to generate letter',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const totalSteps = 4

  return (
    <>
      <Dialog
        open={open}
        onOpenChange={(v) => {
          onOpenChange(v)
          if (!v) reset()
        }}
      >
        <DialogContent className="max-h-[95vh] overflow-y-auto sm:max-w-5xl">
          <DialogHeader>
            <DialogTitle>
              Generate Letter — Step {step} of {totalSteps}
            </DialogTitle>
          </DialogHeader>

          {step === 1 && (
            <div className="space-y-4 py-2">
              <EmployeeSearchSelect
                label="Select Employee"
                value={employeeId}
                onChange={(id) => setEmployeeId(id)}
              />
            </div>
          )}

          {step === 2 && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {LETTER_TYPES.map((t) => {
                const Icon = LETTER_ICONS[t.value]
                return (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => {
                      setLetterType(t.value)
                      setFields({})
                      setPreviewHtml(null)
                    }}
                    className={cn(
                      'flex flex-col items-center gap-2 rounded-lg border p-4 text-center transition-colors hover:bg-muted',
                      letterType === t.value &&
                        'border-primary bg-primary/5 ring-1 ring-primary',
                    )}
                  >
                    <Icon className="h-6 w-6 text-primary" />
                    <span className="text-xs font-medium">{t.label}</span>
                  </button>
                )
              })}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              {urduMode ? (
                <p className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-950">
                  نیچے اصل اردو ٹیمپلیٹ ہے۔ نام، عہدہ اور وجوہات اردو میں ٹائپ
                  کریں۔
                </p>
              ) : (
                <p className="rounded-md border border-blue-200 bg-blue-50 px-3 py-2 text-sm text-blue-900">
                  This letter type uses the approved English format.
                </p>
              )}

              {urduMode ? (
                <div className="grid gap-4 lg:grid-cols-2">
                  <UrduLetterCanvas
                    letterType={letterType}
                    fields={fields}
                    onChange={(key, value) => {
                      setPreviewHtml(null)
                      setFields((f) => ({ ...f, [key]: value }))
                    }}
                    templateFields={templateFields}
                  />
                  <div className="space-y-3">
                    {sideFields.map((field) => (
                      <div key={field.key} className="space-y-2">
                        <Label>{field.label}</Label>
                        {field.type === 'select' ? (
                          <Select
                            value={fields[field.key] ?? ''}
                            onValueChange={(value) => {
                              setPreviewHtml(null)
                              setFields((f) => {
                                const normalized =
                                  value === '__custom__' ? '' : value
                                const next = { ...f, [field.key]: normalized }
                                if (field.key === 'finePreset') {
                                  const today = new Date()
                                  const monthYear = format(today, 'MMMM yyyy')
                                  if (value === 'UNIFORM') {
                                    next.fineAmount = next.fineAmount || '200/-'
                                    next.deductionMonth =
                                      next.deductionMonth || monthYear
                                  } else if (value === 'ABSENT') {
                                    next.fineAmount =
                                      next.fineAmount || 'دو یوم کی تنخواہ'
                                    next.deductionMonth =
                                      next.deductionMonth || monthYear
                                  } else if (value === 'LATE_DEDUCTION') {
                                    next.fineAmount =
                                      next.fineAmount || 'ایک یوم کی تنخواہ'
                                    next.deductionMonth =
                                      next.deductionMonth || monthYear
                                  } else if (value === 'ELECTRICITY') {
                                    next.deductionMonth =
                                      next.deductionMonth || monthYear
                                  }
                                }
                                return next
                              })
                            }}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder={field.label} />
                            </SelectTrigger>
                            <SelectContent>
                              {(field.options ?? []).map((opt) => (
                                <SelectItem
                                  key={opt.value || '__custom__'}
                                  value={opt.value || '__custom__'}
                                >
                                  {opt.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : field.type === 'textarea' ? (
                          <Textarea
                            dir="rtl"
                            lang="ur"
                            value={fields[field.key] ?? ''}
                            onChange={(e) => {
                              setPreviewHtml(null)
                              setFields((f) => ({
                                ...f,
                                [field.key]: e.target.value,
                              }))
                            }}
                          />
                        ) : (
                          <Input
                            dir={field.type === 'date' ? undefined : 'rtl'}
                            lang="ur"
                            type={
                              field.type === 'number'
                                ? 'number'
                                : field.type === 'date'
                                  ? 'date'
                                  : 'text'
                            }
                            value={fields[field.key] ?? ''}
                            onChange={(e) => {
                              setPreviewHtml(null)
                              setFields((f) => ({
                                ...f,
                                [field.key]: e.target.value,
                              }))
                            }}
                          />
                        )}
                        {field.hint ? (
                          <p className="text-xs text-text-secondary">
                            {field.hint}
                          </p>
                        ) : null}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {extraFields.map((field) => (
                    <div key={field.key} className="space-y-2">
                      <Label>{field.label}</Label>
                      {field.type === 'textarea' ? (
                        <Textarea
                          value={fields[field.key] ?? ''}
                          onChange={(e) => {
                            setPreviewHtml(null)
                            setFields((f) => ({
                              ...f,
                              [field.key]: e.target.value,
                            }))
                          }}
                        />
                      ) : (
                        <Input
                          type={
                            field.type === 'number'
                              ? 'number'
                              : field.type === 'date'
                                ? 'date'
                                : 'text'
                          }
                          value={fields[field.key] ?? ''}
                          onChange={(e) => {
                            setPreviewHtml(null)
                            setFields((f) => ({
                              ...f,
                              [field.key]: e.target.value,
                            }))
                          }}
                        />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {step === 4 && (
            <div className="space-y-3">
              <p className="text-sm text-text-secondary">
                Preview the letter before issuing. Preview does not consume a
                letter number.
              </p>
              {previewHtml ? (
                <iframe
                  title="Letter preview"
                  className="h-[55vh] w-full rounded border bg-white"
                  srcDoc={previewHtml}
                />
              ) : (
                <div className="flex h-40 items-center justify-center rounded border border-dashed text-sm text-text-secondary">
                  Click Preview to render the letter
                </div>
              )}
            </div>
          )}

          <DialogFooter className="gap-2">
            {step > 1 && (
              <Button variant="outline" onClick={() => setStep((s) => s - 1)}>
                Back
              </Button>
            )}
            {step < totalSteps ? (
              <Button
                className="bg-primary hover:bg-primary-dark"
                disabled={
                  (step === 1 && !employeeId) ||
                  (step === 3 && !requiredFieldsFilled)
                }
                onClick={() => {
                  setStep((s) => s + 1)
                  if (step === 3) {
                    setPreviewHtml(null)
                  }
                }}
              >
                Next
              </Button>
            ) : (
              <>
                <Button
                  variant="outline"
                  disabled={previewMutation.isPending || !requiredFieldsFilled}
                  onClick={() => previewMutation.mutate()}
                >
                  {previewMutation.isPending ? 'Rendering...' : 'Preview'}
                </Button>
                <Button
                  className="bg-primary hover:bg-primary-dark"
                  disabled={mutation.isPending || !previewHtml}
                  onClick={() => mutation.mutate()}
                >
                  {mutation.isPending ? 'Issuing...' : 'Issue Letter'}
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!downloadPrompt}
        title="Letter ready"
        description={
          downloadPrompt
            ? `Reference ${downloadPrompt.reference}. Download the PDF now?`
            : ''
        }
        confirmLabel="Download PDF"
        onConfirm={async () => {
          if (!downloadPrompt) return
          try {
            const { downloadLetterPdf } = await import(
              '@/lib/downloadLetterPdf'
            )
            await downloadLetterPdf(
              downloadPrompt.id,
              `${downloadPrompt.reference}.pdf`,
            )
          } catch (err) {
            toast({
              title: 'File unavailable — please reissue',
              description:
                err instanceof Error ? err.message : undefined,
              variant: 'destructive',
            })
          }
          setDownloadPrompt(null)
        }}
        onCancel={() => setDownloadPrompt(null)}
      />
    </>
  )
}

function PendingLetterShareDialog({
  letter,
  open,
  onOpenChange,
}: {
  letter: Letter | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [pdfUrl, setPdfUrl] = useState<string | null>(null)
  const [pdfError, setPdfError] = useState<string | null>(null)
  const [sending, setSending] = useState(false)

  const { data: share, isLoading: shareLoading } = useQuery({
    queryKey: ['letter-whatsapp-share', letter?.id],
    queryFn: () => lettersApi.getWhatsAppShare(letter!.id),
    enabled: !!letter && open,
  })

  useEffect(() => {
    if (!letter || !open) {
      setPdfUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev)
        return null
      })
      setPdfError(null)
      return
    }

    let revoked = false
    let objectUrl: string | null = null

    ;(async () => {
      try {
        const blob = await lettersApi.getPdf(letter.id)
        if (blob.type?.includes('application/json')) {
          throw new Error('PDF unavailable')
        }
        objectUrl = URL.createObjectURL(blob)
        if (!revoked) setPdfUrl(objectUrl)
      } catch (err) {
        if (!revoked) {
          setPdfError(
            err instanceof Error ? err.message : 'Failed to load PDF preview',
          )
        }
      }
    })()

    return () => {
      revoked = true
      if (objectUrl) URL.revokeObjectURL(objectUrl)
    }
  }, [letter, open])

  if (!letter) return null

  const ref = letterReference(letter)
  const phoneOk = Boolean(share?.phoneConfigured)

  const handleSend = async () => {
    if (!phoneOk) {
      toast({
        title: 'Phone missing',
        description: 'Add a phone number on the employee profile first.',
        variant: 'destructive',
      })
      return
    }
    setSending(true)
    try {
      await openLetterWhatsAppShare(letter.id)
      toast({
        title: 'WhatsApp opened',
        description:
          'PDF downloaded — attach it in WhatsApp Web, then send the message.',
      })
      queryClient.invalidateQueries({ queryKey: ['letters-pending'] })
      queryClient.invalidateQueries({ queryKey: ['letters'] })
      onOpenChange(false)
    } catch (err) {
      toast({
        title: 'Failed to open WhatsApp',
        description: err instanceof Error ? err.message : undefined,
        variant: 'destructive',
      })
    } finally {
      setSending(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[95vh] overflow-y-auto sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>Preview & send — {ref}</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 lg:grid-cols-2">
          <div className="space-y-2">
            <Label>Letter PDF</Label>
            {pdfError ? (
              <p className="rounded-md border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                {pdfError}
              </p>
            ) : pdfUrl ? (
              <iframe
                title="Letter PDF preview"
                src={pdfUrl}
                className="h-[420px] w-full rounded-md border border-border bg-muted"
              />
            ) : (
              <Skeleton className="h-[420px] w-full" />
            )}
          </div>

          <div className="space-y-4">
            <div className="space-y-1 text-sm">
              <p>
                <span className="text-text-secondary">Employee: </span>
                {letter.employee?.fullName ?? '—'} (
                {letter.employee?.employeeCode ?? '—'})
              </p>
              <p>
                <span className="text-text-secondary">Type: </span>
                {letter.letterType.replace(/_/g, ' ')}
              </p>
              <p>
                <span className="text-text-secondary">Phone: </span>
                {shareLoading
                  ? '…'
                  : share?.phoneE164
                    ? `+${share.phoneE164}`
                    : 'Not set — add on employee profile'}
              </p>
            </div>

            <div className="space-y-2">
              <Label>WhatsApp message</Label>
              {shareLoading ? (
                <Skeleton className="h-40 w-full" />
              ) : (
                <Textarea
                  readOnly
                  value={share?.message ?? ''}
                  className="min-h-[160px] font-normal"
                />
              )}
              <p className="text-xs text-text-secondary">
                WhatsApp Web cannot attach files automatically. Sending
                downloads the PDF and opens a prefilled chat — attach the PDF
                in WhatsApp before you send.
              </p>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="bg-primary hover:bg-primary-dark"
            disabled={sending || shareLoading || !phoneOk}
            onClick={() => void handleSend()}
          >
            <MessageCircle className="mr-2 h-4 w-4" />
            {sending ? 'Opening…' : 'Send letter'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}


export function LettersPage() {
  const queryClient = useQueryClient()
  const { hasRole } = useAuth()
  const canReverse = hasRole(['SUPER_ADMIN', 'IT_ADMIN'])
  const [searchParams] = useSearchParams()
  const [tab, setTab] = useState<'draft' | 'sent' | 'reversed' | 'pending'>(
    'draft',
  )
  const [employeeId, setEmployeeId] = useState(
    () => searchParams.get('employeeId') ?? '',
  )
  const [letterType, setLetterType] = useState(ALL)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [generateOpen, setGenerateOpen] = useState(
    () => searchParams.get('issue') === '1',
  )
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [reverseLetter, setReverseLetter] = useState<Letter | null>(null)
  const [reverseReason, setReverseReason] = useState('')
  const [repliesLetter, setRepliesLetter] = useState<Letter | null>(null)
  const [ackLetter, setAckLetter] = useState<Letter | null>(null)
  const [shareLetter, setShareLetter] = useState<Letter | null>(null)

  const prefillType = (searchParams.get('letterType') as LetterType | null) ?? undefined
  const prefillViolations = searchParams.get('violations') ?? undefined

  const filters = useMemo(
    () => ({
      employeeId: employeeId || undefined,
      letterType: letterType !== ALL ? letterType : undefined,
      startDate: startDate || undefined,
      endDate: endDate || undefined,
      status:
        tab === 'draft' || tab === 'sent' || tab === 'reversed'
          ? tab.toUpperCase()
          : undefined,
    }),
    [employeeId, letterType, startDate, endDate, tab],
  )

  const { data: letters = [], isLoading } = useQuery({
    queryKey: ['letters', filters],
    queryFn: () => lettersApi.getAll(filters),
    staleTime: 0,
    refetchOnWindowFocus: true,
    refetchInterval: 30000,
    enabled: tab !== 'pending',
  })

  const { data: pendingLetters = [], isLoading: pendingLoading } = useQuery({
    queryKey: ['letters-pending'],
    queryFn: () => lettersApi.getPending(),
    staleTime: 0,
    refetchOnWindowFocus: true,
    refetchInterval: 30000,
  })

  const letterList = letters as Letter[]
  const pendingList = pendingLetters as Letter[]

  const { page, setPage, totalPages, paginated, total } = usePagination(
    letterList,
    [filters],
  )

  const {
    page: pendingPage,
    setPage: setPendingPage,
    totalPages: pendingTotalPages,
    paginated: pendingPaginated,
    total: pendingTotal,
  } = usePagination(pendingList, [])

  const markPrintedMutation = useMutation({
    mutationFn: (id: string) => lettersApi.markPrinted(id),
    onSuccess: () => {
      toast({ title: 'Letter marked as printed' })
      queryClient.invalidateQueries({ queryKey: ['letters'] })
    },
    onError: () => {
      toast({ title: 'Failed to mark printed', variant: 'destructive' })
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => lettersApi.delete(id),
    onSuccess: () => {
      toast({ title: 'Letter deleted' })
      queryClient.invalidateQueries({ queryKey: ['letters'] })
      queryClient.invalidateQueries({ queryKey: ['letters-pending'] })
      setDeleteId(null)
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to delete letter',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? ''),
        variant: 'destructive',
      })
    },
  })

  const sendMutation = useMutation({
    mutationFn: (id: string) => lettersApi.send(id),
    onSuccess: (data) => {
      toast({
        title: data.alreadySent ? 'Already on portal' : 'Sent to portal',
        description: data.message,
      })
      queryClient.invalidateQueries({ queryKey: ['letters'] })
      queryClient.invalidateQueries({ queryKey: ['letters-pending'] })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Send failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? ''),
        variant: 'destructive',
      })
    },
  })

  const reverseMutation = useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) =>
      lettersApi.reverse(id, reason),
    onSuccess: (data) => {
      toast({ title: 'Letter reversed', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['letters'] })
      setReverseLetter(null)
      setReverseReason('')
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Reverse failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? ''),
        variant: 'destructive',
      })
    },
  })

  const downloadPdf = async (letter: Letter) => {
    try {
      const { downloadLetterPdf } = await import('@/lib/downloadLetterPdf')
      await downloadLetterPdf(
        letter.id,
        `${letterReference(letter)}.pdf`,
      )
    } catch (err) {
      toast({
        title: 'File unavailable — please reissue',
        description: err instanceof Error ? err.message : undefined,
        variant: 'destructive',
      })
    }
  }

  const clearFilters = () => {
    setEmployeeId('')
    setLetterType(ALL)
    setStartDate('')
    setEndDate('')
    setPage(0)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold text-text-primary">
          Letter Management
        </h1>
        <Button
          className="bg-primary hover:bg-primary-dark"
          onClick={() => setGenerateOpen(true)}
        >
          <Plus className="mr-2 h-4 w-4" />
          Generate Letter
        </Button>
      </div>

      <Tabs
        value={tab}
        onValueChange={(v) =>
          setTab(v as 'draft' | 'sent' | 'reversed' | 'pending')
        }
      >
        <TabsList>
          <TabsTrigger value="draft">Draft</TabsTrigger>
          <TabsTrigger value="sent">Sent</TabsTrigger>
          <TabsTrigger value="reversed">Reversed</TabsTrigger>
          <TabsTrigger value="pending" className="gap-2">
            WhatsApp pending
            {pendingTotal > 0 ? (
              <Badge
                variant="secondary"
                className="h-5 min-w-5 justify-center rounded-full px-1.5 text-xs"
              >
                {pendingTotal}
              </Badge>
            ) : null}
          </TabsTrigger>
        </TabsList>

        {(tab === 'draft' || tab === 'sent' || tab === 'reversed') && (
          <div className="mt-4 space-y-4">
          <div className="flex flex-wrap items-end gap-3 rounded-lg border border-border bg-white p-4">
            <div className="min-w-[220px] flex-1">
              <EmployeeSearchSelect
                label="Employee"
                value={employeeId}
                onChange={setEmployeeId}
                placeholder="Filter by employee..."
              />
            </div>

            <div className="space-y-1">
              <Label>Letter Type</Label>
              <Select value={letterType} onValueChange={setLetterType}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={ALL}>All Types</SelectItem>
                  {LETTER_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <Label>From</Label>
              <DateInput
                className="w-[150px]"
                value={startDate}
                onChange={setStartDate}
              />
            </div>

            <div className="space-y-1">
              <Label>To</Label>
              <DateInput
                className="w-[150px]"
                value={endDate}
                onChange={setEndDate}
              />
            </div>

            <Button variant="outline" onClick={clearFilters}>
              Clear Filters
            </Button>
          </div>

          <TableRecordCount count={total} label="letter" />

          <div className="rounded-lg border border-border bg-white">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Reference</TableHead>
                  <TableHead>Employee</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Generated</TableHead>
                  <TableHead>Printed</TableHead>
                  <TableHead>Replies</TableHead>
                  <TableHead>Acknowledgement</TableHead>
                  <TableHead className="w-[50px]" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  [...Array(5)].map((_, i) => (
                    <TableRow key={i}>
                      {[...Array(8)].map((__, j) => (
                        <TableCell key={j}>
                          <Skeleton className="h-5 w-full" />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : paginated.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={8}
                      className="h-32 text-center text-text-secondary"
                    >
                      No letters found
                    </TableCell>
                  </TableRow>
                ) : (
                  paginated.map((letter) => (
                    <TableRow key={letter.id}>
                      <TableCell>
                        <div className="space-y-1">
                          <Badge
                            variant="outline"
                            className="font-mono text-xs"
                          >
                            {letter.letterNo ?? letterReference(letter)}
                          </Badge>
                          {isLetterPdfUnavailable(letter) && (
                            <p className="text-xs text-amber-700">
                              PDF missing on disk — download will try to rebuild
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <EmployeeNameLink employee={letter.employee} />
                          <p className="font-mono text-xs text-text-secondary">
                            {letter.employee?.employeeCode ?? '—'}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={letterTypeBadgeClass(letter.letterType)}
                        >
                          {letter.letterType.replace(/_/g, ' ')}
                        </Badge>
                        {letter.status ? (
                          <Badge
                            variant="secondary"
                            className="ml-2 font-normal"
                          >
                            {letter.status}
                          </Badge>
                        ) : null}
                      </TableCell>
                      <TableCell>
                        {format(
                          new Date(letter.generatedAt),
                          'dd/MM/yyyy HH:mm',
                        )}
                      </TableCell>
                      <TableCell>
                        {letter.printedAt ? (
                          <Check className="h-5 w-5 text-green-600" />
                        ) : (
                          <span className="text-text-secondary">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <ReplyStatusCell letter={letter} />
                      </TableCell>
                      <TableCell>
                        <AcknowledgementCell letter={letter} />
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => downloadPdf(letter)}
                            >
                              Download PDF
                            </DropdownMenuItem>
                            {letter.status === 'DRAFT' && (
                              <DropdownMenuItem
                                onClick={() => sendMutation.mutate(letter.id)}
                              >
                                Send to portal
                              </DropdownMenuItem>
                            )}
                            {letter.letterType === 'SHOW_CAUSE' && (
                              <DropdownMenuItem
                                onClick={() => setRepliesLetter(letter)}
                              >
                                View Replies
                              </DropdownMenuItem>
                            )}
                            {letter.requiresAcknowledgement && (
                              <DropdownMenuItem
                                onClick={() => setAckLetter(letter)}
                              >
                                View Acknowledgement
                              </DropdownMenuItem>
                            )}
                            {letter.status === 'SENT' && (
                              <DropdownMenuItem
                                disabled={!!letter.printedAt}
                                onClick={() =>
                                  markPrintedMutation.mutate(letter.id)
                                }
                              >
                                Mark as Printed
                              </DropdownMenuItem>
                            )}
                            {canReverse && letter.status === 'SENT' && (
                              <DropdownMenuItem
                                className="text-red-600"
                                onClick={() => setReverseLetter(letter)}
                              >
                                Reverse (IT)
                              </DropdownMenuItem>
                            )}
                            {letter.status === 'DRAFT' && (
                              <DropdownMenuItem
                                className="text-red-600"
                                onClick={() => setDeleteId(letter.id)}
                              >
                                Delete draft
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>

            <TablePagination
              page={page}
              totalPages={totalPages}
              total={total}
              onPageChange={setPage}
            />
          </div>
          </div>
        )}

        <TabsContent value="pending" className="space-y-4">
          <p className="text-sm text-text-secondary">
            Letters waiting to be sent via WhatsApp Web. Preview the PDF, then
            send — attach the downloaded file in WhatsApp.
          </p>

          <TableRecordCount count={pendingTotal} label="pending letter" />

          <div className="rounded-lg border border-border bg-white">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Reference</TableHead>
                  <TableHead>Employee</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Generated</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingLoading ? (
                  [...Array(5)].map((_, i) => (
                    <TableRow key={i}>
                      {[...Array(6)].map((__, j) => (
                        <TableCell key={j}>
                          <Skeleton className="h-5 w-full" />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : pendingPaginated.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="h-32 text-center text-text-secondary"
                    >
                      No pending letters
                    </TableCell>
                  </TableRow>
                ) : (
                  pendingPaginated.map((letter) => {
                    const hasPhone = Boolean(letter.employee?.phone?.trim())
                    return (
                      <TableRow key={letter.id}>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className="font-mono text-xs"
                          >
                            {letter.letterNo ?? letterReference(letter)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div>
                            <EmployeeNameLink
                              employee={{
                                id: letter.employee?.id ?? letter.employeeId,
                                fullName: letter.employee?.fullName,
                                employeeCode: letter.employee?.employeeCode,
                              }}
                            />
                            <p className="font-mono text-xs text-text-secondary">
                              {letter.employee?.employeeCode ?? '—'}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={letterTypeBadgeClass(letter.letterType)}
                          >
                            {letter.letterType.replace(/_/g, ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {format(
                            new Date(letter.generatedAt),
                            'dd/MM/yyyy HH:mm',
                          )}
                        </TableCell>
                        <TableCell>
                          {hasPhone ? (
                            <span className="tabular-nums text-sm">
                              {letter.employee?.phone}
                            </span>
                          ) : (
                            <span className="text-sm text-amber-700">
                              Add phone on profile
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setShareLetter(letter)}
                            >
                              Preview
                            </Button>
                            <Button
                              size="sm"
                              className="bg-primary hover:bg-primary-dark"
                              disabled={!hasPhone}
                              onClick={() => setShareLetter(letter)}
                            >
                              <MessageCircle className="mr-1.5 h-3.5 w-3.5" />
                              Send letter
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })
                )}
              </TableBody>
            </Table>

            <TablePagination
              page={pendingPage}
              totalPages={pendingTotalPages}
              total={pendingTotal}
              onPageChange={setPendingPage}
            />
          </div>
        </TabsContent>
      </Tabs>

      <GenerateLetterWizard
        open={generateOpen}
        onOpenChange={setGenerateOpen}
        initialEmployeeId={employeeId || undefined}
        initialLetterType={prefillType}
        initialFields={
          prefillViolations ? { violations: prefillViolations } : undefined
        }
      />

      <LetterRepliesDialog
        letter={repliesLetter}
        open={!!repliesLetter}
        onOpenChange={(v) => !v && setRepliesLetter(null)}
      />

      <AcknowledgementDialog
        letter={ackLetter}
        open={!!ackLetter}
        onOpenChange={(v) => !v && setAckLetter(null)}
      />

      <PendingLetterShareDialog
        letter={shareLetter}
        open={!!shareLetter}
        onOpenChange={(v) => !v && setShareLetter(null)}
      />

      <Dialog
        open={!!reverseLetter}
        onOpenChange={(v) => {
          if (!v) {
            setReverseLetter(null)
            setReverseReason('')
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reverse letter (IT)</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-text-secondary">
            This voids the letter on the portal and unwinds linked pending fines
            where safe.
          </p>
          <div className="space-y-2">
            <Label>Reason</Label>
            <Textarea
              value={reverseReason}
              onChange={(e) => setReverseReason(e.target.value)}
              placeholder="Why is this letter being reversed?"
            />
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setReverseLetter(null)
                setReverseReason('')
              }}
            >
              Cancel
            </Button>
            <Button
              className="bg-red-600 hover:bg-red-700"
              disabled={
                reverseReason.trim().length < 3 || reverseMutation.isPending
              }
              onClick={() => {
                if (!reverseLetter) return
                reverseMutation.mutate({
                  id: reverseLetter.id,
                  reason: reverseReason.trim(),
                })
              }}
            >
              Reverse letter
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteId}
        title="Delete draft letter"
        description="Are you sure you want to delete this draft? This action cannot be undone."
        confirmLabel="Delete"
        confirmVariant="destructive"
        loading={deleteMutation.isPending}
        onConfirm={() => deleteId && deleteMutation.mutate(deleteId)}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  )
}
