import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { format } from 'date-fns'
import { Search } from 'lucide-react'
import { useSearchParams } from 'react-router-dom'
import { attendanceApi } from '@/api/endpoints/attendance'
import { leaveApi } from '@/api/endpoints/leave'
import { shiftsApi } from '@/api/endpoints/shifts'
import { TablePagination } from '@/components/common/TablePagination'
import { TableRecordCount } from '@/components/common/TableRecordCount'
import { DateInput } from '@/components/common/DateInput'
import {
  EmployeeSearchSelect,
} from '@/components/common/EmployeeSearchSelect'
import { UpdateAttendanceDialog } from '@/components/attendance/UpdateAttendanceDialog'
import { AttendanceStatusBadge } from '@/components/attendance/AttendanceStatusBadge'
import { TimeInput12Hour } from '@/components/common/TimeInput12Hour'
import { combineCheckOutDateTime, combineDateAndTime } from '@/lib/attendanceUtils'
import { canHrCorrectAttendance } from '@/lib/attendanceEligibility'
import {
  CheckInManualTab,
  CheckOutManualTab,
  MarkLeaveManualTab,
} from '@/components/attendance/ManualAttendanceTabs'
import {
  createEmployeeFilters,
  EmployeeFiltersBar,
  employeeFiltersToAttendanceParams,
} from '@/components/employees/EmployeeFiltersBar'
import { EmployeeNameLink } from '@/components/employees/EmployeeNameLink'
import { formatBranchTableLabel } from '@/lib/formatBranchLabel'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { toast } from '@/hooks/use-toast'
import { useAuth } from '@/hooks/useAuth'
import { useDebounce } from '@/hooks/useDebounce'
import { usePagination } from '@/hooks/usePagination'
import { getLogLateMinutes } from '@/lib/attendanceUtils'
import { formatShiftOptionLabel } from '@/lib/shiftFilterUtils'
import { formatDateTimeTime, toPakistanTime24, todayPakistan } from '@/lib/timeFormat'
import { cn } from '@/lib/utils'
import { MutualSwapTab } from '@/pages/attendance/MutualSwapTab'
import {
  ATTENDANCE_STATUSES,
  type AttendanceLog,
  type Employee,
  type RelieverSession,
} from '@/types'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

const ALL = 'ALL'

function formatLogShift(log: AttendanceLog): string {
  const emp = log.employee
  // Prefer this row's own duty snapshot (locked in at creation) so a later
  // duty change never retroactively alters how a past record displays.
  // emp?.shift?.startTime/endTime is already snapshot-resolved by the
  // backend; emp?.dutyStartTime/dutyEndTime (current duty) is the last
  // resort, for legacy rows with no snapshot and no shift.
  const start =
    log.dutyStartTimeSnapshot ?? emp?.shift?.startTime ?? emp?.dutyStartTime
  const end =
    log.dutyEndTimeSnapshot ?? emp?.shift?.endTime ?? emp?.dutyEndTime
  const name = emp?.shift?.name
  if (!start || !end) return name ?? '—'
  return formatShiftOptionLabel({
    name: name ?? 'Duty',
    startTime: start,
    endTime: end,
  })
}

function formatDuration(minutes: number) {
  const h = Math.floor(minutes / 60)
  const m = minutes % 60
  if (h > 0) return `${h}h ${m}m`
  return `${m} min`
}

function isAbsentStatus(status: string) {
  return status === 'ABSENT' || status === 'UNINFORMED_ABSENT'
}

function AssignAbsentRelieverDialog({
  log,
  date,
  open,
  onOpenChange,
}: {
  log: AttendanceLog | null
  date: string
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const [relieverId, setRelieverId] = useState('')
  const [selectedReliever, setSelectedReliever] = useState<Employee | undefined>()
  const [reason, setReason] = useState('Reliever assigned for absence')

  const employeeName = log?.employee?.fullName ?? 'employee'

  const mutation = useMutation({
    mutationFn: () =>
      leaveApi.markVerified({
        employeeId: log!.employeeId!,
        startDate: date,
        endDate: date,
        leaveType: 'EMERGENCY',
        reason: reason.trim() || 'Reliever assigned for absence',
        relieverId,
      }),
    onSuccess: () => {
      toast({
        title: 'Reliever assigned',
        description: `${employeeName} marked on leave with covering reliever.`,
      })
      queryClient.invalidateQueries({ queryKey: ['attendance'] })
      queryClient.invalidateQueries({ queryKey: ['leave'] })
      queryClient.invalidateQueries({ queryKey: ['leave-balance'] })
      queryClient.invalidateQueries({ queryKey: ['payroll-entries'] })
      queryClient.invalidateQueries({ queryKey: ['payroll-summary'] })
      queryClient.invalidateQueries({ queryKey: ['payroll-history'] })
      setRelieverId('')
      setSelectedReliever(undefined)
      setReason('Reliever assigned for absence')
      onOpenChange(false)
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to assign reliever',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  if (!log) return null

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) {
          setRelieverId('')
          setSelectedReliever(undefined)
          setReason('Reliever assigned for absence')
        }
        onOpenChange(next)
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Assign Reliever for {employeeName}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-sm">
          <div className="rounded-lg border border-border bg-surface p-3">
            <p>
              <span className="text-text-secondary">Date: </span>
              {format(new Date(`${date}T00:00:00`), 'dd/MM/yyyy')}
            </p>
            <p className="mt-1">
              <span className="text-text-secondary">Status: </span>
              {log.status.replace(/_/g, ' ')}
            </p>
            <p className="mt-2 text-xs text-text-secondary">
              Marks the day as verified leave and assigns the selected reliever.
            </p>
          </div>
          <EmployeeSearchSelect
            label="Select Reliever"
            value={relieverId}
            onChange={(id, emp) => {
              setRelieverId(id)
              setSelectedReliever(emp)
            }}
            excludeIds={log?.employeeId ? [log.employeeId] : []}
          />
          {selectedReliever?.shift && (
            <p className="text-sm">
              {selectedReliever.fullName} — Shift:{' '}
              {formatShiftOptionLabel({
                name: selectedReliever.shift.name ?? '',
                startTime: selectedReliever.shift.startTime ?? '',
                endTime: selectedReliever.shift.endTime ?? '',
              })}
            </p>
          )}
          <div className="space-y-1">
            <Label>Reason</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={2}
              placeholder="Reason for leave / coverage..."
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            disabled={
              !relieverId ||
              !log?.employeeId ||
              reason.trim().length < 3 ||
              mutation.isPending
            }
            onClick={() => mutation.mutate()}
          >
            {mutation.isPending ? 'Assigning...' : 'Assign Reliever'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function DailyLogTab({
  initialStatus = ALL,
  initialDate,
}: {
  initialStatus?: string
  initialDate?: string
}) {
  const queryClient = useQueryClient()
  const { user, hasRole } = useAuth()
  const canFullyEditAttendance = hasRole([
    'SUPER_ADMIN',
    'IT_ADMIN',
    'HR_EXECUTIVE',
    'HR_MANAGER',
    'HR_ADMIN_MANAGER',
    'HR_OPERATIONS_MANAGER',
  ])
  const today = todayPakistan()
  const [date, setDate] = useState(initialDate ?? today)
  const [search, setSearch] = useState('')
  const [employeeFilters, setEmployeeFilters] = useState(() =>
    createEmployeeFilters(user),
  )
  const [statusFilter, setStatusFilter] = useState(initialStatus)
  const [dutyFilter, setDutyFilter] = useState<'onDutyNow' | 'all'>(
    (initialDate ?? today) === today ? 'onDutyNow' : 'all',
  )
  const [updateLog, setUpdateLog] = useState<AttendanceLog | null>(null)
  const [relieverLog, setRelieverLog] = useState<AttendanceLog | null>(null)

  const isToday = date === today
  const effectiveDutyFilter = isToday ? dutyFilter : 'all'

  useEffect(() => {
    if (!isToday && dutyFilter !== 'all') {
      setDutyFilter('all')
    }
  }, [isToday, dutyFilter])

  const debouncedSearch = useDebounce(search, 400)

  const { data: shifts = [] } = useQuery({
    queryKey: ['shifts'],
    queryFn: () => shiftsApi.getAll(),
  })

  const queryParams = useMemo(
    () => ({
      startDate: date,
      endDate: date,
      status: statusFilter !== ALL ? statusFilter : undefined,
      search: debouncedSearch || undefined,
      dutyFilter: effectiveDutyFilter,
      ...employeeFiltersToAttendanceParams(employeeFilters, shifts),
    }),
    [
      date,
      statusFilter,
      debouncedSearch,
      employeeFilters,
      shifts,
      effectiveDutyFilter,
    ],
  )

  const { data: allTodayLogs = [] } = useQuery({
    queryKey: ['attendance', { ...queryParams, dutyFilter: 'all', _countOnly: true }],
    queryFn: () =>
      attendanceApi.getAll({ ...queryParams, dutyFilter: 'all' }),
    enabled: isToday && effectiveDutyFilter === 'onDutyNow',
  })

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ['attendance', queryParams],
    queryFn: () => attendanceApi.getAll(queryParams),
    refetchInterval: isToday ? 60_000 : false,
  })

  const attendanceLogs = logs as AttendanceLog[]
  const totalBeforeFilter =
    effectiveDutyFilter === 'onDutyNow'
      ? (allTodayLogs as AttendanceLog[]).length
      : attendanceLogs.length

  const summary = useMemo(() => {
    const total = attendanceLogs.length
    const present = attendanceLogs.filter((l) => l.status === 'PRESENT').length
    const absent = attendanceLogs.filter((l) => l.status === 'ABSENT').length
    const unmarked = attendanceLogs.filter((l) => l.status === 'UNMARKED').length
    const late = attendanceLogs.filter((l) => l.status === 'LATE').length
    const uninformedAbsent = attendanceLogs.filter(
      (l) => l.status === 'UNINFORMED_ABSENT',
    ).length
    const halfDay = attendanceLogs.filter((l) => l.status === 'HALF_DAY').length
    const shortLeave = attendanceLogs.filter(
      (l) => l.status === 'SHORT_LEAVE',
    ).length
    const onLeave = attendanceLogs.filter((l) => l.status === 'ON_LEAVE').length
    const holiday = attendanceLogs.filter((l) => l.status === 'HOLIDAY').length
    const swapCovered = attendanceLogs.filter(
      (l) => l.status === 'SWAP_COVERED',
    ).length
    return {
      total,
      present,
      absent,
      unmarked,
      late,
      uninformedAbsent,
      halfDay,
      shortLeave,
      onLeave,
      holiday,
      swapCovered,
    }
  }, [attendanceLogs])

  const { page, setPage, totalPages, paginated, total } = usePagination(
    attendanceLogs,
    [queryParams],
  )

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="flex flex-wrap items-end gap-3">
          <div className="space-y-1">
            <Label>Date</Label>
            <DateInput
              className="w-full max-w-[160px]"
              value={date}
              onChange={setDate}
            />
          </div>

          <div className="space-y-1">
            <Label>Attendance Status</Label>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>All Statuses</SelectItem>
                {ATTENDANCE_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s.replace(/_/g, ' ')}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <Label>Duty window</Label>
            <div className="flex rounded-md border border-border p-0.5">
              <Button
                type="button"
                size="sm"
                variant={effectiveDutyFilter === 'onDutyNow' ? 'default' : 'ghost'}
                className="h-8"
                disabled={!isToday}
                onClick={() => setDutyFilter('onDutyNow')}
              >
                On duty now
              </Button>
              <Button
                type="button"
                size="sm"
                variant={effectiveDutyFilter === 'all' ? 'default' : 'ghost'}
                className="h-8"
                onClick={() => setDutyFilter('all')}
              >
                All employees
              </Button>
            </div>
          </div>
        </div>
      </div>

      <p className="text-sm text-text-secondary">
        Showing {attendanceLogs.length}
        {effectiveDutyFilter === 'onDutyNow'
          ? ` of ${totalBeforeFilter} (on duty now)`
          : ' employees'}
      </p>

      <div className="rounded-lg border border-border bg-white p-4 space-y-4">
        <div className="relative min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-text-secondary" />
          <Input
            placeholder="Search by name, code, CNIC, branch..."
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <EmployeeFiltersBar
          filters={employeeFilters}
          onChange={setEmployeeFilters}
        />
      </div>

      <TableRecordCount
        count={total}
        label="attendance record"
        extra={
          !isLoading && total > 0 ? (
            <p className="text-sm text-text-secondary">
              Present: {summary.present} | Unmarked: {summary.unmarked} | Absent:{' '}
              {summary.absent} | Uninformed Absent: {summary.uninformedAbsent} | Late:{' '}
              {summary.late} | Half Day: {summary.halfDay} | Short Leave:{' '}
              {summary.shortLeave} | On Leave: {summary.onLeave} | Holiday:{' '}
              {summary.holiday} | Swap: {summary.swapCovered}
            </p>
          ) : undefined
        }
      />

      <div className="rounded-lg border border-border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead>
              <TableHead>Employee Name</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Designation</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Branch</TableHead>
              <TableHead>Shift</TableHead>
              <TableHead>Check In</TableHead>
              <TableHead>Check Out</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Late Minutes</TableHead>
              <TableHead>Overtime</TableHead>
              <TableHead>Source</TableHead>
              {canFullyEditAttendance && <TableHead>Actions</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  {[...Array(canFullyEditAttendance ? 14 : 13)].map((__, j) => (
                    <TableCell key={j}>
                      <Skeleton className="h-5 w-full" />
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : paginated.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={canFullyEditAttendance ? 14 : 13}
                  className="h-32 text-center text-text-secondary"
                >
                  No attendance records for this date
                </TableCell>
              </TableRow>
            ) : (
              paginated.map((log) => {
                const displayLateMinutes = getLogLateMinutes(log)
                return (
                <TableRow key={log.id}>
                  <TableCell className="font-mono text-sm">
                    {log.employee?.employeeCode ?? '—'}
                  </TableCell>
                  <TableCell>
                    <EmployeeNameLink
                      employee={log.employee}
                      employeeId={log.employeeId}
                    />
                  </TableCell>
                  <TableCell>
                    {log.employee?.currentDepartment?.name ?? '—'}
                  </TableCell>
                  <TableCell>
                    {log.employee?.currentDesignation ?? '—'}
                  </TableCell>
                  <TableCell>
                    {log.employee?.phone ? (
                      <a
                        href={`tel:${log.employee.phone}`}
                        className="text-sm text-blue-600 hover:underline"
                      >
                        {log.employee.phone}
                      </a>
                    ) : (
                      '—'
                    )}
                  </TableCell>
                  <TableCell className="text-text-secondary">
                    {formatBranchTableLabel(log.branch)}
                  </TableCell>
                  <TableCell className="text-sm text-text-secondary">
                    {formatLogShift(log)}
                  </TableCell>
                  <TableCell className="text-text-secondary">
                    {formatDateTimeTime(log.checkIn)}
                  </TableCell>
                  <TableCell className="text-text-secondary">
                    {formatDateTimeTime(log.checkOut)}
                  </TableCell>
                  <TableCell>
                    <AttendanceStatusBadge status={log.status} note={log.note} />
                  </TableCell>
                  <TableCell
                    className={cn(
                      displayLateMinutes > 0 && 'font-medium text-red-600',
                    )}
                  >
                    {displayLateMinutes > 0 ? displayLateMinutes : '—'}
                  </TableCell>
                  <TableCell
                    className={cn(
                      (log.overtimeMinutes ?? 0) > 0 &&
                        !log.overtimePending &&
                        'font-medium text-green-600',
                    )}
                  >
                    {log.overtimePending ? (
                      <Badge className="border-amber-200 bg-amber-100 text-amber-800">
                        Pending Approval
                      </Badge>
                    ) : (log.overtimeMinutes ?? 0) > 0 ||
                      log.overtimeApprovedBy ? (
                      `${log.overtimeMinutes ?? 0} min`
                    ) : (
                      '—'
                    )}
                  </TableCell>
                  <TableCell>
                    {log.source === 'BIOMETRIC' ? (
                      <Badge className="bg-blue-100 text-blue-800">BIOMETRIC</Badge>
                    ) : (
                      <Badge variant="outline" className="text-gray-600">
                        MANUAL
                      </Badge>
                    )}
                  </TableCell>
                  {canFullyEditAttendance && (
                  <TableCell>
                    <div className="flex flex-wrap gap-2">
                      {canHrCorrectAttendance(log.employee?.status) ? (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setUpdateLog(log)}
                          >
                            Update
                          </Button>
                          {isAbsentStatus(log.status) && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setRelieverLog(log)}
                            >
                              Assign Reliever
                            </Button>
                          )}
                        </>
                      ) : (
                        <span className="text-xs text-text-secondary">Locked</span>
                      )}
                    </div>
                  </TableCell>
                  )}
                </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>

        <TablePagination
          page={page}
          totalPages={totalPages}
          total={total}
          onPageChange={setPage}
        />
      </div>

      <UpdateAttendanceDialog
        log={updateLog}
        open={!!updateLog}
        onOpenChange={(open) => {
          if (!open) setUpdateLog(null)
        }}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ['attendance'] })
          queryClient.invalidateQueries({ queryKey: ['payroll-entries'] })
          queryClient.invalidateQueries({ queryKey: ['payroll-summary'] })
          queryClient.invalidateQueries({ queryKey: ['payroll-history'] })
          queryClient.invalidateQueries({ queryKey: ['leave'] })
          queryClient.invalidateQueries({ queryKey: ['leave-balance'] })
        }}
      />

      <AssignAbsentRelieverDialog
        log={relieverLog}
        date={date}
        open={!!relieverLog}
        onOpenChange={(open) => {
          if (!open) setRelieverLog(null)
        }}
      />
    </div>
  )
}

/**
 * HR correction to an existing RelieverSession's checkIn/checkOut — the
 * Reliever equivalent of UpdateAttendanceDialog for normal AttendanceLog
 * rows. Mirrors its layout (current values shown as context, editable time
 * fields below) but only exposes the two fields that make sense for a
 * RelieverSession — no status field, since Reliever attendance has no
 * status concept.
 */
function UpdateRelieverSessionDialog({
  session,
  open,
  onOpenChange,
  onSuccess,
}: {
  session: RelieverSession | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess: () => void
}) {
  const [checkIn, setCheckIn] = useState('')
  const [checkOut, setCheckOut] = useState('')

  useEffect(() => {
    if (open && session) {
      setCheckIn(session.checkIn ? toPakistanTime24(session.checkIn) : '')
      setCheckOut(session.checkOut ? toPakistanTime24(session.checkOut) : '')
    }
  }, [open, session])

  const mutation = useMutation({
    mutationFn: () => {
      if (!session?.id) throw new Error('No reliever session selected')
      const dateOnly = session.date.slice(0, 10)
      const payload: { checkIn?: string; checkOut?: string } = {}
      if (checkIn) {
        payload.checkIn = combineDateAndTime(dateOnly, checkIn)
      }
      if (checkOut) {
        payload.checkOut = combineCheckOutDateTime(
          dateOnly,
          payload.checkIn ?? session.checkIn,
          checkOut,
        )
      }
      return attendanceApi.updateRelieverSession(session.id, payload)
    },
    onSuccess: () => {
      toast({ title: 'Reliever attendance updated' })
      onSuccess()
      onOpenChange(false)
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to update Reliever attendance',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  if (!session) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Update Reliever Attendance</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-sm">
          <div className="rounded-lg border border-border bg-surface p-3 space-y-1">
            <p>
              <span className="text-text-secondary">Reliever: </span>
              {session.employee?.fullName ?? '—'}
            </p>
            <p>
              <span className="text-text-secondary">Covering: </span>
              {session.coveringEmployee?.fullName ?? '—'}
            </p>
            <p>
              <span className="text-text-secondary">Session date: </span>
              {format(new Date(session.date), 'dd/MM/yyyy')}
            </p>
            <p>
              <span className="text-text-secondary">Current Check In: </span>
              {formatDateTimeTime(session.checkIn)}
            </p>
            <p>
              <span className="text-text-secondary">Current Check Out: </span>
              {formatDateTimeTime(session.checkOut)}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Corrected Check In</Label>
              <TimeInput12Hour value={checkIn} onChange={setCheckIn} />
            </div>
            <div className="space-y-2">
              <Label>Corrected Check Out</Label>
              <TimeInput12Hour
                value={checkOut}
                onChange={setCheckOut}
                disabled={!checkIn}
              />
            </div>
          </div>
          <p className="text-xs text-text-secondary">
            Correcting these times recalculates payable Reliever minutes the
            next time payroll is generated or refreshed for this month.
            Already PROCESSED or PAID payroll is not affected.
          </p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="bg-primary hover:bg-primary-dark"
            disabled={mutation.isPending || (!checkIn && !checkOut)}
            onClick={() => mutation.mutate()}
          >
            {mutation.isPending ? 'Saving...' : 'Save Changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function RelieverSessionsTab() {
  const queryClient = useQueryClient()
  const { user } = useAuth()
  const today = format(new Date(), 'yyyy-MM-dd')
  const [date, setDate] = useState(today)
  const [employeeFilters, setEmployeeFilters] = useState(() =>
    createEmployeeFilters(user),
  )
  const [actionId, setActionId] = useState<string | null>(null)
  const [updateSession, setUpdateSession] = useState<RelieverSession | null>(
    null,
  )

  const { data: shifts = [] } = useQuery({
    queryKey: ['shifts'],
    queryFn: () => shiftsApi.getAll(),
  })

  const queryParams = useMemo(
    () => ({
      startDate: date,
      endDate: date,
      ...employeeFiltersToAttendanceParams(employeeFilters, shifts),
    }),
    [date, employeeFilters, shifts],
  )

  const { data: sessions = [], isLoading } = useQuery({
    queryKey: ['reliever-sessions', queryParams],
    queryFn: () => attendanceApi.listRelieverSessions(queryParams),
  })

  const relieverSessions = sessions as RelieverSession[]

  const checkInMutation = useMutation({
    mutationFn: (employeeId: string) =>
      attendanceApi.relieverCheckIn({ employeeId, date }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reliever-sessions'] })
      toast({ title: 'Reliever checked in' })
      setActionId(null)
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Check-in failed',
        description: Array.isArray(msg) ? msg.join(', ') : msg ?? 'Unknown error',
        variant: 'destructive',
      })
      setActionId(null)
    },
  })

  const checkOutMutation = useMutation({
    mutationFn: (sessionId: string) =>
      attendanceApi.relieverCheckOut({ sessionId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reliever-sessions'] })
      toast({
        title: 'Reliever checked out',
        description:
          'Reliever duty recorded. It is listed under Additional working days as extra duty (already approved) and paid on Extra Day.',
      })
      setActionId(null)
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Check-out failed',
        description: Array.isArray(msg) ? msg.join(', ') : msg ?? 'Unknown error',
        variant: 'destructive',
      })
      setActionId(null)
    },
  })

  const activeCount = relieverSessions.filter(
    (s) => s.sessionStatus === 'ACTIVE' || (!s.checkOut && s.checkIn),
  ).length

  const { page, setPage, totalPages, paginated, total } = usePagination(
    relieverSessions,
    [queryParams],
  )

  return (
    <div className="space-y-4">
      <div className="space-y-1">
        <Label>Date</Label>
        <DateInput
          className="w-full max-w-[160px]"
          value={date}
          onChange={setDate}
        />
      </div>

      <div className="rounded-lg border border-border bg-white p-4">
        <EmployeeFiltersBar
          filters={employeeFilters}
          onChange={setEmployeeFilters}
        />
      </div>

      <TableRecordCount
        count={total}
        label="assigned reliever"
        extra={
          activeCount > 0 ? (
            <p className="text-sm text-text-secondary">{activeCount} active</p>
          ) : undefined
        }
      />

      <div className="rounded-lg border border-border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead>
              <TableHead>Reliever</TableHead>
              <TableHead>Covering</TableHead>
              <TableHead>Branch</TableHead>
              <TableHead>Check In</TableHead>
              <TableHead>Check Out</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  {[...Array(9)].map((__, j) => (
                    <TableCell key={j}>
                      <Skeleton className="h-5 w-full" />
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : paginated.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={9}
                  className="py-8 text-center text-text-secondary"
                >
                  No assigned relievers for this date
                </TableCell>
              </TableRow>
            ) : (
              paginated.map((session) => {
                const rowKey =
                  session.id ??
                  session.relieverRequestId ??
                  `${session.employeeId}-${session.date}`
                const status =
                  session.sessionStatus ??
                  (!session.checkIn
                    ? 'NOT_STARTED'
                    : session.checkOut
                      ? 'COMPLETED'
                      : 'ACTIVE')
                const busy =
                  actionId === rowKey &&
                  (checkInMutation.isPending || checkOutMutation.isPending)

                return (
                  <TableRow key={rowKey}>
                    <TableCell className="font-medium">
                      {session.employee?.employeeCode ?? '—'}
                    </TableCell>
                    <TableCell>
                      <EmployeeNameLink
                        employee={session.employee}
                        employeeId={session.employeeId}
                      />
                    </TableCell>
                    <TableCell>
                      {session.coveringEmployee ? (
                        <EmployeeNameLink
                          employee={session.coveringEmployee}
                          employeeId={session.coveringEmployee.id}
                        />
                      ) : (
                        '—'
                      )}
                    </TableCell>
                    <TableCell>{formatBranchTableLabel(session.branch)}</TableCell>
                    <TableCell>
                      {session.checkIn
                        ? formatDateTimeTime(session.checkIn)
                        : '—'}
                    </TableCell>
                    <TableCell>
                      {session.checkOut
                        ? formatDateTimeTime(session.checkOut)
                        : '—'}
                    </TableCell>
                    <TableCell>
                      {session.checkOut
                        ? formatDuration(session.totalMinutes)
                        : '—'}
                    </TableCell>
                    <TableCell>
                      {status === 'ACTIVE' ? (
                        <Badge
                          variant="outline"
                          className="border-indigo-200 bg-indigo-100 text-indigo-800"
                        >
                          Active
                        </Badge>
                      ) : status === 'COMPLETED' ? (
                        <Badge
                          variant="outline"
                          className="border-green-200 bg-green-100 text-green-800"
                        >
                          Completed
                        </Badge>
                      ) : (
                        <Badge
                          variant="outline"
                          className="border-amber-200 bg-amber-100 text-amber-800"
                        >
                          Not started
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-2">
                        {status === 'NOT_STARTED' ? (
                          <Button
                            size="sm"
                            disabled={busy}
                            onClick={() => {
                              setActionId(rowKey)
                              checkInMutation.mutate(session.employeeId)
                            }}
                          >
                            Check In
                          </Button>
                        ) : status === 'ACTIVE' && session.id ? (
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={busy}
                            onClick={() => {
                              setActionId(rowKey)
                              checkOutMutation.mutate(session.id!)
                            }}
                          >
                            Check Out
                          </Button>
                        ) : !session.id ? (
                          <span className="text-sm text-text-secondary">—</span>
                        ) : null}
                        {session.id && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setUpdateSession(session)}
                          >
                            Update Attendance
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>

        <TablePagination
          page={page}
          totalPages={totalPages}
          total={total}
          onPageChange={setPage}
        />
      </div>

      <UpdateRelieverSessionDialog
        session={updateSession}
        open={!!updateSession}
        onOpenChange={(open) => !open && setUpdateSession(null)}
        onSuccess={() =>
          queryClient.invalidateQueries({ queryKey: ['reliever-sessions'] })
        }
      />
    </div>
  )
}

export function AttendancePage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const tab = searchParams.get('tab') || 'daily'
  const statusParam = searchParams.get('status') || ALL
  const dateParam = searchParams.get('date')
  const initialDate =
    dateParam === 'today'
      ? format(new Date(), 'yyyy-MM-dd')
      : dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)
        ? dateParam
        : undefined

  const handleTabChange = (value: string) => {
    const next = new URLSearchParams(searchParams)
    if (value === 'daily') {
      next.delete('tab')
    } else {
      next.set('tab', value)
    }
    setSearchParams(next, { replace: true })
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-text-primary sm:text-2xl">Attendance</h1>

      <Tabs value={tab} onValueChange={handleTabChange}>
        <TabsList className="w-full justify-start sm:w-auto">
          <TabsTrigger value="daily">Daily Log</TabsTrigger>
          <TabsTrigger value="reliever">Reliever</TabsTrigger>
          <TabsTrigger value="mutual-swap">Mutual Swap</TabsTrigger>
          <TabsTrigger value="manual">Mark Manual</TabsTrigger>
        </TabsList>

        <TabsContent value="daily" className="mt-4">
          <DailyLogTab initialStatus={statusParam} initialDate={initialDate} />
        </TabsContent>

        <TabsContent value="reliever" className="mt-4">
          <RelieverSessionsTab />
        </TabsContent>

        <TabsContent value="mutual-swap" className="mt-4">
          <MutualSwapTab />
        </TabsContent>

        <TabsContent value="manual" className="mt-4 space-y-4">
          <Tabs defaultValue="checkin">
            <TabsList>
              <TabsTrigger value="checkin">CheckIn</TabsTrigger>
              <TabsTrigger value="checkout">CheckOut</TabsTrigger>
              <TabsTrigger value="leave">Mark Leave</TabsTrigger>
            </TabsList>
            <TabsContent value="checkin" className="mt-4">
              <CheckInManualTab />
            </TabsContent>
            <TabsContent value="checkout" className="mt-4">
              <CheckOutManualTab />
            </TabsContent>
            <TabsContent value="leave" className="mt-4">
              <MarkLeaveManualTab />
            </TabsContent>
          </Tabs>
        </TabsContent>
      </Tabs>
    </div>
  )
}
