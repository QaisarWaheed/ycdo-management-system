import { selectCurrentStipend } from '@/lib/stipendUtils'
import { Fragment, useMemo, useRef, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { format } from 'date-fns'
import {
  ChevronDown,
  ChevronRight,
  Clock,
  Download,
  FileText,
  Fingerprint,
  History,
  Loader2,
  MoreHorizontal,
  Pencil,
  Plus,
  Printer,
  Trash2,
  X,
} from 'lucide-react'
import { useParams } from 'react-router-dom'
import { attendanceApi } from '@/api/endpoints/attendance'
import {
  attendanceLockMessage,
  canHrCorrectAttendance,
} from '@/lib/attendanceEligibility'
import { AttendanceStatusBadge } from '@/components/attendance/AttendanceStatusBadge'
import { UpdateAttendanceDialog } from '@/components/attendance/UpdateAttendanceDialog'
import { AttendanceTrailDialog } from '@/components/attendance/AttendanceTrailDialog'
import {
  displayCheckInSource,
  displayCheckOutSource,
} from '@/lib/attendanceSourceDisplay'
import { disciplinaryApi } from '@/api/endpoints/disciplinary'
import { employeesApi } from '@/api/endpoints/employees'
import { leaveApi } from '@/api/endpoints/leave'
import { lettersApi } from '@/api/endpoints/letters'
import { payrollApi } from '@/api/endpoints/payroll'
import { previousEmploymentApi } from '@/api/endpoints/previousEmployment'
import { qualificationsApi } from '@/api/endpoints/qualifications'
import { incentivesApi } from '@/api/endpoints/incentives'
import { AdditionalWorkingDaysTab } from '@/components/employees/AdditionalWorkingDaysTab'
import { EmployeePayrollTab } from '@/components/employees/EmployeePayrollTab'
import { AddIncentiveDialog } from '@/pages/incentives/AddIncentiveDialog'
import { ChangeStatusDialog } from '@/components/employees/ChangeStatusDialog'
import { EditEmployeeDialog } from '@/components/employees/EditEmployeeDialog'
import { EmployeeAvatar } from '@/components/employees/EmployeeAvatar'
import { EmployeeDisciplineTrackRecord } from '@/components/employees/EmployeeDisciplineTrackRecord'
import {
  ManagerScopeBadges,
} from '@/components/employees/RoleBadges'
import { GenerateLetterDialog } from '@/components/employees/GenerateLetterDialog'
import { EditDraftLetterDialog } from '@/components/letters/EditDraftLetterDialog'
import { StatusBadge } from '@/components/employees/StatusBadge'
import { TransferDialog } from '@/components/employees/TransferDialog'
import { FaceSyncDialog } from '@/components/employees/FaceSyncDialog'
import { FaceSyncStatusBadge } from '@/components/dashboard/FaceSyncTab'
import { faceSyncApi } from '@/api/endpoints/faceSync'
import { UpdateBranchDutyDialog } from '@/components/employees/UpdateBranchDutyDialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from '@/hooks/use-toast'
import { useAuth } from '@/hooks/useAuth'
import { formatEmployeeShiftDisplay } from '@/lib/dutyTimes'
import { formatWeeklyOffWeekdays } from '@/lib/weeklyOffDays'
import { formatDateTimeTime } from '@/lib/timeFormat'
import { formatBranchLabel } from '@/lib/formatBranchLabel'
import { letterTypeLabel } from '@/lib/letterFieldConfig'
import { openOnboardingWhatsAppShare } from '@/lib/openOnboardingWhatsAppShare'
import { maritalStatusToLabel } from '@/lib/searchableSelectOptions'
import type {
  AcademicQualification,
  AttendanceLog,
  DisciplinaryAction,
  DocumentType,
  EmployeeDocument,
  EmploymentHistory,
  Incentive,
  Letter,
  PayrollEntry,
  PreviousEmployment,
  QualType,
  StipendRecord,
} from '@/types'

const IT_PROFILE_ROLES = ['SUPER_ADMIN', 'IT_ADMIN'] as const
const HR_JOB_ROLES = [
  'SUPER_ADMIN',
  'HR_EXECUTIVE',
  'HR_MANAGER',
  'HR_ADMIN_MANAGER',
  'HR_OPERATIONS_MANAGER',
] as const
const ATTENDANCE_EDIT_ROLES = [
  'SUPER_ADMIN',
  'IT_ADMIN',
  'HR_EXECUTIVE',
  'HR_MANAGER',
  'HR_ADMIN_MANAGER',
  'HR_OPERATIONS_MANAGER',
] as const
const ROLE_ASSIGNER_ROLES = [
  'SUPER_ADMIN',
  'IT_ADMIN',
  'HR_EXECUTIVE',
  'HR_MANAGER',
  'HR_ADMIN_MANAGER',
  'HR_OPERATIONS_MANAGER',
] as const

const API_BASE = import.meta.env.VITE_API_URL || 'http://187.127.115.103:3000'

function resolveFileUrl(path: string) {
  if (path.startsWith('http')) return path
  return `${API_BASE}${path}`
}

function letterReference(letter: Letter) {
  if (letter.letterNo) return letter.letterNo.replace(/\//g, '-')
  if (letter.fileUrl) {
    const name = letter.fileUrl.split('/').pop() ?? ''
    return name.replace(/\.pdf$/i, '').replace(/_/g, '/')
  }
  return letter.id.slice(0, 8).toUpperCase()
}

function letterVars(letter: Letter): Record<string, unknown> {
  return (letter.variables ?? {}) as Record<string, unknown>
}

function letterDisciplineReason(letter: Letter): string {
  const v = letterVars(letter)
  const category = String(v.disciplineCategory ?? '')
  if (category === 'LATE' || v.monthlyLateOccurrence != null) {
    return 'Late Arrival'
  }
  if (
    category === 'MISSING_CHECKOUT' ||
    v.monthlyMissingCheckoutOccurrence != null
  ) {
    return 'Missing Checkout'
  }
  if (category === 'UNINFORMED_ABSENT') return 'Uninformed Absence'
  if (category === 'ABSENT') return 'Absence'
  if (v.warningNumber != null) return 'Manual Disciplinary Action'
  return 'Manual / Other'
}

function letterOccurrence(letter: Letter): string {
  const v = letterVars(letter)
  const n =
    v.monthlyLateOccurrence ??
    v.monthlyMissingCheckoutOccurrence ??
    v.monthlyAbsenceOccurrence ??
    v.warningNumber
  return n != null ? String(n) : '—'
}

function letterIncidentDate(letter: Letter): string {
  const raw = letterVars(letter).incidentDate
  if (typeof raw !== 'string' || !raw) return '—'
  try {
    return format(new Date(`${raw}T00:00:00.000Z`), 'dd/MM/yyyy')
  } catch {
    return raw
  }
}

function letterStatus(letter: Letter): {
  label: string
  className: string
} {
  const v = letterVars(letter)
  if (
    letter.status === 'REVERSED' ||
    v.reversedDueToShortLeave === true ||
    v.reversed === true
  ) {
    return {
      label: 'Reversed',
      className: 'border-amber-200 bg-amber-50 text-amber-900',
    }
  }
  const hasTrackMeta =
    v.monthlyLateOccurrence != null ||
    v.monthlyMissingCheckoutOccurrence != null ||
    v.disciplineCategory != null
  if (!hasTrackMeta && !v.incidentDate) {
    return {
      label: 'Legacy',
      className: 'border-slate-200 bg-slate-50 text-slate-700',
    }
  }
  return {
    label: 'Active',
    className: 'border-emerald-200 bg-emerald-50 text-emerald-800',
  }
}

function leaveStatusBadge(status: string) {
  const styles: Record<string, string> = {
    APPROVED: 'bg-green-100 text-green-800',
    PENDING: 'bg-yellow-100 text-yellow-800',
    REJECTED: 'bg-red-100 text-red-800',
    CANCELLED: 'bg-gray-100 text-gray-700',
  }
  return (
    <Badge variant="outline" className={styles[status] ?? ''}>
      {status}
    </Badge>
  )
}

interface QualFormState {
  degree: string
  boardUniversity: string
  obtainedMarks: string
  divisionGrade: string
}

const emptyQualForm = (): QualFormState => ({
  degree: '',
  boardUniversity: '',
  obtainedMarks: '',
  divisionGrade: '',
})

function QualificationSection({
  employeeId,
  qualType,
  title,
  qualifications,
  isLoading,
  canEdit = true,
}: {
  employeeId: string
  qualType: QualType
  title: string
  qualifications: AcademicQualification[]
  isLoading: boolean
  canEdit?: boolean
}) {
  const queryClient = useQueryClient()
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editForm, setEditForm] = useState<QualFormState>(emptyQualForm())
  const [adding, setAdding] = useState(false)
  const [newForm, setNewForm] = useState<QualFormState>(emptyQualForm())

  const filtered = qualifications.filter((q) => q.qualType === qualType)

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: ['qualifications', employeeId] })

  const createMutation = useMutation({
    mutationFn: () =>
      qualificationsApi.create({
        employeeId,
        qualType,
        degree: newForm.degree,
        boardUniversity: newForm.boardUniversity,
        obtainedMarks: newForm.obtainedMarks || undefined,
        divisionGrade: newForm.divisionGrade || undefined,
      }),
    onSuccess: () => {
      toast({ title: 'Qualification added' })
      setAdding(false)
      setNewForm(emptyQualForm())
      invalidate()
    },
    onError: () => {
      toast({ title: 'Failed to add qualification', variant: 'destructive' })
    },
  })

  const updateMutation = useMutation({
    mutationFn: (qualId: string) =>
      qualificationsApi.update(qualId, {
        degree: editForm.degree,
        boardUniversity: editForm.boardUniversity,
        obtainedMarks: editForm.obtainedMarks || undefined,
        divisionGrade: editForm.divisionGrade || undefined,
      }),
    onSuccess: () => {
      toast({ title: 'Qualification updated' })
      setEditingId(null)
      invalidate()
    },
    onError: () => {
      toast({ title: 'Failed to update qualification', variant: 'destructive' })
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (qualId: string) => qualificationsApi.delete(qualId),
    onSuccess: () => {
      toast({ title: 'Qualification deleted' })
      invalidate()
    },
    onError: () => {
      toast({ title: 'Failed to delete qualification', variant: 'destructive' })
    },
  })

  const startEdit = (qual: AcademicQualification) => {
    setEditingId(qual.id)
    setEditForm({
      degree: qual.degree,
      boardUniversity: qual.boardUniversity,
      obtainedMarks: qual.obtainedMarks ?? '',
      divisionGrade: qual.divisionGrade ?? '',
    })
  }

  const renderFormRow = (
    form: QualFormState,
    setForm: (f: QualFormState) => void,
    onSave: () => void,
    onCancel: () => void,
    saving: boolean,
  ) => (
    <TableRow>
      <TableCell>
        <Input
          value={form.degree}
          onChange={(e) => setForm({ ...form, degree: e.target.value })}
          placeholder="Degree"
        />
      </TableCell>
      <TableCell>
        <Input
          value={form.boardUniversity}
          onChange={(e) =>
            setForm({ ...form, boardUniversity: e.target.value })
          }
          placeholder="Board / University"
        />
      </TableCell>
      <TableCell>
        <Input
          value={form.obtainedMarks}
          onChange={(e) =>
            setForm({ ...form, obtainedMarks: e.target.value })
          }
          placeholder="Marks"
        />
      </TableCell>
      <TableCell>
        <Input
          value={form.divisionGrade}
          onChange={(e) =>
            setForm({ ...form, divisionGrade: e.target.value })
          }
          placeholder="Division / Grade"
        />
      </TableCell>
      <TableCell>
        <div className="flex gap-1">
          <Button
            size="sm"
            className="bg-primary hover:bg-primary-dark"
            disabled={
              saving || !form.degree.trim() || !form.boardUniversity.trim()
            }
            onClick={onSave}
          >
            Save
          </Button>
          <Button size="sm" variant="ghost" onClick={onCancel}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  )

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-lg">{title}</CardTitle>
        {canEdit && !adding && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setAdding(true)
              setNewForm(emptyQualForm())
            }}
          >
            <Plus className="mr-1 h-4 w-4" />
            Add
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            {[...Array(2)].map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Degree</TableHead>
                <TableHead>Board / University</TableHead>
                <TableHead>Marks</TableHead>
                <TableHead>Division / Grade</TableHead>
                <TableHead className="w-28">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 && !adding && (
                <TableRow>
                  <TableCell colSpan={5} className="text-text-secondary">
                    No qualifications recorded
                  </TableCell>
                </TableRow>
              )}
              {filtered.map((qual) =>
                editingId === qual.id
                  ? renderFormRow(
                      editForm,
                      setEditForm,
                      () => updateMutation.mutate(qual.id),
                      () => setEditingId(null),
                      updateMutation.isPending,
                    )
                  : (
                    <TableRow key={qual.id}>
                      <TableCell>{qual.degree}</TableCell>
                      <TableCell>{qual.boardUniversity}</TableCell>
                      <TableCell>{qual.obtainedMarks ?? '—'}</TableCell>
                      <TableCell>{qual.divisionGrade ?? '—'}</TableCell>
                      <TableCell>
                        {canEdit ? (
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => startEdit(qual)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            disabled={deleteMutation.isPending}
                            onClick={() => deleteMutation.mutate(qual.id)}
                          >
                            <Trash2 className="h-4 w-4 text-red-600" />
                          </Button>
                        </div>
                        ) : (
                          '—'
                        )}
                      </TableCell>
                    </TableRow>
                  ),
              )}
              {canEdit && adding &&
                renderFormRow(
                  newForm,
                  setNewForm,
                  () => createMutation.mutate(),
                  () => setAdding(false),
                  createMutation.isPending,
                )}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  )
}

function AddPreviousEmploymentDialog({
  open,
  onOpenChange,
  employeeId,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  employeeId: string
}) {
  const queryClient = useQueryClient()
  const [organizationName, setOrganizationName] = useState('')
  const [ownerAdminName, setOwnerAdminName] = useState('')
  const [contactNumber, setContactNumber] = useState('')
  const [postalAddress, setPostalAddress] = useState('')
  const [totalExperience, setTotalExperience] = useState('')
  const [relevantExperience, setRelevantExperience] = useState('')
  const [jobResponsibilities, setJobResponsibilities] = useState('')

  const reset = () => {
    setOrganizationName('')
    setOwnerAdminName('')
    setContactNumber('')
    setPostalAddress('')
    setTotalExperience('')
    setRelevantExperience('')
    setJobResponsibilities('')
  }

  const mutation = useMutation({
    mutationFn: () =>
      previousEmploymentApi.create({
        employeeId,
        organizationName,
        ownerAdminName: ownerAdminName || undefined,
        contactNumber: contactNumber || undefined,
        postalAddress: postalAddress || undefined,
        totalExperience: totalExperience || undefined,
        relevantExperience: relevantExperience || undefined,
        jobResponsibilities: jobResponsibilities || undefined,
      }),
    onSuccess: () => {
      toast({ title: 'Previous employment added' })
      queryClient.invalidateQueries({
        queryKey: ['previous-employment', employeeId],
      })
      reset()
      onOpenChange(false)
    },
    onError: () => {
      toast({
        title: 'Failed to add previous employment',
        variant: 'destructive',
      })
    },
  })

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) reset()
        onOpenChange(v)
      }}
    >
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Previous Employment</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Organization Name *</Label>
            <Input
              value={organizationName}
              onChange={(e) => setOrganizationName(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Owner / Admin Name</Label>
              <Input
                value={ownerAdminName}
                onChange={(e) => setOwnerAdminName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Contact Number</Label>
              <Input
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Postal Address</Label>
            <Input
              value={postalAddress}
              onChange={(e) => setPostalAddress(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Total Experience</Label>
              <Input
                value={totalExperience}
                onChange={(e) => setTotalExperience(e.target.value)}
                placeholder="e.g. 3 years"
              />
            </div>
            <div className="space-y-2">
              <Label>Relevant Experience</Label>
              <Input
                value={relevantExperience}
                onChange={(e) => setRelevantExperience(e.target.value)}
                placeholder="e.g. 2 years"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Job Responsibilities</Label>
            <Textarea
              value={jobResponsibilities}
              onChange={(e) => setJobResponsibilities(e.target.value)}
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button
            className="bg-primary hover:bg-primary-dark"
            disabled={!organizationName.trim() || mutation.isPending}
            onClick={() => mutation.mutate()}
          >
            {mutation.isPending ? 'Adding...' : 'Add'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export function EmployeeProfilePage() {
  const { id: routeId } = useParams<{ id: string }>()
  const id = routeId?.trim() ?? ''
  const { user, hasPermission, hasRole } = useAuth()
  const queryClient = useQueryClient()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const photoInputRef = useRef<HTMLInputElement>(null)

  const now = new Date()
  const [month, setMonth] = useState(now.getMonth() + 1)
  const [year, setYear] = useState(now.getFullYear())
  const [uploadType, setUploadType] = useState<DocumentType>('CNIC')

  const [letterOpen, setLetterOpen] = useState(false)
  const [editAppointmentLetter, setEditAppointmentLetter] =
    useState<Letter | null>(null)
  const [editAppointmentPreviewHtml, setEditAppointmentPreviewHtml] = useState<
    string | null
  >(null)
  const [reverseLetter, setReverseLetter] = useState<Letter | null>(null)
  const [reverseReason, setReverseReason] = useState('')
  const [statusOpen, setStatusOpen] = useState(false)
  const [transferOpen, setTransferOpen] = useState(false)
  const [branchDutyOpen, setBranchDutyOpen] = useState(false)
  const [editPersonalOpen, setEditPersonalOpen] = useState(false)
  const [editJobOpen, setEditJobOpen] = useState(false)
  const [prevEmpOpen, setPrevEmpOpen] = useState(false)
  const [incentiveOpen, setIncentiveOpen] = useState(false)
  const [faceSyncOpen, setFaceSyncOpen] = useState(false)
  const [attendanceToEdit, setAttendanceToEdit] =
    useState<AttendanceLog | null>(null)
  const [attendanceTrailLog, setAttendanceTrailLog] =
    useState<AttendanceLog | null>(null)
  const [creatingMissingDate, setCreatingMissingDate] = useState<string | null>(
    null,
  )
  const [expandedPrevEmpId, setExpandedPrevEmpId] = useState<string | null>(
    null,
  )

  const {
    data: employee,
    isLoading,
    isFetching,
    isError,
    error,
  } = useQuery({
    queryKey: ['employee', id],
    queryFn: () => employeesApi.getOne(id),
    enabled: !!id,
    retry: 1,
  })

  const { data: faceSyncStats } = useQuery({
    queryKey: ['face-sync', 'stats', id],
    queryFn: () => faceSyncApi.getStats(id),
    enabled: !!id,
  })

  const { data: attendanceSummary, isLoading: loadingSummary } = useQuery({
    queryKey: ['attendance', 'summary', id, month, year],
    queryFn: () => attendanceApi.getSummary(id, month, year),
    enabled: !!id,
  })

  const { data: workingHours, isLoading: loadingWorkingHours } = useQuery({
    queryKey: ['working-hours', id],
    queryFn: () => employeesApi.getWorkingHours(id),
    enabled: !!id,
  })

  const { data: attendanceLogs = [], isLoading: loadingLogs } = useQuery({
    queryKey: ['attendance', 'logs', id, month, year],
    queryFn: () => attendanceApi.getAll({ employeeId: id, month, year }),
    enabled: !!id,
  })

  type AttendanceLogRow = AttendanceLog & { isMissing?: boolean }

  const attendanceLogRows = useMemo((): AttendanceLogRow[] => {
    const logs = (attendanceLogs as AttendanceLog[]).map((log) => ({
      ...log,
      isMissing: false as const,
    }))
    const loggedKeys = new Set(
      logs.map((log) => String(log.date).slice(0, 10)),
    )
    const missingRows: AttendanceLogRow[] = (
      attendanceSummary?.missingDates ?? []
    )
      .filter((date) => !loggedKeys.has(date.slice(0, 10)))
      .map((date) => ({
        id: `missing:${date}`,
        date,
        status: 'MISSING',
        lateMinutes: 0,
        overtimeMinutes: 0,
        source: undefined,
        note: 'No attendance record yet — update to create one',
        isMissing: true,
      }))
    return [...logs, ...missingRows].sort((a, b) =>
      String(b.date).localeCompare(String(a.date)),
    )
  }, [attendanceLogs, attendanceSummary?.missingDates])

  const openAttendanceUpdate = async (row: AttendanceLogRow) => {
    if (!id) return
    if (!row.isMissing) {
      setAttendanceToEdit(row)
      return
    }
    const dateKey = String(row.date).slice(0, 10)
    setCreatingMissingDate(dateKey)
    try {
      const created = await attendanceApi.markManual({
        employeeId: id,
        date: dateKey,
        status: 'UNMARKED',
        note: 'Created from profile missing-day update',
      })
      await Promise.all([
        queryClient.invalidateQueries({
          queryKey: ['attendance', 'logs', id, month, year],
        }),
        queryClient.invalidateQueries({
          queryKey: ['attendance', 'summary', id, month, year],
        }),
      ])
      setAttendanceToEdit(created)
    } catch (err: unknown) {
      const msg = (
        err as { response?: { data?: { message?: string | string[] } } }
      )?.response?.data?.message
      toast({
        title: 'Could not open attendance for this date',
        description: Array.isArray(msg)
          ? msg.join(', ')
          : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    } finally {
      setCreatingMissingDate(null)
    }
  }

  const { data: payrollHistory = [] } = useQuery({
    queryKey: ['payroll-history', id],
    queryFn: () => payrollApi.getHistory(id),
    enabled: !!id,
  })
  const monthPayroll = useMemo(() => {
    return (payrollHistory as PayrollEntry[]).filter(
      (entry) => entry.month === month && entry.year === year,
    )
  }, [payrollHistory, month, year])
  const monthPayrollBasic = monthPayroll.reduce(
    (sum, entry) => sum + Number(entry.basicStipend),
    0,
  )
  const monthPayrollNet = monthPayroll.reduce(
    (sum, entry) => sum + Number(entry.netStipend),
    0,
  )
  const monthPayrollPaid = monthPayroll.some((entry) => entry.status === 'PAID')
  const canEditAttendance = hasRole([...ATTENDANCE_EDIT_ROLES])
  const attendanceUnlocked = canHrCorrectAttendance(employee?.status)
  const canUpdateAttendance = canEditAttendance && attendanceUnlocked

  const { data: leaves = [], isLoading: loadingLeaves } = useQuery({
    queryKey: ['leave', id],
    queryFn: () => leaveApi.getAll({ employeeId: id }),
    enabled: !!id,
  })

  const { data: leaveBalance } = useQuery({
    queryKey: ['leave-balance', id, year],
    queryFn: () => leaveApi.getBalance(id, year),
    enabled: !!id,
  })

  const { data: letters = [], isLoading: loadingLetters } = useQuery({
    queryKey: ['letters', id],
    queryFn: () => lettersApi.getAll({ employeeId: id }),
    enabled: !!id,
  })

  const { data: disciplinary = [], isLoading: loadingDisciplinary } = useQuery({
    queryKey: ['disciplinary', id],
    queryFn: () => disciplinaryApi.getAll({ employeeId: id }),
    enabled: !!id,
  })

  const { data: qualifications = [], isLoading: loadingQualifications } =
    useQuery({
      queryKey: ['qualifications', id],
      queryFn: () => qualificationsApi.getByEmployee(id),
      enabled: !!id,
    })

  const {
    data: previousEmployments = [],
    isLoading: loadingPreviousEmployment,
  } = useQuery({
    queryKey: ['previous-employment', id],
    queryFn: () => previousEmploymentApi.getByEmployee(id),
    enabled: !!id,
  })

  const { data: incentives = [], isLoading: loadingIncentives } = useQuery({
    queryKey: ['incentives', id],
    queryFn: () => incentivesApi.getByEmployee(id),
    enabled: !!id,
  })

  const canAddIncentive =
    user?.role === 'SUPER_ADMIN' ||
    user?.role === 'HR_MANAGER' ||
    user?.role === 'HR_ADMIN_MANAGER' ||
    user?.role === 'ADMIN_OFFICER'

  const canEditAdditionalWorkingDays = hasRole([
    ...HR_JOB_ROLES,
    'ADMIN_OFFICER',
    'ADMIN_MANAGER',
  ])

  const incentiveTotal = (incentives as Incentive[]).reduce(
    (sum, i) => sum + Number(i.amount),
    0,
  )

  const deletePrevEmpMutation = useMutation({
    mutationFn: (recordId: string) => previousEmploymentApi.delete(recordId),
    onSuccess: () => {
      toast({ title: 'Previous employment deleted' })
      queryClient.invalidateQueries({ queryKey: ['previous-employment', id] })
    },
    onError: () => {
      toast({
        title: 'Failed to delete previous employment',
        variant: 'destructive',
      })
    },
  })

  const uploadMutation = useMutation({
    mutationFn: (file: File) => {
      const formData = new FormData()
      formData.append('documentType', uploadType)
      formData.append('file', file)
      return employeesApi.uploadDocument(id, formData)
    },
    onSuccess: () => {
      toast({ title: 'Document uploaded' })
      queryClient.invalidateQueries({ queryKey: ['employee', id] })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Upload failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const photoUploadMutation = useMutation({
    mutationFn: (file: File) => {
      const formData = new FormData()
      formData.append('photo', file)
      return employeesApi.uploadPhoto(id, formData)
    },
    onSuccess: () => {
      toast({ title: 'Photo updated' })
      queryClient.invalidateQueries({ queryKey: ['employee', id] })
      queryClient.invalidateQueries({ queryKey: ['face-sync', 'stats', id] })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Photo upload failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const deleteDocMutation = useMutation({
    mutationFn: (documentId: string) =>
      employeesApi.deleteDocument(id, documentId),
    onSuccess: () => {
      toast({ title: 'Document deleted' })
      queryClient.invalidateQueries({ queryKey: ['employee', id] })
    },
    onError: () => {
      toast({ title: 'Failed to delete document', variant: 'destructive' })
    },
  })

  const reverseLetterMutation = useMutation({
    mutationFn: ({ letterId, reason }: { letterId: string; reason: string }) =>
      lettersApi.reverse(letterId, reason),
    onSuccess: (data) => {
      toast({ title: 'Letter reversed', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['letters', id] })
      queryClient.invalidateQueries({ queryKey: ['payroll'] })
      setReverseLetter(null)
      setReverseReason('')
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Reverse failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? ''),
        variant: 'destructive',
      })
    },
  })

  const sendAppointmentMutation = useMutation({
    mutationFn: (letterId: string) => lettersApi.send(letterId),
    onSuccess: (data) => {
      toast({
        title: data.alreadySent
          ? 'Appointment letter already issued'
          : 'Appointment letter issued',
        description: data.alreadySent
          ? 'This letter was already sent to the employee portal.'
          : 'Watermark removed. Sent to portal and WhatsApp.',
      })
      queryClient.invalidateQueries({ queryKey: ['letters', id] })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Failed to issue appointment letter',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const submitAppointmentMutation = useMutation({
    mutationFn: (letterId: string) => lettersApi.submitForApproval(letterId),
    onSuccess: () => {
      toast({
        title: 'Submitted for approval',
        description:
          'Watermark stays on. An executive must approve before Send.',
      })
      queryClient.invalidateQueries({ queryKey: ['letters', id] })
      queryClient.invalidateQueries({
        queryKey: ['letters', 'appointment-approvals'],
      })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Submit failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const approveAppointmentMutation = useMutation({
    mutationFn: (letterId: string) => lettersApi.approve(letterId),
    onSuccess: () => {
      toast({
        title: 'Appointment letter approved',
        description: 'HR can send the final letter. Employee is not activated yet.',
      })
      queryClient.invalidateQueries({ queryKey: ['letters', id] })
      queryClient.invalidateQueries({
        queryKey: ['letters', 'appointment-approvals'],
      })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Approve failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const rejectAppointmentMutation = useMutation({
    mutationFn: (letterId: string) => lettersApi.reject(letterId),
    onSuccess: () => {
      toast({
        title: 'Returned for changes',
        description: 'The letter is a draft again.',
      })
      queryClient.invalidateQueries({ queryKey: ['letters', id] })
      queryClient.invalidateQueries({
        queryKey: ['letters', 'appointment-approvals'],
      })
    },
    onError: (err: { response?: { data?: { message?: string | string[] } } }) => {
      const msg = err.response?.data?.message
      toast({
        title: 'Return failed',
        description: Array.isArray(msg) ? msg.join(', ') : String(msg ?? 'Error'),
        variant: 'destructive',
      })
    },
  })

  const markPrintedMutation = useMutation({
    mutationFn: (letterId: string) => lettersApi.markPrinted(letterId),
    onSuccess: () => {
      toast({ title: 'Letter marked as printed' })
      queryClient.invalidateQueries({ queryKey: ['letters', id] })
    },
  })

  const downloadPdf = async (letterId: string) => {
    try {
      const { downloadLetterPdf } = await import('@/lib/downloadLetterPdf')
      await downloadLetterPdf(letterId)
    } catch (err) {
      toast({
        title: 'Failed to download PDF',
        description:
          err instanceof Error ? err.message : 'File unavailable — please reissue',
        variant: 'destructive',
      })
    }
  }

  if (!id || isLoading || (isFetching && !employee && !isError)) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-96 w-full" />
      </div>
    )
  }

  if (isError) {
    const status = (error as { response?: { status?: number } })?.response?.status
    return (
      <div className="space-y-3 rounded-lg border border-border bg-white p-6">
        <p className="font-medium text-text-primary">
          {status === 403
            ? 'Access denied'
            : status === 404
              ? 'Employee not found'
              : 'Could not load employee'}
        </p>
        <p className="text-sm text-text-secondary">
          {status === 403
            ? 'You do not have permission to view this employee.'
            : 'Refresh the page or go back and try again. If this keeps happening, check that you are still signed in.'}
        </p>
      </div>
    )
  }

  if (!employee) {
    return (
      <div className="space-y-3 rounded-lg border border-border bg-white p-6">
        <p className="font-medium text-text-primary">Employee not found</p>
        <p className="text-sm text-text-secondary">
          No employee matches this profile URL.
        </p>
      </div>
    )
  }

  const needsJobAssignment =
    employee.currentDepartmentId == null || employee.currentDesignation == null

  const history = (employee.employmentHistory ?? []) as EmploymentHistory[]
  const stipends = (employee.stipendRecords ?? []) as StipendRecord[]
  const latestStipend = selectCurrentStipend(stipends)
  const basicStipendAmount = latestStipend
    ? Number(latestStipend.basicStipend)
    : 0
  const payrollTotal = basicStipendAmount + incentiveTotal
  const photoSrc = employee.photoUrl
    ? resolveFileUrl(employee.photoUrl)
    : undefined
  const documents = (employee.documents ?? []) as EmployeeDocument[]

  const isItTeam = hasRole([...IT_PROFILE_ROLES])
  const canReverseLetters = isItTeam

  const isHrTeam = hasRole([...HR_JOB_ROLES])
  const canApproveAppointment = hasRole([
    'SUPER_ADMIN',
    'PRESIDENT',
    'FOUNDER',
    'CHAIRMAN',
  ])

  const canEditEmployeeProfile = hasPermission('EMPLOYEES_EDIT')

  const canManagePersonalData = isItTeam || isHrTeam || canEditEmployeeProfile

  const canEditJobInfo = isHrTeam || isItTeam || canEditEmployeeProfile

  const canAssignRoles = hasRole([...ROLE_ASSIGNER_ROLES])

  const canEditPayroll = isHrTeam || isItTeam

  const canHrJobActions = isHrTeam
  const canOverrideSuspendedStatus = hasRole([...IT_PROFILE_ROLES])

  const canEditBranchDuty =
    canHrJobActions && user?.employeeId !== employee.id

  const hasPersonalInfo =
    employee.bloodGroup ||
    employee.caste ||
    employee.domicile ||
    employee.province ||
    employee.city ||
    employee.district ||
    employee.tehsil ||
    employee.policeStation ||
    employee.fatherContactNumber ||
    employee.emergencyContactName ||
    employee.emergencyContactNumber ||
    employee.spouseName ||
    employee.spouseContactNumber ||
    employee.currentAddress ||
    employee.permanentAddress

  return (
    <>
      <input
        ref={photoInputRef}
        type="file"
        accept="image/jpeg,image/png,image/jpg"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0]
          if (file) photoUploadMutation.mutate(file)
          e.target.value = ''
        }}
      />

      {(isItTeam || isHrTeam || canEditEmployeeProfile) && (
        <div className="rounded-lg border border-blue-200 bg-blue-50 p-4 text-sm text-blue-900 no-print">
          {isItTeam
            ? 'IT access — you can edit personal information, job information, documents, and qualifications for this employee.'
            : isHrTeam
              ? 'HR access — you can edit personal information, job information, documents, and qualifications for this employee.'
              : 'You have permission to edit this employee’s personal information and job information.'}
        </div>
      )}

      {needsJobAssignment && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          ⚠️ This employee needs department/designation assignment. Please
          update their job information.
        </div>
      )}

      <div className="print-only hidden">
        <div className="print-header">
          <h1 className="text-2xl font-bold">YCDO</h1>
          <p className="text-sm">Youth Community Development Organization</p>
        </div>
        <h2 className="mb-2 text-center text-lg font-semibold">
          Employee Profile
        </h2>
        <p className="mb-6 text-center text-sm">
          {employee.employeeCode} · Printed{' '}
          {format(new Date(), 'dd/MM/yyyy')}
        </p>

        <h3 className="mb-2 font-semibold">Personal Information</h3>
        <div className="print-grid mb-6">
          <div className="print-field">
            <div className="print-label">Full Name</div>
            {employee.fullName}
          </div>
          <div className="print-field">
            <div className="print-label">CNIC</div>
            {employee.cnic ?? '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Date of Birth</div>
            {employee.dateOfBirth
              ? format(new Date(employee.dateOfBirth), 'dd/MM/yyyy')
              : '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Gender</div>
            {employee.gender}
          </div>
          <div className="print-field">
            <div className="print-label">Blood Group</div>
            {employee.bloodGroup ?? '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Marital Status</div>
            {employee.maritalStatus
              ? maritalStatusToLabel(employee.maritalStatus)
              : '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Father Name</div>
            {employee.fatherName ?? '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Caste</div>
            {employee.caste ?? '—'}
          </div>
        </div>

        <h3 className="mb-2 font-semibold">Contact Information</h3>
        <div className="print-grid mb-6">
          <div className="print-field">
            <div className="print-label">Phone</div>
            {employee.phone ?? '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Email</div>
            {employee.email ?? '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Emergency Contact</div>
            {employee.emergencyContactName ?? '—'}
            {employee.emergencyRelation
              ? ` (${employee.emergencyRelation})`
              : ''}
          </div>
          <div className="print-field">
            <div className="print-label">Emergency Number</div>
            {employee.emergencyContactNumber ?? '—'}
          </div>
          <div className="print-field sm:col-span-2">
            <div className="print-label">Current Address</div>
            {employee.currentAddress ?? '—'}
          </div>
        </div>

        <h3 className="mb-2 font-semibold">Employment Details</h3>
        <div className="print-grid mb-6">
          <div className="print-field">
            <div className="print-label">Designation</div>
            {employee.currentDesignation ?? '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Department</div>
            {employee.currentDepartment?.name ?? '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Branch</div>
            {formatBranchLabel(employee.currentBranch)}
          </div>
          <div className="print-field">
            <div className="print-label">Joining Date</div>
            {format(new Date(employee.joiningDate), 'dd/MM/yyyy')}
          </div>
          <div className="print-field">
            <div className="print-label">Shift</div>
            {employee.shift?.name ?? '—'}
          </div>
          <div className="print-field">
            <div className="print-label">Duty Hours</div>
            {formatEmployeeShiftDisplay(employee)}
          </div>
          <div className="print-field">
            <div className="print-label">Weekly Off</div>
            {formatWeeklyOffWeekdays(employee.weeklyOffWeekdays)}
          </div>
        </div>

        <h3 className="mb-2 font-semibold">Payroll Summary</h3>
        <div className="print-grid mb-10">
          <div className="print-field">
            <div className="print-label">Basic Stipend</div>
            PKR {basicStipendAmount.toLocaleString()}
          </div>
          <div className="print-field">
            <div className="print-label">Total (incl. incentives)</div>
            PKR {payrollTotal.toLocaleString()}
          </div>
        </div>

        <p className="mt-8 text-sm">
          HR Manager _________________________ Date _______________
        </p>
      </div>

    <div className="no-print grid grid-cols-1 gap-6 lg:grid-cols-[35%_1fr]">
      <Card>
        <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
          <EmployeeAvatar
            fullName={employee.fullName}
            photoUrl={photoSrc}
            hideProfilePhoto={employee.hideProfilePhoto}
            size="lg"
            onPhotoClick={
              canManagePersonalData
                ? () => photoInputRef.current?.click()
                : undefined
            }
          />
          <FaceSyncStatusBadge
            status={faceSyncStats?.latestJob?.status ?? null}
          />
          <div>
            <h1 className="text-xl font-bold">
              {employee.fullName}
            </h1>
            <Badge variant="outline" className="mt-2 font-mono">
              {employee.employeeCode}
            </Badge>
            {(() => {
              const registration =
                employee.biometricRegistration ??
                faceSyncStats?.registration
              const registrationStatus =
                registration?.registrationStatus ?? 'NOT_REGISTERED'
              const registrationLabel =
                registrationStatus === 'REGISTERED'
                  ? 'Registered on device'
                  : registrationStatus === 'PARTIAL'
                    ? 'Partially registered'
                    : 'Not registered on device'
              const registrationClass =
                registrationStatus === 'REGISTERED'
                  ? 'bg-green-100 text-green-800'
                  : registrationStatus === 'PARTIAL'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-slate-100 text-slate-600'
              return (
                <div className="mt-2 flex flex-col items-center gap-1.5">
                  <p className="flex items-center justify-center gap-1.5 text-xs text-text-secondary">
                    <Fingerprint className="h-3.5 w-3.5" />
                    <span>
                      Biometric ID:{' '}
                      {employee.biometricId || registration?.biometricId
                        ? (employee.biometricId ?? registration?.biometricId)
                        : 'Not assigned'}
                    </span>
                  </p>
                  <Badge
                    variant="outline"
                    className={`text-xs ${registrationClass}`}
                  >
                    {registrationLabel}
                  </Badge>
                  {registration && registration.totalDevices > 0 && (
                    <p className="text-xs text-text-secondary">
                      Synced on {registration.registeredDeviceCount} of{' '}
                      {registration.totalDevices} devices
                    </p>
                  )}
                </div>
              )
            })()}
          </div>
          <p className="text-text-secondary">{employee.currentDesignation ?? '—'}</p>
          {(employee.user?.managerScopes?.length ?? 0) > 0 && (
            <div className="flex flex-col items-center gap-1">
              <p className="text-xs text-text-secondary">Hospital scopes</p>
              <ManagerScopeBadges scopes={employee.user?.managerScopes} />
            </div>
          )}
          <p className="text-sm">
            <span className="font-medium">
              {employee.currentDepartment?.name ?? '—'}
            </span>
            {' · '}
            <span className="text-text-secondary">
              {formatBranchLabel(employee.currentBranch)}
            </span>
          </p>
          <StatusBadge status={employee.status} />
          <p
            className={`flex w-full items-center justify-center gap-1.5 text-sm ${
              employee.dutyStartTime || employee.relieverOnly
                ? 'text-text-primary'
                : 'text-text-secondary'
            }`}
          >
            <Clock className="h-4 w-4 shrink-0" />
            <span>
              Duty:{' '}
              {employee.relieverOnly
                ? 'Reliever only (no regular duty)'
                : formatEmployeeShiftDisplay(employee)}
            </span>
          </p>
          <p className="text-sm text-text-secondary">
            Weekly off: {formatWeeklyOffWeekdays(employee.weeklyOffWeekdays)}
          </p>
          <div className="w-full space-y-2 text-left text-sm">
            <p>
              <span className="text-text-secondary">Joined: </span>
              {format(new Date(employee.joiningDate), 'dd/MM/yyyy')}
            </p>
            <p>
              <span className="text-text-secondary">CNIC: </span>
              {employee.cnic}
            </p>
            <p>
              <span className="text-text-secondary">Phone: </span>
              {employee.phone ?? '—'}
              {' · '}
              <span className="text-text-secondary">Email: </span>
              {employee.email ?? '—'}
            </p>
          </div>
          <div className="flex w-full flex-col gap-2">
            {(canManagePersonalData || canEditJobInfo) && (
              <Button
                variant="outline"
                className="w-full no-print"
                onClick={() => window.print()}
              >
                <Printer className="mr-2 h-4 w-4" />
                Print Profile
              </Button>
            )}
            {canManagePersonalData && (
              <>
                {employee.photoUrl || employee.hasPrivatePhoto ? (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setFaceSyncOpen(true)}
                  >
                    <Fingerprint className="mr-2 h-4 w-4" />
                    Sync Face to Devices
                  </Button>
                ) : (
                  <p className="text-center text-xs text-text-secondary">
                    Upload photo first to enable face sync
                  </p>
                )}
              </>
            )}
            {canManagePersonalData && (
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setEditPersonalOpen(true)}
              >
                <Pencil className="mr-2 h-4 w-4" />
                Edit Personal Info
              </Button>
            )}
            {canEditJobInfo && (
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setEditJobOpen(true)}
              >
                <Pencil className="mr-2 h-4 w-4" />
                Edit Job Info
              </Button>
            )}
            {canHrJobActions && (
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setLetterOpen(true)}
              >
                Generate Letter
              </Button>
            )}
            {(canHrJobActions ||
              (canOverrideSuspendedStatus &&
                employee.status === 'SUSPENDED')) &&
              employee.status !== 'PENDING_APPROVAL' && (
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setStatusOpen(true)}
              >
                Change Status
              </Button>
            )}
            {canHrJobActions && employee.status === 'PENDING_APPROVAL' && (
              <>
                <p className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
                  Pending executive approval — status updates only when the
                  assigned approver reviews the onboarding request.
                </p>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={async () => {
                    try {
                      const share = await openOnboardingWhatsAppShare({
                        employeeId: employee.id,
                      })
                      toast({
                        title: `WhatsApp opened for ${share.approverLabel}`,
                        description: share.phoneConfigured
                          ? 'Prefilled approval message with HRMS login link.'
                          : 'Pick the approver contact in WhatsApp — no number was configured.',
                      })
                    } catch (err: unknown) {
                      const msg = (
                        err as {
                          response?: { data?: { message?: string | string[] } }
                        }
                      )?.response?.data?.message
                      toast({
                        title: 'Could not open WhatsApp',
                        description: Array.isArray(msg)
                          ? msg.join(', ')
                          : String(msg ?? 'Error'),
                        variant: 'destructive',
                      })
                    }
                  }}
                >
                  Send WhatsApp reminder
                </Button>
              </>
            )}
            {canHrJobActions && (
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setTransferOpen(true)}
              >
                Transfer
              </Button>
            )}
            {canEditBranchDuty && (
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setBranchDutyOpen(true)}
              >
                Edit Branch & Duty
              </Button>
            )}
          </div>
          <EmployeeDisciplineTrackRecord
            letters={letters}
            actions={disciplinary as DisciplinaryAction[]}
            isLoading={loadingLetters || loadingDisciplinary}
            currentStatus={employee.status}
          />
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="min-w-0">
        <TabsList className="flex h-auto flex-wrap gap-1">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="payroll">Payroll</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="leave">Leave</TabsTrigger>
          <TabsTrigger value="letters">Letters</TabsTrigger>
          <TabsTrigger value="disciplinary">Disciplinary</TabsTrigger>
          <TabsTrigger value="qualifications">Qualifications</TabsTrigger>
          <TabsTrigger value="previous-employment">Previous Employment</TabsTrigger>
          <TabsTrigger value="incentives">Incentives</TabsTrigger>
          <TabsTrigger value="additional-working-days">
            Additional working days
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-lg">Personal Info</CardTitle>
              {canManagePersonalData && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditPersonalOpen(true)}
                >
                  <Pencil className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              {hasPersonalInfo ? (
                <>
                <div className="flex flex-wrap items-center gap-2">
                  {employee.bloodGroup && (
                    <Badge variant="outline" className="bg-red-50 text-red-700">
                      Blood Group: {employee.bloodGroup}
                    </Badge>
                  )}
                  {employee.caste && (
                    <span>
                      <span className="text-text-secondary">Caste: </span>
                      {employee.caste}
                    </span>
                  )}
                </div>
                {(employee.province || employee.city) && (
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {employee.province && (
                      <p>
                        <span className="text-text-secondary">Province: </span>
                        {employee.province}
                      </p>
                    )}
                    {employee.city && (
                      <p>
                        <span className="text-text-secondary">City: </span>
                        {employee.city}
                      </p>
                    )}
                  </div>
                )}
                {(employee.domicile ||
                  employee.district ||
                  employee.tehsil ||
                  employee.policeStation) && (
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {employee.domicile && (
                      <p>
                        <span className="text-text-secondary">Domicile: </span>
                        {employee.domicile}
                      </p>
                    )}
                    {employee.district && (
                      <p>
                        <span className="text-text-secondary">District: </span>
                        {employee.district}
                      </p>
                    )}
                    {employee.tehsil && (
                      <p>
                        <span className="text-text-secondary">Tehsil: </span>
                        {employee.tehsil}
                      </p>
                    )}
                    {employee.policeStation && (
                      <p>
                        <span className="text-text-secondary">
                          Police Station:{' '}
                        </span>
                        {employee.policeStation}
                      </p>
                    )}
                  </div>
                )}
                {employee.fatherContactNumber && (
                  <p>
                    <span className="text-text-secondary">
                      Father Contact:{' '}
                    </span>
                    {employee.fatherContactNumber}
                  </p>
                )}
                {(employee.emergencyContactName ||
                  employee.emergencyContactNumber) && (
                  <p>
                    <span className="text-text-secondary">
                      Emergency Contact:{' '}
                    </span>
                    {employee.emergencyContactName ?? '—'}
                    {employee.emergencyContactNumber &&
                      ` (${employee.emergencyContactNumber})`}
                  </p>
                )}
                {(employee.spouseName || employee.spouseContactNumber) && (
                  <p>
                    <span className="text-text-secondary">Spouse: </span>
                    {employee.spouseName ?? '—'}
                    {employee.spouseContactNumber &&
                      ` (${employee.spouseContactNumber})`}
                  </p>
                )}
                {employee.currentAddress && (
                  <div>
                    <p className="text-text-secondary">Current Address</p>
                    <p className="whitespace-pre-wrap">
                      {employee.currentAddress}
                    </p>
                  </div>
                )}
                {employee.permanentAddress && (
                  <div>
                    <p className="text-text-secondary">Permanent Address</p>
                    <p className="whitespace-pre-wrap">
                      {employee.permanentAddress}
                    </p>
                  </div>
                )}
                </>
              ) : (
                <p className="text-text-secondary">
                  No personal details recorded yet.
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Working Hours Summary</CardTitle>
            </CardHeader>
            <CardContent>
              {loadingWorkingHours ? (
                <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-20" />
                  ))}
                </div>
              ) : (
                <>
                <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
                  {[
                    {
                      label: 'Total Hours',
                      value: workingHours?.totalHours ?? 0,
                    },
                    {
                      label: 'This Month',
                      value: workingHours?.thisMonthHours ?? 0,
                    },
                    {
                      label: 'Days Worked',
                      value: workingHours?.totalDays ?? 0,
                    },
                    {
                      label: 'Avg Daily Hours',
                      value: workingHours?.averageDailyHours ?? 0,
                    },
                    {
                      label: 'Total Minutes',
                      value: workingHours?.totalMinutes ?? 0,
                    },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="rounded-lg border border-border p-4 text-center"
                    >
                      <p className="text-2xl font-bold">{item.value}</p>
                      <p className="text-xs text-text-secondary">{item.label}</p>
                    </div>
                  ))}
                </div>
                {(workingHours?.anomalies ?? 0) > 0 && (
                  <p className="mt-3 text-sm text-amber-700">
                    {workingHours?.anomalies} day
                    {(workingHours?.anomalies ?? 0) === 1 ? '' : 's'} excluded
                    due to invalid punch times
                  </p>
                )}
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Employment History</CardTitle>
            </CardHeader>
            <CardContent>
              {history.length === 0 ? (
                <p className="text-sm text-text-secondary">No history records</p>
              ) : (
                <div className="relative space-y-0 pl-6">
                  {history.map((entry, i) => (
                    <div key={entry.id} className="relative pb-8 last:pb-0">
                      {i < history.length - 1 && (
                        <div className="absolute left-[-18px] top-2 h-full w-0.5 bg-border" />
                      )}
                      <div className="absolute left-[-22px] top-1.5 h-2.5 w-2.5 rounded-full bg-primary" />
                      <div className="rounded-lg border border-border p-4">
                        <div className="mb-2 flex flex-wrap items-center gap-2">
                          <Badge variant="outline">{entry.changeType}</Badge>
                          <span className="text-sm font-medium">
                            {entry.designation}
                          </span>
                        </div>
                        <p className="text-sm text-text-secondary">
                          {formatBranchLabel(entry.branch)} ·{' '}
                          {entry.department?.name ?? '—'}
                        </p>
                        <p className="mt-1 text-xs text-text-secondary">
                          {format(new Date(entry.effectiveDate), 'dd/MM/yyyy')} →{' '}
                          {entry.endDate
                            ? format(new Date(entry.endDate), 'dd/MM/yyyy')
                            : 'Present'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Stipend History</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Basic Stipend</TableHead>
                    <TableHead>Effective From</TableHead>
                    <TableHead>Effective To</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stipends.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={3} className="text-text-secondary">
                        No stipend records
                      </TableCell>
                    </TableRow>
                  ) : (
                    stipends.map((rec, i) => (
                      <TableRow key={rec.id}>
                        <TableCell>
                          PKR {Number(rec.basicStipend).toLocaleString()}
                          {i === 0 && !rec.effectiveTo && (
                            <Badge className="ml-2 bg-accent/20 text-accent-dark">
                              Current
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {format(new Date(rec.effectiveFrom), 'dd/MM/yyyy')}
                        </TableCell>
                        <TableCell>
                          {rec.effectiveTo
                            ? format(new Date(rec.effectiveTo), 'dd/MM/yyyy')
                            : '—'}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance" className="space-y-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1">
              <Label>Month</Label>
              <Select
                value={String(month)}
                onValueChange={(v) => setMonth(Number(v))}
              >
                <SelectTrigger className="w-[120px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                    <SelectItem key={m} value={String(m)}>
                      {format(new Date(2000, m - 1, 1), 'MMMM')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Year</Label>
              <Input
                type="number"
                className="w-[100px]"
                value={year}
                onChange={(e) => setYear(Number(e.target.value))}
              />
            </div>
          </div>

          {loadingSummary ? (
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
              {[...Array(12)].map((_, i) => (
                <Skeleton key={i} className="h-20" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
              {[
                { label: 'Present', value: attendanceSummary?.present ?? 0 },
                { label: 'Absent', value: attendanceSummary?.absent ?? 0 },
                {
                  label: 'Uninformed Absent',
                  value: attendanceSummary?.uninformedAbsent ?? 0,
                },
                { label: 'Late', value: attendanceSummary?.late ?? 0 },
                { label: 'Half Day', value: attendanceSummary?.halfDay ?? 0 },
                {
                  label: 'Short Leave',
                  value: attendanceSummary?.shortLeave ?? 0,
                },
                { label: 'On Leave', value: attendanceSummary?.onLeave ?? 0 },
                { label: 'Holiday', value: attendanceSummary?.holiday ?? 0 },
                {
                  label: 'Swap Covered',
                  value: attendanceSummary?.swapCovered ?? 0,
                },
                { label: 'Unmarked', value: attendanceSummary?.unmarked ?? 0 },
                {
                  label: 'Additional working days',
                  value: attendanceSummary?.additionalWorkingDays ?? 0,
                },
                {
                  label: 'Overtime hours',
                  value:
                    attendanceSummary?.overtimeHours ?? 0,
                },
              ].map((item) => (
                <Card key={item.label}>
                  <CardContent className="p-4 text-center">
                    <p className="text-2xl font-bold">{item.value}</p>
                    <p className="text-xs text-text-secondary">{item.label}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {(attendanceSummary?.missingDates?.length ?? 0) > 0 && (
            <p role="alert" className="text-sm text-amber-700">
              Payroll is blocked: {attendanceSummary?.missingDates?.length} dates have no final attendance status. Review the attendance record before generating salary.
            </p>
          )}
          {attendanceSummary?.risks?.map((risk) => (
            <p key={risk} className="text-xs text-text-secondary">{risk}</p>
          ))}
          {monthPayroll.length > 0 && (
            <Card>
              <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                <div>
                  <p className="text-sm text-text-secondary">
                    Calculated salary for {format(new Date(year, month - 1, 1), 'MMMM yyyy')}
                  </p>
                  <p className="text-xl font-bold">
                    PKR {monthPayrollNet.toLocaleString('en-PK')}
                  </p>
                  <p className="text-xs text-text-secondary">
                    Earned basic PKR {monthPayrollBasic.toLocaleString('en-PK')}
                    {monthPayrollPaid
                      ? ' · Paid (locked)'
                      : ' · Updates when attendance is saved'}
                  </p>
                </div>
                <StatusBadge status={monthPayrollPaid ? 'PAID' : monthPayroll[0].status} />
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Attendance Log</CardTitle>
            </CardHeader>
            <CardContent>
              {!attendanceUnlocked && (
                <p className="mb-3 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
                  {attendanceLockMessage(employee.status)}
                </p>
              )}
              {loadingLogs ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Check In</TableHead>
                      <TableHead>Check Out</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Late Min</TableHead>
                      <TableHead>Extra hours</TableHead>
                      <TableHead>Source</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {attendanceLogRows.length === 0 ? (
                      <TableRow>
                        <TableCell
                          colSpan={8}
                          className="text-text-secondary"
                        >
                          No attendance records
                        </TableCell>
                      </TableRow>
                    ) : (
                      attendanceLogRows.map((log) => {
                        const dateKey = String(log.date).slice(0, 10)
                        const isCreating = creatingMissingDate === dateKey
                        return (
                        <TableRow
                          key={log.id}
                          className={
                            log.isMissing
                              ? 'bg-amber-50/60'
                              : undefined
                          }
                        >
                          <TableCell>
                            {format(new Date(log.date), 'dd/MM/yyyy')}
                          </TableCell>
                          <TableCell>
                            {log.checkIn
                              ? formatDateTimeTime(log.checkIn)
                              : '—'}
                          </TableCell>
                          <TableCell>
                            {log.checkOut
                              ? formatDateTimeTime(log.checkOut)
                              : '—'}
                          </TableCell>
                          <TableCell>
                            {log.isMissing ? (
                              <Badge
                                variant="outline"
                                className="border-amber-300 bg-amber-100 text-amber-900"
                              >
                                Missing
                              </Badge>
                            ) : (
                              <AttendanceStatusBadge
                                status={log.status}
                                note={log.note}
                              />
                            )}
                          </TableCell>
                          <TableCell>
                            {log.isMissing ? '—' : (log.lateMinutes ?? 0)}
                          </TableCell>
                          <TableCell>
                            {log.isMissing
                              ? '—'
                              : (log.overtimeMinutes ?? 0) > 0
                                ? `${Math.round(((log.overtimeMinutes ?? 0) / 60) * 100) / 100}h`
                                : '—'}
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col gap-0.5 text-xs">
                              <span>In: {displayCheckInSource(log)}</span>
                              <span>Out: {displayCheckOutSource(log)}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-2">
                              {!log.isMissing && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setAttendanceTrailLog(log)}
                                >
                                  <History className="mr-1.5 h-3.5 w-3.5" />
                                  Trail
                                </Button>
                              )}
                              {canUpdateAttendance && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  disabled={isCreating}
                                  onClick={() => void openAttendanceUpdate(log)}
                                >
                                  <Pencil className="mr-1.5 h-3.5 w-3.5" />
                                  {log.isMissing
                                    ? isCreating
                                      ? 'Opening…'
                                      : 'Update'
                                    : 'Update'}
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                        )
                      })
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payroll" className="space-y-4">
          <EmployeePayrollTab
            employeeId={id}
            employeeName={employee.fullName}
            employeeCode={employee.employeeCode}
            joiningDate={employee.joiningDate}
            stipendRecords={(employee.stipendRecords ?? []) as StipendRecord[]}
            canEdit={canEditPayroll}
            onUpdated={() => {
              queryClient.invalidateQueries({ queryKey: ['employee', id] })
              queryClient.invalidateQueries({ queryKey: ['payroll-history', id] })
            }}
          />
        </TabsContent>

        <TabsContent value="documents" className="space-y-4">
          {canManagePersonalData && (
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1">
              <Label>Document Type</Label>
              <Select
                value={uploadType}
                onValueChange={(v) => setUploadType(v as DocumentType)}
              >
                <SelectTrigger className="w-[220px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(
                    [
                      'CNIC',
                      'EDUCATIONAL_CERTIFICATE',
                      'MEDICAL_CERTIFICATE',
                      'EXPERIENCE_LETTER',
                      'OTHER',
                    ] as DocumentType[]
                  ).map((t) => (
                    <SelectItem key={t} value={t}>
                      {t.replace(/_/g, ' ')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept=".jpg,.jpeg,.png,.pdf"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) uploadMutation.mutate(file)
                e.target.value = ''
              }}
            />
            <Button
              className="bg-primary hover:bg-primary-dark"
              disabled={uploadMutation.isPending}
              onClick={() => fileInputRef.current?.click()}
            >
              {uploadMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Upload Document
            </Button>
          </div>
          )}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {documents.length === 0 ? (
              <p className="text-sm text-text-secondary">No documents uploaded</p>
            ) : (
              documents.map((doc) => (
                <Card key={doc.id}>
                  <CardContent className="space-y-3 p-4">
                    <Badge variant="outline">
                      {doc.documentType.replace(/_/g, ' ')}
                    </Badge>
                    <div className="flex items-start gap-2">
                      <FileText className="mt-0.5 h-4 w-4 shrink-0 text-text-secondary" />
                      <p className="break-all text-sm font-medium">{doc.fileName}</p>
                    </div>
                    <p className="text-xs text-text-secondary">
                      {format(new Date(doc.uploadedAt), 'dd/MM/yyyy')}
                    </p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" asChild>
                        <a
                          href={resolveFileUrl(doc.fileUrl)}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Download className="mr-1 h-3 w-3" />
                          Download
                        </a>
                      </Button>
                      {canManagePersonalData && (
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={deleteDocMutation.isPending}
                        onClick={() => deleteDocMutation.mutate(doc.id)}
                      >
                        <Trash2 className="h-3 w-3 text-red-600" />
                      </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="leave" className="space-y-4">
          <Card>
            <CardContent className="p-6">
              {leaveBalance ? (
                <p className="text-lg">
                  Taken{' '}
                  <span className="font-bold">{leaveBalance.taken}</span> /{' '}
                  {leaveBalance.totalAllowed} days · Remaining{' '}
                  <span className="font-bold text-accent-dark">
                    {leaveBalance.remaining}
                  </span>{' '}
                  days
                </p>
              ) : (
                <Skeleton className="h-8 w-64" />
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Leave History</CardTitle>
            </CardHeader>
            <CardContent>
              {loadingLeaves ? (
                <div className="space-y-2">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>From</TableHead>
                      <TableHead>To</TableHead>
                      <TableHead>Days</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Approved By</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leaves.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-text-secondary">
                          No leave records
                        </TableCell>
                      </TableRow>
                    ) : (
                      leaves.map((leave) => (
                        <TableRow key={leave.id}>
                          <TableCell>
                            {format(new Date(leave.startDate), 'dd/MM/yyyy')}
                          </TableCell>
                          <TableCell>
                            {format(new Date(leave.endDate), 'dd/MM/yyyy')}
                          </TableCell>
                          <TableCell>{leave.totalDays}</TableCell>
                          <TableCell>{leave.reason ?? '—'}</TableCell>
                          <TableCell>{leaveStatusBadge(leave.status)}</TableCell>
                          <TableCell>{leave.approvedBy ?? '—'}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="letters" className="space-y-4">
          <Button
            className="bg-primary hover:bg-primary-dark"
            onClick={() => setLetterOpen(true)}
          >
            Generate New Letter
          </Button>

          <Card>
            <CardContent className="p-0">
              {loadingLetters ? (
                <div className="space-y-2 p-4">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Incident</TableHead>
                      <TableHead>Occ.</TableHead>
                      <TableHead>Generated</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {letters.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-text-secondary">
                          No letters generated
                        </TableCell>
                      </TableRow>
                    ) : (
                      letters.map((letter) => {
                        const status = letterStatus(letter)
                        return (
                          <TableRow
                            key={letter.id}
                            className={
                              status.label === 'Reversed'
                                ? 'opacity-70'
                                : undefined
                            }
                          >
                            <TableCell>
                              {letterTypeLabel(letter.letterType)}
                            {letter.status && letter.status !== 'SENT' && (
                              <Badge
                                variant="secondary"
                                className="ml-2 font-normal"
                              >
                                {letter.status.replace(/_/g, ' ')}
                              </Badge>
                            )}
                            {letter.letterType === 'APPOINTMENT' &&
                              letter.templateCode && (
                                <span className="ml-2 font-mono text-xs text-text-secondary">
                                  {letter.templateCode}
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="text-sm">
                              {letterDisciplineReason(letter)}
                            </TableCell>
                            <TableCell className="text-sm">
                              {letterIncidentDate(letter)}
                            </TableCell>
                            <TableCell className="text-sm">
                              {letterOccurrence(letter)}
                            </TableCell>
                            <TableCell>
                              {format(
                                new Date(letter.generatedAt),
                                'dd/MM/yyyy',
                              )}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className={status.className}
                              >
                                {status.label}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-mono text-sm">
                              {letterReference(letter)}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => downloadPdf(letter.id)}
                                >
                                  {letter.status === 'SENT'
                                    ? 'Download PDF'
                                    : letter.letterType === 'APPOINTMENT'
                                      ? 'Print Draft'
                                      : letter.status === 'DRAFT'
                                        ? 'Preview PDF'
                                        : 'Download PDF'}
                                </Button>
                                {letter.status === 'DRAFT' && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setEditAppointmentPreviewHtml(null)
                                      setEditAppointmentLetter(letter)
                                    }}
                                  >
                                    Edit
                                  </Button>
                                )}
                                {letter.letterType === 'APPOINTMENT' &&
                                  letter.status !== 'DRAFT' && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setEditAppointmentPreviewHtml(null)
                                      setEditAppointmentLetter(letter)
                                    }}
                                  >
                                    Preview
                                  </Button>
                                )}
                                {letter.letterType === 'APPOINTMENT' &&
                                  letter.status === 'DRAFT' &&
                                  employee.status !== 'ACTIVE' && (
                                    <Button
                                      size="sm"
                                      disabled={
                                        submitAppointmentMutation.isPending
                                      }
                                      onClick={() =>
                                        submitAppointmentMutation.mutate(
                                          letter.id,
                                        )
                                      }
                                    >
                                      Submit for Approval
                                    </Button>
                                  )}
                                {letter.letterType === 'APPOINTMENT' &&
                                  letter.status === 'PENDING_APPROVAL' &&
                                  canApproveAppointment && (
                                    <>
                                      <Button
                                        size="sm"
                                        disabled={
                                          approveAppointmentMutation.isPending
                                        }
                                        onClick={() =>
                                          approveAppointmentMutation.mutate(
                                            letter.id,
                                          )
                                        }
                                      >
                                        Approve
                                      </Button>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        disabled={
                                          rejectAppointmentMutation.isPending
                                        }
                                        onClick={() =>
                                          rejectAppointmentMutation.mutate(
                                            letter.id,
                                          )
                                        }
                                      >
                                        Return
                                      </Button>
                                    </>
                                  )}
                                {letter.letterType === 'APPOINTMENT' &&
                                  employee.status === 'ACTIVE' &&
                                  (letter.status === 'DRAFT' ||
                                    letter.status === 'PENDING_APPROVAL') && (
                                    <Button
                                      size="sm"
                                      disabled={
                                        sendAppointmentMutation.isPending
                                      }
                                      onClick={() =>
                                        sendAppointmentMutation.mutate(
                                          letter.id,
                                        )
                                      }
                                    >
                                      Send
                                    </Button>
                                  )}
                                {letter.letterType === 'APPOINTMENT' &&
                                  letter.status === 'APPROVED' && (
                                    <>
                                      {canApproveAppointment && (
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          disabled={
                                            rejectAppointmentMutation.isPending
                                          }
                                          onClick={() =>
                                            rejectAppointmentMutation.mutate(
                                              letter.id,
                                            )
                                          }
                                        >
                                          Return
                                        </Button>
                                      )}
                                      <Button
                                        size="sm"
                                        disabled={
                                          sendAppointmentMutation.isPending
                                        }
                                        onClick={() =>
                                          sendAppointmentMutation.mutate(
                                            letter.id,
                                          )
                                        }
                                      >
                                        Send
                                      </Button>
                                    </>
                                  )}
                                <Button
                                  variant="outline"
                                  size="sm"
                                  disabled={
                                    !!letter.printedAt ||
                                    markPrintedMutation.isPending
                                  }
                                  onClick={() =>
                                    markPrintedMutation.mutate(letter.id)
                                  }
                                >
                                  {letter.printedAt
                                    ? 'Printed'
                                    : 'Mark Printed'}
                                </Button>
                                {canReverseLetters &&
                                  letter.status === 'SENT' && (
                                    <DropdownMenu>
                                      <DropdownMenuTrigger asChild>
                                        <Button variant="outline" size="sm">
                                          <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                      </DropdownMenuTrigger>
                                      <DropdownMenuContent align="end">
                                        <DropdownMenuItem
                                          className="text-red-600"
                                          onClick={() => {
                                            setReverseLetter(letter)
                                            setReverseReason('')
                                          }}
                                        >
                                          Reverse (IT)
                                        </DropdownMenuItem>
                                      </DropdownMenuContent>
                                    </DropdownMenu>
                                  )}
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="disciplinary" className="space-y-4">
          {loadingDisciplinary ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : disciplinary.length === 0 ? (
            <p className="text-sm text-text-secondary">
              No disciplinary actions on record
            </p>
          ) : (
            <div className="space-y-3">
              {disciplinary.map((action) => (
                <Card key={action.id}>
                  <CardContent className="flex flex-wrap items-center gap-3 p-4">
                    <Badge variant="outline">{action.type}</Badge>
                    <span className="flex-1 text-sm">{action.reason}</span>
                    <StatusBadge status={action.status} />
                    <span className="text-xs text-text-secondary">
                      {format(new Date(action.issuedAt), 'dd/MM/yyyy')}
                    </span>
                    {action.inquiry && (
                      <Badge variant="outline" className="text-xs">
                        Inquiry: {action.inquiry.outcome ?? 'Pending'}
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="qualifications" className="space-y-4">
          <QualificationSection
            employeeId={id}
            qualType="ACADEMIC"
            title="Academic Qualifications"
            qualifications={qualifications as AcademicQualification[]}
            isLoading={loadingQualifications}
            canEdit={canManagePersonalData}
          />
          <QualificationSection
            employeeId={id}
            qualType="JOB_RELEVANT"
            title="Job-Relevant Qualifications"
            qualifications={qualifications as AcademicQualification[]}
            isLoading={loadingQualifications}
            canEdit={canManagePersonalData}
          />
        </TabsContent>

        <TabsContent value="previous-employment" className="space-y-4">
          {canManagePersonalData && (
          <Button
            className="bg-primary hover:bg-primary-dark"
            onClick={() => setPrevEmpOpen(true)}
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Previous Employment
          </Button>
          )}

          <Card>
            <CardContent className="p-0">
              {loadingPreviousEmployment ? (
                <div className="space-y-2 p-4">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-8" />
                      <TableHead>Organization</TableHead>
                      <TableHead>Owner / Admin</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Experience</TableHead>
                      <TableHead className="w-12" />
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(previousEmployments as PreviousEmployment[]).length ===
                    0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-text-secondary">
                          No previous employment records
                        </TableCell>
                      </TableRow>
                    ) : (
                      (previousEmployments as PreviousEmployment[]).map(
                        (emp) => (
                          <Fragment key={emp.id}>
                            <TableRow key={emp.id}>
                              <TableCell>
                                {emp.jobResponsibilities && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-6 w-6 p-0"
                                    onClick={() =>
                                      setExpandedPrevEmpId(
                                        expandedPrevEmpId === emp.id
                                          ? null
                                          : emp.id,
                                      )
                                    }
                                  >
                                    {expandedPrevEmpId === emp.id ? (
                                      <ChevronDown className="h-4 w-4" />
                                    ) : (
                                      <ChevronRight className="h-4 w-4" />
                                    )}
                                  </Button>
                                )}
                              </TableCell>
                              <TableCell className="font-medium">
                                {emp.organizationName}
                              </TableCell>
                              <TableCell>
                                {emp.ownerAdminName ?? '—'}
                              </TableCell>
                              <TableCell>
                                {emp.contactNumber ?? '—'}
                              </TableCell>
                              <TableCell>
                                {emp.totalExperience ?? '—'}
                              </TableCell>
                              <TableCell>
                                {canManagePersonalData ? (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  disabled={deletePrevEmpMutation.isPending}
                                  onClick={() =>
                                    deletePrevEmpMutation.mutate(emp.id)
                                  }
                                >
                                  <Trash2 className="h-4 w-4 text-red-600" />
                                </Button>
                                ) : (
                                  '—'
                                )}
                              </TableCell>
                            </TableRow>
                            {expandedPrevEmpId === emp.id && (
                              <TableRow key={`${emp.id}-details`}>
                                <TableCell colSpan={6} className="bg-muted/30">
                                  <div className="space-y-2 p-2 text-sm">
                                    {emp.postalAddress && (
                                      <p>
                                        <span className="text-text-secondary">
                                          Address:{' '}
                                        </span>
                                        {emp.postalAddress}
                                      </p>
                                    )}
                                    {emp.relevantExperience && (
                                      <p>
                                        <span className="text-text-secondary">
                                          Relevant Experience:{' '}
                                        </span>
                                        {emp.relevantExperience}
                                      </p>
                                    )}
                                    {emp.jobResponsibilities && (
                                      <div>
                                        <p className="text-text-secondary">
                                          Job Responsibilities
                                        </p>
                                        <p className="whitespace-pre-wrap">
                                          {emp.jobResponsibilities}
                                        </p>
                                      </div>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            )}
                          </Fragment>
                        ),
                      )
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="incentives" className="space-y-4">
          {canAddIncentive && (
            <Button
              className="bg-primary hover:bg-primary-dark"
              onClick={() => setIncentiveOpen(true)}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Incentive
            </Button>
          )}
          <Card>
            <CardContent className="p-0">
              {loadingIncentives ? (
                <div className="space-y-2 p-4">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Month/Year</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Added By</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(incentives as Incentive[]).length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-text-secondary">
                          No incentives recorded
                        </TableCell>
                      </TableRow>
                    ) : (
                      <>
                        {(incentives as Incentive[]).map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>
                              {item.month}/{item.year}
                            </TableCell>
                            <TableCell className="font-medium text-green-600">
                              PKR {Number(item.amount).toLocaleString('en-PK')}
                            </TableCell>
                            <TableCell className="max-w-[240px] truncate" title={item.reason}>
                              {item.reason}
                            </TableCell>
                            <TableCell className="font-mono text-xs">
                              {item.addedBy.slice(0, 8)}…
                            </TableCell>
                            <TableCell>
                              {format(new Date(item.createdAt), 'dd/MM/yyyy')}
                            </TableCell>
                          </TableRow>
                        ))}
                        <TableRow className="bg-surface font-semibold">
                          <TableCell>Total</TableCell>
                          <TableCell className="text-green-600">
                            PKR {incentiveTotal.toLocaleString('en-PK')}
                          </TableCell>
                          <TableCell colSpan={3} />
                        </TableRow>
                      </>
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="additional-working-days" className="space-y-4">
          <AdditionalWorkingDaysTab
            employeeId={id}
            dailyDutyHours={employee.dutyTotalHours}
            canEdit={canEditAdditionalWorkingDays}
          />
        </TabsContent>
      </Tabs>

      <AddIncentiveDialog
        open={incentiveOpen}
        onOpenChange={setIncentiveOpen}
        defaultEmployeeId={id}
        onSuccess={() =>
          queryClient.invalidateQueries({ queryKey: ['incentives', id] })
        }
      />

      <AddPreviousEmploymentDialog
        open={prevEmpOpen}
        onOpenChange={setPrevEmpOpen}
        employeeId={id}
      />

      <UpdateAttendanceDialog
        log={attendanceToEdit}
        open={attendanceToEdit !== null}
        onOpenChange={(open) => {
          if (!open) setAttendanceToEdit(null)
        }}
        onSuccess={() => {
          queryClient.invalidateQueries({
            queryKey: ['attendance', 'logs', id, month, year],
          })
          queryClient.invalidateQueries({
            queryKey: ['attendance', 'summary', id, month, year],
          })
          queryClient.invalidateQueries({ queryKey: ['working-hours', id] })
          queryClient.invalidateQueries({ queryKey: ['payroll-history', id] })
          queryClient.invalidateQueries({ queryKey: ['payroll-entries'] })
          queryClient.invalidateQueries({ queryKey: ['payroll-summary'] })
          queryClient.invalidateQueries({ queryKey: ['leave-balance', id] })
          queryClient.invalidateQueries({ queryKey: ['leave', id] })
          queryClient.invalidateQueries({
            queryKey: ['attendance', 'trail', attendanceToEdit?.id],
          })
        }}
      />
      <AttendanceTrailDialog
        log={attendanceTrailLog}
        open={attendanceTrailLog !== null}
        onOpenChange={(open) => {
          if (!open) setAttendanceTrailLog(null)
        }}
      />

      <FaceSyncDialog
        open={faceSyncOpen}
        onOpenChange={setFaceSyncOpen}
        employeeId={id}
        employeeName={employee.fullName}
        photoUrl={photoSrc}
        hasPrivatePhoto={employee.hasPrivatePhoto}
        lastSyncedAt={
          faceSyncStats?.latestJob?.status === 'SYNCED'
            ? faceSyncStats.latestJob.updatedAt
            : null
        }
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ['face-sync', 'stats', id] })
        }}
      />
      <GenerateLetterDialog
        open={letterOpen}
        onOpenChange={setLetterOpen}
        employeeId={id}
        onOpenAppointmentDraft={(opened, html) => {
          setEditAppointmentPreviewHtml(html)
          setEditAppointmentLetter(opened)
        }}
      />
      <EditDraftLetterDialog
        letter={editAppointmentLetter}
        open={!!editAppointmentLetter}
        initialPreviewHtml={editAppointmentPreviewHtml}
        canApprove={canApproveAppointment}
        onLetterUpdated={setEditAppointmentLetter}
        onOpenChange={(open) => {
          if (!open) {
            setEditAppointmentLetter(null)
            setEditAppointmentPreviewHtml(null)
          }
        }}
      />
      <Dialog
        open={!!reverseLetter}
        onOpenChange={(open) => {
          if (!open) {
            setReverseLetter(null)
            setReverseReason('')
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reverse letter (IT)</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-text-secondary">
            This voids the letter on the portal and unwinds linked pending
            fines or two-day absence deductions where payroll is not finalized.
          </p>
          <div className="space-y-2">
            <Label>Reason</Label>
            <Textarea
              value={reverseReason}
              onChange={(e) => setReverseReason(e.target.value)}
              placeholder="Why is this letter being reversed?"
            />
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setReverseLetter(null)
                setReverseReason('')
              }}
            >
              Cancel
            </Button>
            <Button
              className="bg-red-600 hover:bg-red-700"
              disabled={
                reverseReason.trim().length < 3 ||
                reverseLetterMutation.isPending
              }
              onClick={() => {
                if (!reverseLetter) return
                reverseLetterMutation.mutate({
                  letterId: reverseLetter.id,
                  reason: reverseReason.trim(),
                })
              }}
            >
              Reverse letter
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ChangeStatusDialog
        open={statusOpen}
        onOpenChange={setStatusOpen}
        employeeId={id}
        currentStatus={employee.status}
      />
      <TransferDialog
        open={transferOpen}
        onOpenChange={setTransferOpen}
        employeeId={id}
        employee={employee}
        currentDesignation={employee.currentDesignation}
      />
      <UpdateBranchDutyDialog
        employee={employee}
        open={branchDutyOpen}
        onOpenChange={setBranchDutyOpen}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ['employee', id] })
        }}
      />
      {editPersonalOpen && (
        <EditEmployeeDialog
          employee={employee}
          mode="personal"
          open={editPersonalOpen}
          onOpenChange={setEditPersonalOpen}
          canEditCnic={isHrTeam || isItTeam}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: ['employee', id] })
            queryClient.invalidateQueries({ queryKey: ['employees'] })
          }}
        />
      )}
      {editJobOpen && (
        <EditEmployeeDialog
          employee={employee}
          mode="job"
          open={editJobOpen}
          onOpenChange={setEditJobOpen}
          canEditCnic={isHrTeam || isItTeam}
          canAssignRoles={canAssignRoles}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: ['employee', id] })
            queryClient.invalidateQueries({ queryKey: ['employees'] })
          }}
        />
      )}
    </div>
    </>
  )
}
