import api from '../axios'
import type { DisciplinaryAction, Inquiry } from '@/types'

export const disciplinaryApi = {
  getAll: (params?: Record<string, unknown>) =>
    api.get<unknown, DisciplinaryAction[]>('/disciplinary', { params }),
  /** Cases that still need action: not yet started, waiting approval, or under inquiry. */
  getActiveCases: async () => {
    const [open, underInquiry] = await Promise.all([
      api.get<unknown, DisciplinaryAction[]>('/disciplinary', {
        params: { status: 'OPEN' },
      }),
      api.get<unknown, DisciplinaryAction[]>('/disciplinary', {
        params: { status: 'UNDER_INQUIRY' },
      }),
    ])
    const byId = new Map<string, DisciplinaryAction>()
    for (const row of [...open, ...underInquiry]) byId.set(row.id, row)
    return [...byId.values()]
  },
  getOne: (id: string) => api.get(`/disciplinary/${id}`),
  create: (data: Record<string, unknown>) => api.post('/disciplinary', data),
  startInquiry: (data: Record<string, unknown>) =>
    api.post('/disciplinary/inquiry', data),
  resolveInquiry: (data: Record<string, unknown>) =>
    api.patch('/disciplinary/inquiry/resolve', data),
  ensureInquiry: (actionId: string) =>
    api.post<unknown, Inquiry>(`/disciplinary/${actionId}/ensure-inquiry`),
  listEligibleApprovers: () =>
    api.get<
      unknown,
      Array<{
        id: string
        displayName: string
        employeeCode: string | null
        phone: string | null
        eligibleRole: string
      }>
    >('/disciplinary/suspension/eligible-approvers'),
  listInquiryOfficers: () =>
    api.get<
      unknown,
      Array<{
        id: string
        displayName: string
        employeeCode: string | null
        designation: string | null
        phone: string | null
        role: string
      }>
    >('/disciplinary/suspension/inquiry-officers'),
  prepareSuspension: (actionId: string, data: Record<string, unknown>) =>
    api.post<unknown, { id: string }>(
      `/disciplinary/${actionId}/suspension/prepare`,
      data,
    ),
  getSuspensionRequest: (id: string) =>
    api.get(`/disciplinary/suspension-requests/${id}`),
  updateSuspensionRequest: (id: string, data: Record<string, unknown>) =>
    api.patch(`/disciplinary/suspension-requests/${id}`, data),
  submitSuspensionRequest: (id: string) =>
    api.post(`/disciplinary/suspension-requests/${id}/submit`),
  listMyPendingApprovals: () =>
    api.get<unknown, SuspensionApprovalRequest[]>(
      '/disciplinary/suspension-approvals/my-pending',
    ),
  getAssignedApproval: (id: string) =>
    api.get<unknown, SuspensionApprovalRequest>(
      `/disciplinary/suspension-approvals/${id}`,
    ),
  approveSuspensionRequest: (id: string, note?: string) =>
    api.post(`/disciplinary/suspension-requests/${id}/approve`, { note }),
  rejectSuspensionRequest: (id: string, reason: string) =>
    api.post(`/disciplinary/suspension-requests/${id}/reject`, { reason }),
  getAssignedApprovalLetterPdf: (id: string) =>
    api.get<unknown, Blob>(
      `/disciplinary/suspension-approvals/${id}/letter-pdf`,
      { responseType: 'blob' },
    ),
  recordInquiryFinding: (id: string, data: Record<string, unknown>) =>
    api.post(`/disciplinary/inquiries/${id}/finding`, data),
  submitInquiryFinalDecision: (id: string, data: Record<string, unknown>) =>
    api.post(`/disciplinary/inquiries/${id}/final-decision`, data),
  listMyPendingInquiryDecisions: () =>
    api.get<unknown, InquiryDecisionPending[]>(
      '/disciplinary/inquiry-decisions/my-pending',
    ),
  approveInquiryFinalDecision: (id: string, note?: string) =>
    api.post(`/disciplinary/inquiries/${id}/final-decision/approve`, { note }),
  rejectInquiryFinalDecision: (id: string, reason: string) =>
    api.post(`/disciplinary/inquiries/${id}/final-decision/reject`, { reason }),
  generateMissingFinalLetters: (id: string) =>
    api.post(`/disciplinary/inquiries/${id}/final-letters/generate-missing`),
  closeInquiry: (id: string, data: Record<string, unknown>) =>
    api.post(`/disciplinary/inquiries/${id}/close`, data),
  listMyPendingOpenApprovals: () =>
    api.get<unknown, Inquiry[]>(
      '/disciplinary/inquiry-open-approvals/my-pending',
    ),
  approveInquiryOpen: (id: string, note?: string) =>
    api.post(`/disciplinary/inquiries/${id}/open/approve`, { note }),
  rejectInquiryOpen: (id: string, reason: string) =>
    api.post(`/disciplinary/inquiries/${id}/open/reject`, { reason }),
  /** Req 9: Suspend inside an inquiry (executives apply at once; others ask an executive). */
  suspendFromInquiry: (
    id: string,
    data: { suspendFrom: string; reason: string; approverUserId?: string },
  ) => api.post<unknown, { status: string }>(`/disciplinary/inquiries/${id}/suspend`, data),
  inquirySuspendApprovers: () =>
    api.get<unknown, Array<{ id: string; displayName: string; eligibleRole: string }>>(
      '/disciplinary/inquiry-suspend-approvers',
    ),
  myPendingInquirySuspends: () =>
    api.get<
      unknown,
      Array<{
        id: string
        suspendFrom: string
        suspendReason: string | null
        suspendRequestedAt: string
        disciplinaryAction: {
          reason: string
          employee: {
            id: string
            fullName: string
            employeeCode: string | null
            currentBranch: { name: string } | null
          }
        }
      }>
    >('/disciplinary/inquiry-suspend-approvals/my-pending'),
  approveInquirySuspend: (id: string, note?: string) =>
    api.post(`/disciplinary/inquiries/${id}/suspend/approve`, { note }),
  rejectInquirySuspend: (id: string, reason: string) =>
    api.post(`/disciplinary/inquiries/${id}/suspend/reject`, { reason }),
}

export type SuspensionApprovalRequest = {
  id: string
  status: string
  reason: string
  periodStart: string
  periodEnd: string
  inquiryDeadlineAt: string
  durationDays?: number
  submittedAt?: string | null
  decisionNote?: string | null
  employee?: {
    id: string
    fullName: string
    employeeCode: string
    status?: string
    currentBranch?: { name: string; abbreviation?: string | null } | null
  }
  inquiryOfficer?: {
    email: string
    employee?: { fullName: string } | null
  } | null
  submittedBy?: {
    email: string
    employee?: { fullName: string } | null
  } | null
  letter?: {
    id: string
    status: string
    letterType: string
    letterNo?: string | null
  } | null
  disciplinaryAction?: {
    id: string
    type: string
    status: string
    reason: string
  } | null
}

export type InquiryDecisionPending = Inquiry

