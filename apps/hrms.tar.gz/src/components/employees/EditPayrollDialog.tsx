import { useEffect, useState } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { employeesApi } from '@/api/endpoints/employees'
import { payrollApi } from '@/api/endpoints/payroll'
import { DateInput } from '@/components/common/DateInput'
import { StipendPackageFields } from '@/components/payroll/StipendPackageFields'
import { PaySlipEditor, usePaySlipDraft } from '@/components/payroll/PaySlipEditor'
import type { EmployeeApproverTarget } from '@/api/endpoints/employeeOnboarding'
import { isPendingApproval, payApprovalsApi } from '@/api/endpoints/payApprovals'
import {
  useCanEditPay,
  useNeedsPayApproval,
} from '@/components/payroll/ApproverSelect'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from '@/hooks/use-toast'
import { DEFAULT_STIPEND_VALUES } from '@/lib/stipendUtils'
import { ConfirmDialog } from '@/components/common/ConfirmDialog'
import { useAuth } from '@/hooks/useAuth'
import type { StipendRecord } from '@/types'

const stipendFieldSchema = z.number().min(0)

const editPayrollSchema = z.object({
  joiningDate: z.string().min(1, 'Joining date is required'),
  basicStipend: z.number().min(0),
  allowances: stipendFieldSchema,
  reward: stipendFieldSchema,
  progressReward: stipendFieldSchema,
  fuelAllowance: stipendFieldSchema,
  loanDeduction: stipendFieldSchema,
  advanceDeduction: stipendFieldSchema,
  fineDeduction: stipendFieldSchema,
  healthDeduction: stipendFieldSchema,
  effectiveFrom: z.string().optional(),
  reason: z.string().optional(),
})

type EditPayrollFormValues = z.infer<typeof editPayrollSchema>

type EditPayrollDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  employeeId: string
  joiningDate: string
  packageVerifiedAt?: string | null
  latestStipend?: StipendRecord
  onSuccess: () => void
}

function toDateInput(value?: string | null) {
  if (!value) return ''
  return value.slice(0, 10)
}

function stipendValuesFromRecord(record: StipendRecord) {
  return {
    basicStipend: Number(record.basicStipend) || 0,
    allowances: Number(record.allowances) || 0,
    reward: Number(record.reward) || 0,
    progressReward: Number(record.progressReward) || 0,
    fuelAllowance: Number(record.fuelAllowance) || 0,
    loanDeduction: Number(record.loanDeduction) || 0,
    advanceDeduction: Number(record.advanceDeduction) || 0,
    fineDeduction: Number(record.fineDeduction) || 0,
    healthDeduction: Number(record.healthDeduction) || 0,
  }
}

function stipendAmountsChanged(
  values: EditPayrollFormValues,
  record: StipendRecord,
): boolean {
  const current = stipendValuesFromRecord(record)
  return (
    values.basicStipend !== current.basicStipend ||
    values.allowances !== current.allowances ||
    values.reward !== current.reward ||
    values.progressReward !== current.progressReward ||
    values.fuelAllowance !== current.fuelAllowance ||
    values.loanDeduction !== current.loanDeduction ||
    values.advanceDeduction !== current.advanceDeduction ||
    values.fineDeduction !== current.fineDeduction ||
    values.healthDeduction !== current.healthDeduction
  )
}

function firstOfMonthIso(isoDate: string): string {
  if (!isoDate || isoDate.length < 7) return isoDate
  return `${isoDate.slice(0, 7)}-01`
}

function firstOfCurrentMonthIso(): string {
  const now = new Date()
  const y = now.getFullYear()
  const m = String(now.getMonth() + 1).padStart(2, '0')
  return `${y}-${m}-01`
}

export function EditPayrollDialog({
  open,
  onOpenChange,
  employeeId,
  joiningDate,
  packageVerifiedAt,
  latestStipend,
  onSuccess,
}: EditPayrollDialogProps) {
  const [isIncrement, setIsIncrement] = useState(false)
  const originalJoiningDate = toDateInput(joiningDate)
  const originalEffectiveFrom = toDateInput(latestStipend?.effectiveFrom)

  const form = useForm<EditPayrollFormValues>({
    resolver: zodResolver(editPayrollSchema),
    defaultValues: {
      joiningDate: originalJoiningDate,
      ...DEFAULT_STIPEND_VALUES,
      effectiveFrom: originalEffectiveFrom,
      reason: '',
    },
  })

  const slip = usePaySlipDraft(employeeId, form)

  useEffect(() => {
    if (!open) return

    const stipendDefaults = latestStipend
      ? stipendValuesFromRecord(latestStipend)
      : DEFAULT_STIPEND_VALUES

    form.reset({
      joiningDate: originalJoiningDate,
      ...stipendDefaults,
      effectiveFrom: toDateInput(latestStipend?.effectiveFrom),
      reason: '',
    })
    setIsIncrement(false)
  }, [open, originalJoiningDate, latestStipend, form])

  const needsApproval = useNeedsPayApproval()
  // HR sets salary only when adding the employee; later changes are Finance's.
  const canEditPay = useCanEditPay()
  // Before Finance verifies, Finance saves directly; after it, changes go to the Founder.
  const verified = Boolean(packageVerifiedAt)
  // Verified package: a Basic change or an increment needs the signed notification.
  const [notificationFile, setNotificationFile] = useState<File>()
  const canVerify =
    useAuth().hasRole(['PAYROLL_OFFICER', 'SUPER_ADMIN']) &&
    !verified &&
    latestStipend != null &&
    canEditPay
  const [verifyValues, setVerifyValues] = useState<EditPayrollFormValues>()
  const queryClient = useQueryClient()
  const mutation = useMutation({
    mutationFn: async (
      values: EditPayrollFormValues & { isIncrement?: boolean; verify?: boolean },
    ): Promise<string | null> => {
      let sentTo: string | null = null
      const joiningChanged = values.joiningDate !== originalJoiningDate
      const amountsChanged =
        latestStipend != null && stipendAmountsChanged(values, latestStipend)
      const effectiveFromChanged =
        latestStipend != null &&
        !!values.effectiveFrom?.trim() &&
        values.effectiveFrom.trim() !== originalEffectiveFrom
      const stipendUpdate = amountsChanged || effectiveFromChanged

      if (!joiningChanged && !stipendUpdate && !slip.changed && !values.verify) {
        throw new Error('No changes to save')
      }

      if (stipendUpdate && latestStipend) {
        const packageValues = {
          employeeId,
          basicStipend: values.basicStipend,
          allowances: values.allowances,
          reward: values.reward,
          progressReward: values.progressReward,
          fuelAllowance: values.fuelAllowance,
          loanDeduction: values.loanDeduction,
          advanceDeduction: values.advanceDeduction,
          fineDeduction: values.fineDeduction,
          healthDeduction: values.healthDeduction,
        }

        if (values.isIncrement) {
          const snapped = firstOfMonthIso(
            values.effectiveFrom?.trim() || firstOfCurrentMonthIso(),
          )
          if (!snapped) {
            throw new Error('Effective date is required for a salary increment')
          }
          if (!values.reason?.trim()) {
            throw new Error('Reason is required for a salary increment')
          }

          const res = await payrollApi.increment({
            ...packageValues,
            effectiveFrom: snapped,
            reason: values.reason.trim(),
            approverTarget: verified ? ('FOUNDER' as EmployeeApproverTarget) : undefined,
          })
          if (isPendingApproval(res)) {
            sentTo = res.approverLabel
            if (notificationFile) await payApprovalsApi.attach(res.request.id, notificationFile)
          }
        } else {
          const res = await payrollApi.updateActiveStipend({
            approverTarget: verified ? ('FOUNDER' as EmployeeApproverTarget) : undefined,
            ...packageValues,
            // A package starting in a later month needs its date sent even when unchanged.
            ...(effectiveFromChanged ||
            originalEffectiveFrom.slice(0, 7) > new Date().toISOString().slice(0, 7)
              ? { effectiveFrom: values.effectiveFrom?.trim() || originalEffectiveFrom }
              : {}),
            reason:
              values.reason?.trim() ||
              (effectiveFromChanged
                ? 'Correct package effective date (management order: from month day 1)'
                : 'Correct current stipend package'),
          })
          if (isPendingApproval(res)) {
            sentTo = res.approverLabel
            if (notificationFile) await payApprovalsApi.attach(res.request.id, notificationFile)
          }
        }
      }

      // Allowances, incentives and deductions typed in the slip section.
      if (slip.changed) {
        const res = await slip.apply()
        if (res.pending) sentTo = res.approverLabel
      }

      if (joiningChanged) {
        await employeesApi.update(employeeId, {
          joiningDate: values.joiningDate,
        })
      }
      if (values.verify) {
        await payrollApi.verifyPackage(employeeId)
        return 'VERIFIED'
      }
      return sentTo
    },
    onSuccess: (sentTo) => {
      toast({
        title:
          sentTo === 'VERIFIED'
            ? 'Package saved and verified. Any further change needs Founder approval.'
            : sentTo
              ? `Change sent to ${sentTo} for approval`
              : 'Payroll information updated',
      })
      // Joining date decides loan eligibility.
      queryClient.invalidateQueries({ queryKey: ['loans', employeeId] })
      queryClient.invalidateQueries({ queryKey: ['salary-history', employeeId] })
      onSuccess()
      onOpenChange(false)
    },
    onError: (err: Error & { response?: { data?: { message?: string | string[] } } }) => {
      const apiMsg = err.response?.data?.message
      const description = apiMsg
        ? Array.isArray(apiMsg)
          ? apiMsg.join(', ')
          : String(apiMsg)
        : err.message

      toast({
        title: 'Failed to update payroll',
        description,
        variant: 'destructive',
      })
    },
  })

  const watchedEffectiveFrom = form.watch('effectiveFrom')
  const watchedBasic = form.watch('basicStipend')
  const notificationNeeded =
    verified &&
    needsApproval &&
    latestStipend != null &&
    (isIncrement || Number(watchedBasic) !== Number(latestStipend.basicStipend))

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Payroll & Joining Date</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit((values) =>
              mutation.mutate({ ...values, isIncrement })
            )}
            className="space-y-6"
          >
            <FormField
              control={form.control}
              name="joiningDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Joining Date</FormLabel>
                  <FormControl>
                    <DateInput
                      value={field.value ?? ''}
                      onChange={field.onChange}
                      onBlur={field.onBlur}
                      name={field.name}
                      ref={field.ref}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {latestStipend && canEditPay ? (
              <>
                <p className="rounded-md border border-border bg-muted/40 px-3 py-2 text-sm text-text-secondary">
                  Saving updates the current package only. Tick salary
                  increment only when pay changes from a new month — the
                  start date is always the <strong>1st</strong> of that
                  month (mid-month dates are snapped to the 1st). To fix a
                  raise saved mid-month, change &quot;Package starts on&quot;
                  to the 1st without ticking increment.
                </p>
                <StipendPackageFields control={form.control} watch={form.watch} basicOnly />
                <PaySlipEditor draft={slip} />

                <label className="flex items-start gap-2 text-sm">
                  <input
                    type="checkbox"
                    className="mt-1"
                    checked={isIncrement}
                    onChange={(e) => {
                      const checked = e.target.checked
                      setIsIncrement(checked)
                      if (checked) {
                        form.setValue(
                          'effectiveFrom',
                          firstOfCurrentMonthIso(),
                          { shouldDirty: true },
                        )
                      } else {
                        form.setValue(
                          'effectiveFrom',
                          originalEffectiveFrom,
                          { shouldDirty: true },
                        )
                      }
                    }}
                  />
                  <span>
                    This is a salary increment from a new month (starts a
                    new package on the 1st)
                  </span>
                </label>

                <FormField
                  control={form.control}
                  name="effectiveFrom"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {isIncrement
                          ? 'Increment month (always the 1st)'
                          : 'Package starts on'}
                      </FormLabel>
                      <FormControl>
                        <DateInput
                          value={field.value ?? ''}
                          onChange={(v) => {
                            if (isIncrement && v) {
                              field.onChange(firstOfMonthIso(v))
                            } else {
                              field.onChange(v)
                            }
                          }}
                          onBlur={field.onBlur}
                          name={field.name}
                          ref={field.ref}
                        />
                      </FormControl>
                      {isIncrement ? (
                        <p className="text-xs text-text-secondary">
                          Pick any day in the target month — the system
                          uses the 1st so the whole month uses the new
                          package.
                        </p>
                      ) : field.value && !field.value.endsWith('-01') ? (
                        <div className="space-y-1">
                          <p className="text-xs text-amber-800">
                            A date that is not the 1st splits that
                            month&apos;s basic on regenerate. Use the 1st
                            unless correcting intentionally.
                          </p>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              form.setValue(
                                'effectiveFrom',
                                firstOfMonthIso(field.value ?? ''),
                                { shouldDirty: true },
                              )
                            }
                          >
                            Move to 1st of this month
                          </Button>
                        </div>
                      ) : (
                        <p className="text-xs text-text-secondary">
                          Prefer the 1st of the month so Monthly Payroll
                          matches this package for the whole month.
                        </p>
                      )}
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {!isIncrement &&
                  watchedEffectiveFrom &&
                  originalEffectiveFrom &&
                  watchedEffectiveFrom.slice(0, 7) >
                    originalEffectiveFrom.slice(0, 7) && (
                    <div className="space-y-2 rounded-md border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900">
                      <p>
                        Moving the start to a later month rewrites the current
                        package (starting {originalEffectiveFrom}) instead of
                        starting a new one, and recalculates unpaid payroll
                        from that date. For a raise from a new month, use a
                        salary increment.
                      </p>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setIsIncrement(true)
                          form.setValue(
                            'effectiveFrom',
                            firstOfMonthIso(watchedEffectiveFrom),
                            { shouldDirty: true },
                          )
                        }}
                      >
                        Make this a salary increment
                      </Button>
                    </div>
                  )}

                {(isIncrement ||
                  (watchedEffectiveFrom &&
                    watchedEffectiveFrom !== originalEffectiveFrom)) && (
                  <FormField
                    control={form.control}
                    name="reason"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          {isIncrement
                            ? 'Reason for increment'
                            : 'Reason for date/package correction'}
                        </FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder={
                              isIncrement
                                ? 'e.g. Annual increment'
                                : 'e.g. Management order — raise from month day 1'
                            }
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </>
            ) : (
              <p className="text-sm text-text-secondary">
                {latestStipend
                  ? 'Salary changes are made by Finance (Payroll Officer). Only the joining date can be updated here.'
                  : 'No stipend record found. Only joining date can be updated.'}
              </p>
            )}

            {latestStipend && canEditPay ? (
              verified ? (
                <p className="rounded-lg border border-green-200 bg-green-50 p-3 text-sm text-green-900">
                  Verified by Finance on {packageVerifiedAt!.slice(0, 10)}.
                  {needsApproval
                    ? ' Basic, increments and allowances go to the Founder for approval; deductions apply directly.'
                    : ''}
                </p>
              ) : (
                <p className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                  Not verified yet: Save applies directly. After Save &amp; Verify, every change needs Founder approval.
                </p>
              )
            ) : null}

            {notificationNeeded ? (
              <div className="space-y-1 rounded-lg border border-red-200 bg-red-50 p-3 text-sm">
                <Label htmlFor="pay-notification">Signed notification (required for a Basic change or increment)</Label>
                <Input
                  id="pay-notification"
                  type="file"
                  accept=".jpg,.jpeg,.png,.pdf"
                  onChange={(e) => setNotificationFile(e.target.files?.[0])}
                />
                <p className="text-xs text-red-800">It goes to the Founder with the request.</p>
              </div>
            ) : null}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-primary hover:bg-primary-dark"
                disabled={mutation.isPending || (notificationNeeded && !notificationFile)}
              >
                {mutation.isPending ? 'Saving...' : 'Save Changes'}
              </Button>
              {canVerify ? (
                <Button
                  type="button"
                  className="bg-green-700 hover:bg-green-800"
                  disabled={mutation.isPending}
                  onClick={form.handleSubmit((values) => setVerifyValues(values))}
                >
                  Save &amp; Verify
                </Button>
              ) : null}
            </DialogFooter>
            <ConfirmDialog
              open={verifyValues != null}
              title="Verify this salary package?"
              description="After verification the package is locked. Any later change to this employee's salary will need Founder approval."
              confirmLabel="Save & Verify"
              loading={mutation.isPending}
              onCancel={() => setVerifyValues(undefined)}
              onConfirm={() => {
                if (verifyValues) mutation.mutate({ ...verifyValues, isIncrement, verify: true })
                setVerifyValues(undefined)
              }}
            />
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
