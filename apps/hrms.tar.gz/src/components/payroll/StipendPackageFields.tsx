import type { Control, FieldValues, Path } from 'react-hook-form'
import { PKRInput } from '@/components/common/PKRInput'
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { calculateLumpsumTotal, formatPKR } from '@/lib/stipendUtils'

const EARNING_FIELDS = [
  ['basicStipend', 'Basic Stipend', true],
  ['allowances', 'Allowances', false],
  ['reward', 'Reward', false],
  ['progressReward', 'Reward on Progress (Incentive)', false],
  ['fuelAllowance', 'Petrol (Fuel Allowance)', false],
] as const

/** From this month the four allowance fields live in Allowances (employee → Payroll tab). */
const ALLOWANCES_FROM_MONTH = '2026-11'
export function packageAllowancesLive(now = new Date()) {
  const m = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
  return m >= ALLOWANCES_FROM_MONTH
}

const DEDUCTION_FIELDS = [
  ['loanDeduction', 'Loan Deduction'],
  ['advanceDeduction', 'Advance Deduction'],
  ['fineDeduction', 'Fine Deduction'],
  ['healthDeduction', 'Health Deduction'],
] as const

type StipendPackageFieldsProps<T extends FieldValues> = {
  control: Control<T>
  watch: (names: Path<T>[]) => unknown[]
  basicRequired?: boolean
  /** Edit Payroll: only Basic; allowances and deductions are typed in the slip section. */
  basicOnly?: boolean
}

export function StipendPackageFields<T extends FieldValues>({
  control,
  watch,
  basicRequired = true,
  basicOnly = false,
}: StipendPackageFieldsProps<T>) {
  const [
    basicStipend,
    allowances,
    reward,
    progressReward,
    fuelAllowance,
    loanDeduction,
    advanceDeduction,
    fineDeduction,
    healthDeduction,
  ] = watch([
    'basicStipend' as Path<T>,
    'allowances' as Path<T>,
    'reward' as Path<T>,
    'progressReward' as Path<T>,
    'fuelAllowance' as Path<T>,
    'loanDeduction' as Path<T>,
    'advanceDeduction' as Path<T>,
    'fineDeduction' as Path<T>,
    'healthDeduction' as Path<T>,
  ]) as number[]

  const lumpsum = calculateLumpsumTotal({
    basicStipend: Number(basicStipend) || 0,
    allowances: Number(allowances) || 0,
    reward: Number(reward) || 0,
    progressReward: Number(progressReward) || 0,
    fuelAllowance: Number(fuelAllowance) || 0,
    loanDeduction: Number(loanDeduction) || 0,
    advanceDeduction: Number(advanceDeduction) || 0,
    fineDeduction: Number(fineDeduction) || 0,
    healthDeduction: Number(healthDeduction) || 0,
  })

  const allowancesLive = packageAllowancesLive()
  if (basicOnly) {
    // Old fixed package deductions keep their saved amounts; show them when not zero.
    const oldDeductions = DEDUCTION_FIELDS.map(([name, label]) => [label, Number(watch([name as Path<T>])[0]) || 0] as const)
      .filter(([, v]) => v > 0)
    return (
      <div className="space-y-3">
        <FormField
          control={control}
          name={'basicStipend' as Path<T>}
          render={({ field }) => (
            <FormItem>
              <FormLabel>
                Basic Stipend<span className="text-destructive"> *</span>
              </FormLabel>
              <FormControl>
                <PKRInput value={Number(field.value) || 0} onChange={field.onChange} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        {oldDeductions.length ? (
          <p className="text-xs text-text-secondary">
            Fixed package deductions still applied: {oldDeductions.map(([l, v]) => `${l} ${formatPKR(v)}`).join(', ')}.
          </p>
        ) : null}
        <p className="text-sm">
          Package lumpsum: <span className="font-semibold">{formatPKR(lumpsum)}</span>
        </p>
      </div>
    )
  }
  const earningFields = allowancesLive
    ? EARNING_FIELDS.filter(([name]) => name === 'basicStipend')
    : EARNING_FIELDS

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <h3 className="text-sm font-semibold">Earnings</h3>
        <p className="text-xs text-text-secondary">
          {allowancesLive
            ? 'Allowances, Reward, Reward on Progress and Petrol are set under Allowances (employee profile → Payroll tab).'
            : 'From November 2026 payroll, Allowances, Reward, Reward on Progress and Petrol move to Allowances (employee profile → Payroll tab); amounts entered here are carried over.'}
        </p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {earningFields.map(([name, label, required]) => (
            <FormField
              key={name}
              control={control}
              name={name as Path<T>}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    {label}
                    {(required || basicRequired) && name === 'basicStipend' && (
                      <span className="text-destructive"> *</span>
                    )}
                  </FormLabel>
                  <FormControl>
                    <PKRInput
                      value={Number(field.value) || 0}
                      onChange={field.onChange}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          ))}
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-sm font-semibold">Deductions</h3>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {DEDUCTION_FIELDS.map(([name, label]) => (
            <FormField
              key={name}
              control={control}
              name={name as Path<T>}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{label}</FormLabel>
                  <FormControl>
                    <PKRInput
                      value={Number(field.value) || 0}
                      onChange={field.onChange}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          ))}
        </div>
      </div>

      <div className="rounded-lg border border-border bg-surface p-4">
        <p className="text-sm text-text-secondary">Lumpsum Total</p>
        <p className="text-2xl font-bold text-primary">{formatPKR(lumpsum)}</p>
        <p className="mt-1 text-xs text-text-secondary">
          Earnings minus fixed deductions (auto-calculated)
        </p>
      </div>
    </div>
  )
}
