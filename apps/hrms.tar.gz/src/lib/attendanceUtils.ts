import { formatDutyDisplay } from '@/lib/dutyTimes'
import { toPakistanTime24 } from '@/lib/timeFormat'

export function parseTimeToMinutes(time: string): number {
  const [hours, minutes] = time.split(':').map(Number)
  return hours * 60 + (minutes ?? 0)
}

export function combineDateAndTime(date: string, time: string): string {
  return `${date}T${time}:00+05:00`
}

/**
 * Build check-out ISO for a log. Uses the attendance date when possible;
 * if the chosen time would be at/before check-in (overnight shift), moves
 * to the next calendar day.
 */
export function combineCheckOutDateTime(
  logDate: string,
  checkInIso: string | null | undefined,
  checkOut24: string,
): string {
  const dateOnly = logDate.slice(0, 10)
  const sameDay = combineDateAndTime(dateOnly, checkOut24)
  if (!checkInIso) return sameDay
  if (new Date(sameDay).getTime() > new Date(checkInIso).getTime()) {
    return sameDay
  }
  const [y, m, d] = dateOnly.split('-').map(Number)
  const next = new Date(Date.UTC(y, m - 1, d + 1))
  const nextDate = `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, '0')}-${String(next.getUTCDate()).padStart(2, '0')}`
  return combineDateAndTime(nextDate, checkOut24)
}

/**
 * Signed minutes between a punch and duty start, resolved to the nearest
 * occurrence of that duty time (positive = after duty start, negative =
 * before it). Without this wrap, a punch a few minutes before an overnight
 * duty start (e.g. 19:20 against a 20:00 start) reads as ~23.5 hours *since*
 * the previous day's start and produces absurd late totals (1000+ minutes)
 * instead of being recognised as an early arrival.
 */
function signedMinutesFromDutyStart(
  minutesOfDay: number,
  dutyStartMin: number,
): number {
  let diff = minutesOfDay - dutyStartMin
  if (diff > 720) diff -= 1440
  if (diff <= -720) diff += 1440
  return diff
}

export function calcLateMinutes(
  checkInTime: string,
  dutyStart: string,
  graceMinutes = 15,
): number {
  if (!checkInTime || !dutyStart) return 0
  const checkIn = parseTimeToMinutes(checkInTime)
  const dutyTotal = parseTimeToMinutes(dutyStart)

  const minutesSince = signedMinutesFromDutyStart(checkIn, dutyTotal)

  const lateMinutes = minutesSince - graceMinutes
  return lateMinutes > 0 ? lateMinutes : 0
}

export function calcOvertimeMinutes(
  checkOutTime: string,
  shiftEnd: string,
  graceMinutes = 60,
): number {
  const checkOut = parseTimeToMinutes(checkOutTime)
  const threshold = parseTimeToMinutes(shiftEnd) + graceMinutes
  if (checkOut > threshold) return checkOut - threshold
  return 0
}

export function showsTimeFields(status: string): boolean {
  return status === 'PRESENT' || status === 'LATE' || status === 'HALF_DAY'
}

export function getEmployeeDutyStartTime(employee: {
  dutyStartTime?: string | null
  shift?: { startTime?: string } | null
}): string {
  return employee.dutyStartTime ?? ''
}

export function getEmployeeDutyEndTime(employee: {
  dutyEndTime?: string | null
  shift?: { endTime?: string } | null
}): string {
  return employee.dutyEndTime ?? ''
}

export function isWithinDutyWindow(
  currentMinutes: number,
  startTime: string,
  endTime: string,
): boolean {
  if (!startTime || !endTime) return false

  const startMin = parseTimeToMinutes(startTime)
  const endMin = parseTimeToMinutes(endTime)

  if (startMin === endMin) {
    return true
  }

  if (endMin < startMin) {
    return currentMinutes >= startMin || currentMinutes <= endMin
  }

  return currentMinutes >= startMin && currentMinutes <= endMin
}

export function getUniqueDutyStartTimes(
  employees: Array<{
    dutyStartTime?: string | null
    shift?: { startTime?: string } | null
  }>,
): string[] {
  return [
    ...new Set(
      employees
        .map((e) => getEmployeeDutyStartTime(e))
        .filter((t): t is string => Boolean(t)),
    ),
  ].sort()
}

export function filterByDutyStartTime<T extends {
  dutyStartTime?: string | null
  shift?: { startTime?: string } | null
}>(items: T[], dutyStartTime: string): T[] {
  if (!dutyStartTime) return items
  return items.filter(
    (item) => getEmployeeDutyStartTime(item) === dutyStartTime,
  )
}

export function formatEmployeeDutyLabel(employee: {
  shift?: { name?: string; startTime?: string; endTime?: string } | null
  dutyStartTime?: string | null
  dutyEndTime?: string | null
}): string {
  const start = getEmployeeDutyStartTime(employee)
  const end = getEmployeeDutyEndTime(employee)
  if (!start || !end) {
    return employee.shift?.name ?? '—'
  }
  const hours = formatDutyDisplay(start, end)
  return employee.shift?.name ? `${employee.shift.name} · ${hours}` : hours
}

export function getLogLateMinutes(log: {
  lateMinutes?: number | null
  checkIn?: string | null
  status?: string
  employee?: {
    dutyStartTime?: string | null
    shift?: { startTime?: string } | null
  } | null
}): number {
  if (log.lateMinutes != null) {
    return log.lateMinutes
  }

  if (!log.checkIn || !log.employee) {
    return 0
  }

  const dutyStart = getEmployeeDutyStartTime(log.employee)
  if (!dutyStart) {
    return 0
  }

  const checkInTime = toPakistanTime24(log.checkIn)
  return calcLateMinutes(checkInTime, dutyStart)
}

/** Final payroll/attendance policy: more than 120 minutes late → HALF_DAY. */
export const HALF_DAY_LATE_THRESHOLD_MINUTES = 120

export function statusFromLateMinutes(
  lateMinutes: number,
): 'PRESENT' | 'LATE' | 'HALF_DAY' {
  if (lateMinutes > HALF_DAY_LATE_THRESHOLD_MINUTES) return 'HALF_DAY'
  if (lateMinutes > 0) return 'LATE'
  return 'PRESENT'
}

const PK_OFFSET_MS = 5 * 60 * 60 * 1000

export const ATTENDANCE_GRACE_MINUTES = 15

function toPakistanMinutesOfDay(date: Date): number {
  const pkDate = new Date(date.getTime() + PK_OFFSET_MS)
  return pkDate.getUTCHours() * 60 + pkDate.getUTCMinutes()
}

export function isWithinGrace(
  shiftStart: string,
  graceMins = ATTENDANCE_GRACE_MINUTES,
): boolean {
  if (!shiftStart) return false
  const shiftStartMins = parseTimeToMinutes(shiftStart)
  const nowMins = toPakistanMinutesOfDay(new Date())
  const minutesSince = signedMinutesFromDutyStart(nowMins, shiftStartMins)
  return minutesSince >= 0 && minutesSince <= graceMins
}

export function graceMinutesRemaining(
  shiftStart: string,
  graceMins = ATTENDANCE_GRACE_MINUTES,
): number {
  if (!shiftStart) return 0
  const shiftStartMins = parseTimeToMinutes(shiftStart)
  const nowMins = toPakistanMinutesOfDay(new Date())
  const minutesSince = signedMinutesFromDutyStart(nowMins, shiftStartMins)
  if (minutesSince < 0) return graceMins
  return Math.max(0, graceMins - minutesSince)
}
